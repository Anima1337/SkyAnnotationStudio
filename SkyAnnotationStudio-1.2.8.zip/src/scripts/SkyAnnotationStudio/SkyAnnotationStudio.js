/*
   Sky Annotation Studio - Native PixInsight PJSR MVP

   This script provides a native PixInsight interface for querying SIMBAD
   around a solved FITS/XISF image, filtering likely galaxy catalogues,
   deduplicating related object identifiers, and generating an annotated
   preview window inside PixInsight.
*/

#feature-id    SkyAnnotationStudio : Utilities > Sky Annotation Studio
#feature-info  Native PixInsight annotation browser for solved FITS/XISF images.<br/>\
Queries SIMBAD around the active image or a selected file, filters likely deep-sky catalogues,\
deduplicates related identifiers, and opens an annotated preview window.

#include <pjsr/Sizer.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/UndoFlag.jsh>

#ifndef SETTINGS_MODULE
#define SETTINGS_MODULE "SkyAnnotationStudioPJSR"
#endif

#include "../AdP/WCSmetadata.jsh"

function SkyAnnotationConfig()
{
   this.settingsProperties = [
      ["useActiveWindow", DataType_Boolean],
      ["inputFile", DataType_UCString],
      ["mainObject", DataType_UCString],
      ["photoTitle", DataType_UCString],
      ["filterPrefixes", Ext_DataType_StringArray],
      ["labelMode", DataType_UCString],
      ["labelLengthMode", DataType_UCString],
      ["objectTypeMode", DataType_UCString],
      ["cataloguePriorityMode", DataType_UCString],
      ["useSimbadObjectSize", DataType_Boolean],
      ["presetName", DataType_UCString],
      ["outputMode", DataType_UCString],
      ["showTopDescriptions", DataType_Boolean],
      ["highlightShowcaseObjects", DataType_Boolean],
      ["colorCodeObjectClasses", DataType_Boolean],
      ["showAdvanced", DataType_Boolean],
      ["autoTitle", DataType_Boolean],
      ["includeRedshift", DataType_Boolean],
      ["manualCuration", DataType_Boolean],
      ["autoReviewDelayMs", DataType_Int32],
      ["showLog", DataType_Boolean],
      ["boxSize", DataType_Double],
      ["patchScale", DataType_Double],
      ["previewPatchSize", DataType_Int32],
      ["maxObjects", DataType_Int32],
      ["sortMode", DataType_UCString],
      ["previewLabelAlignment", DataType_UCString],
      ["visibilityMode", DataType_UCString]
   ];

   this.settingsKey = function( property )
   {
      return SETTINGS_MODULE + "/config/" + property;
   };

   this.serialiseStringArray = function( value )
   {
      if ( !(value instanceof Array) )
         return "";
      return value.join( "\n" );
   };

   this.parseStringArray = function( value )
   {
      if ( value == null || value.length == 0 )
         return [];
      var raw = value.split( /[\n,|]/ );
      var parsed = [];
      for ( var i = 0; i < raw.length; ++i )
      {
         var token = raw[i].replace( /^\s+|\s+$/g, "" );
         if ( token.length > 0 )
            parsed.push( token );
      }
      return parsed;
   };

   this.LoadSettings = function()
   {
      if ( typeof Settings == "undefined" )
         return;

      for ( var i = 0; i < this.settingsProperties.length; ++i )
      {
         var property = this.settingsProperties[i][0];
         var type = this.settingsProperties[i][1];
         try
         {
            var value = Settings.read( this.settingsKey( property ), type == Ext_DataType_StringArray ? DataType_UCString : type );
            if ( value == null )
               continue;

            if ( type == Ext_DataType_StringArray )
               this[property] = this.parseStringArray( value );
            else
               this[property] = value;
         }
         catch ( ex )
         {
            // Settings are convenience state only. Ignore corrupt or incompatible values.
         }
      }
   };

   this.SaveSettings = function()
   {
      if ( typeof Settings == "undefined" )
         return;

      for ( var i = 0; i < this.settingsProperties.length; ++i )
      {
         var property = this.settingsProperties[i][0];
         var type = this.settingsProperties[i][1];
         try
         {
            if ( type == Ext_DataType_StringArray )
               Settings.write( this.settingsKey( property ), DataType_UCString, this.serialiseStringArray( this[property] ) );
            else
               Settings.write( this.settingsKey( property ), type, this[property] );
         }
         catch ( ex )
         {
            // Keep script execution independent from persistent-settings failures.
         }
      }
   };

   this.SetDefaults = function()
   {
      this.useActiveWindow = true;
      this.inputFile = "";
      this.mainObject = "";
      this.photoTitle = "Annotated Sky Field";
      this.filterPrefixes = [
         "LEDA", "Gaia", "2MASX", "SDSS", "UGC", "M", "UGCA", "MFGC",
         "MRK", "MGC", "FIRST", "MASS", "MCG", "Mrk", "2MFGC", "2MASS",
         "IC", "NGC", "SAI"
      ];
      this.labelMode = "Numbers";
      this.labelLengthMode = "Medium";
      this.objectTypeMode = "Galaxies only";
      this.cataloguePriorityMode = "Prefer Messier";
      this.useSimbadObjectSize = false;
      this.presetName = "Galaxy field";
      this.outputMode = "Showcase";
      this.showTopDescriptions = false;
      this.highlightShowcaseObjects = true;
      this.colorCodeObjectClasses = false;
      this.showAdvanced = false;
      this.autoTitle = false;
      this.includeRedshift = false;
      this.manualCuration = false;
      this.autoReviewDelayMs = 100;
      this.showLog = false;
      this.boxSize = 96;
      this.patchScale = 1.0;
      this.previewPatchSize = 256;
      this.maxObjects = 500;
      this.sortMode = "Default";
      this.previewLabelAlignment = "Left";
      this.visibilityMode = "Balanced";
   };

   this.SetDefaults();
   this.LoadSettings();
}

function SkyAnnotationEngine( dialog, config )
{
   this.dialog = dialog;
   this.config = config;

   this.log = function( message )
   {
      if ( this.dialog )
         this.dialog.appendLog( message );
      console.writeln( message );
   };

   this.tryExtractMetadata = function( imageWindow )
   {
      try
      {
         var metadata = new ImageMetadata();
         metadata.ExtractMetadata( imageWindow );
         if ( metadata.ref_I_G == null )
            return null;
         return metadata;
      }
      catch ( ex )
      {
         return null;
      }
   };

   this.windowSelectionScore = function( imageWindow, metadata, isActive )
   {
      var score = 0;
      var id = imageWindow && imageWindow.mainView ? imageWindow.mainView.id : "";
      var title = id.toLowerCase();

      if ( isActive )
         score += 1000;
      if ( title.indexOf( "_skyannot" ) >= 0 )
         score -= 500;
      if ( title.indexOf( "annot" ) >= 0 )
         score -= 200;
      if ( title.indexOf( "preview" ) >= 0 )
         score -= 150;
      if ( metadata && metadata.width && metadata.height )
         score += Math.min( 500, Math.round( (metadata.width * metadata.height) / 1000000 ) );

      return score;
   };

   this.findBestSolvedOpenWindow = function()
   {
      var windows = ImageWindow.windows;
      var active = ImageWindow.activeWindow;
      var best = null;
      var bestScore = -1e9;

      for ( var i = 0; i < windows.length; ++i )
      {
         var w = windows[i];
         if ( !w || w.isNull )
            continue;

         var metadata = this.tryExtractMetadata( w );
         if ( metadata == null )
            continue;

         var score = this.windowSelectionScore( w, metadata, active && !active.isNull && w.mainView.id == active.mainView.id );
         if ( best == null || score > bestScore )
         {
            best = { window: w, metadata: metadata, score: score };
            bestScore = score;
         }
      }

      return best;
   };

   this.currentWindow = function()
   {
      if ( this.config.useActiveWindow )
      {
         var w = ImageWindow.activeWindow;
         if ( !w || w.isNull )
            throw new Error( "There is no active image window." );

         var activeMetadata = this.tryExtractMetadata( w );
         if ( activeMetadata != null )
            return { window: w, temporary: false, metadata: activeMetadata };

         var fallback = this.findBestSolvedOpenWindow();
         if ( fallback != null )
         {
            this.log(
               "Active window has no astrometric solution; using solved window '" +
               fallback.window.mainView.id + "' instead."
            );
            return { window: fallback.window, temporary: false, metadata: fallback.metadata };
         }

         throw new Error( "No open image window with a valid astrometric solution was found." );
      }

      if ( !this.config.inputFile || this.config.inputFile.trim().length == 0 )
         throw new Error( "Please choose a FITS/XISF file." );

      var windows = ImageWindow.open( this.config.inputFile );
      if ( !windows || windows.length < 1 )
         throw new Error( "PixInsight could not open the selected file." );

      return { window: windows[0], temporary: true, metadata: null };
   };

   this.extractMetadata = function( imageWindow )
   {
      var metadata = this.tryExtractMetadata( imageWindow );
      if ( metadata == null )
         throw new Error( "The selected image has no valid astrometric solution." );
      return metadata;
   };

   this.fieldRadiusDeg = function( metadata )
   {
      if ( metadata.resolution == null || metadata.width == null || metadata.height == null )
         throw new Error( "The image metadata did not provide a usable field size." );
      return metadata.resolution * Math.max( metadata.width, metadata.height );
   };

   this.downloadText = function( url, fileName )
   {
      var filePath = File.systemTempDirectory + "/" + fileName;
      var downloader = new FileDownload( url, filePath );
      if ( !downloader.perform() )
         throw new Error( "SIMBAD download failed." );
      return File.readTextFile( filePath );
   };

   this.buildCirclePredicate = function( metadata )
   {
      var radiusDeg = this.fieldRadiusDeg( metadata );
      return (
         "CONTAINS(POINT('ICRS', ra, dec), " +
         "CIRCLE('ICRS', " + format( "%.10f", metadata.ra ) + ", " + format( "%.10f", metadata.dec ) + ", " +
         format( "%.10f", radiusDeg ) + ")) = 1"
      );
   };

   this.executeTapQuery = function( adql, fileName )
   {
      var url =
         "https://simbad.cds.unistra.fr/simbad/sim-tap/sync" +
         "?request=doQuery&lang=adql&format=tsv&query=" + encodeURIComponent( adql );
      return this.downloadText( url, fileName );
   };

   this.querySimbad = function( metadata )
   {
      this.log( "Querying SIMBAD..." );
      var objects = this.querySimbadObjects( metadata );
      var aliasesByOid = this.querySimbadAliases( objects );
      for ( var i = 0; i < objects.length; ++i )
      {
         var oid = objects[i].oid.toString();
         objects[i].aliases = aliasesByOid[oid] ? aliasesByOid[oid] : [];
      }
      return objects;
   };

   this.querySimbadObjects = function( metadata )
   {
      var predicate = this.buildCirclePredicate( metadata );
      var queryLimit = Math.max( this.config.maxObjects * 10, 5000 );
      var adql =
         "SELECT TOP " + queryLimit.toString() + " " +
         "basic.oid, basic.main_id, basic.ra, basic.dec, basic.otype, otypedef.path, " +
         "basic.galdim_majaxis, basic.galdim_minaxis, basic.galdim_angle, basic.rvz_redshift " +
         "FROM basic " +
         "JOIN otypedef ON basic.otype = otypedef.otype " +
         "WHERE " + predicate + " AND " + this.objectTypePredicate();

      var text = this.executeTapQuery( adql, "sky_annotation_simbad_objects.tsv" );
      return this.parseObjectRows( text );
   };

   this.objectTypePredicate = function()
   {
      if ( this.config.objectTypeMode == "Stars only" )
         return "(otypedef.path LIKE 'Star%' OR basic.otype IN ('*','PM*','V*','Em*','TT*'))";

      return "otypedef.path LIKE 'G%'";
   };

   this.querySimbadAliases = function( objects )
   {
      var aliasesByOid = {};
      if ( objects.length == 0 )
         return aliasesByOid;

      var chunkSize = 120;
      for ( var offset = 0; offset < objects.length; offset += chunkSize )
      {
         var chunk = objects.slice( offset, offset + chunkSize );
         var oidList = [];
         for ( var i = 0; i < chunk.length; ++i )
         {
            oidList.push( chunk[i].oid.toString() );
            aliasesByOid[chunk[i].oid.toString()] = [];
         }

         var adql =
            "SELECT oidref, id " +
            "FROM ident " +
            "WHERE oidref IN (" + oidList.join( "," ) + ")";

         var fileName = "sky_annotation_simbad_aliases_" + offset.toString() + ".tsv";
         var text = this.executeTapQuery( adql, fileName );
         var aliasRows = this.parseAliasRows( text );
         for ( var j = 0; j < aliasRows.length; ++j )
         {
            var row = aliasRows[j];
            if ( !aliasesByOid[row.oid] )
               aliasesByOid[row.oid] = [];
            if ( aliasesByOid[row.oid].indexOf( row.aliasId ) < 0 )
               aliasesByOid[row.oid].push( row.aliasId );
         }
      }

      return aliasesByOid;
   };

   this.parseObjectRows = function( text )
   {
      var rows = [];
      var lines = text.replace( /\r/g, "" ).split( "\n" );
      for ( var i = 0; i < lines.length; ++i )
      {
         var line = lines[i];
         if ( !line || line.length == 0 )
            continue;
         if ( line.charAt( 0 ) == '#' )
            continue;
         if ( line.indexOf( "oid" ) == 0 )
            continue;

         var parts = line.split( "\t" );
         if ( parts.length < 4 )
            continue;

         rows.push(
            {
               oid: this.cleanText( parts[0] ),
               mainId: this.cleanText( parts[1] ),
               ra: parseFloat( parts[2] ),
               dec: parseFloat( parts[3] ),
               otype: parts.length > 4 ? this.cleanText( parts[4] ) : "",
               otypePath: parts.length > 5 ? this.cleanText( parts[5] ) : "",
               majorAxisArcmin: parts.length > 6 ? parseFloat( parts[6] ) : NaN,
               minorAxisArcmin: parts.length > 7 ? parseFloat( parts[7] ) : NaN,
               positionAngle: parts.length > 8 ? parseFloat( parts[8] ) : NaN,
               redshift: parts.length > 9 ? parseFloat( parts[9] ) : NaN,
               aliases: []
            }
         );
      }
      return rows;
   };

   this.parseAliasRows = function( text )
   {
      var rows = [];
      var lines = text.replace( /\r/g, "" ).split( "\n" );
      for ( var i = 0; i < lines.length; ++i )
      {
         var line = lines[i];
         if ( !line || line.length == 0 )
            continue;
         if ( line.charAt( 0 ) == '#' )
            continue;
         if ( line.indexOf( "oidref" ) == 0 )
            continue;

         var parts = line.split( "\t" );
         if ( parts.length < 2 )
            continue;

         rows.push(
            {
               oid: this.cleanText( parts[0] ),
               aliasId: this.cleanText( parts[1] )
            }
         );
      }
      return rows;
   };

   this.cleanText = function( text )
   {
      if ( text == null )
         return "";
      var s = text.toString();
      s = s.replace( /^"+|"+$/g, "" );
      return s.replace( /^\s+|\s+$/g, "" );
   };

   this.normaliseAlias = function( text )
   {
      return this.cleanText( text ).replace( /\s+/g, " " );
   };

   this.matchCatalogueType = function( name )
   {
      var text = this.normaliseAlias( name );
      var compact = text.replace( /\s+/g, "" ).toUpperCase();
      var patterns = [
         ["2MFGC", function( t, c ) { return c.indexOf( "2MFGC" ) >= 0; }],
         ["2MASX", function( t, c ) { return c.indexOf( "2MASX" ) >= 0; }],
         ["2MASS", function( t, c ) { return c.indexOf( "2MASS" ) >= 0; }],
         ["SDSS", function( t, c ) { return c.indexOf( "SDSS" ) >= 0 || c.indexOf( "SDSSCGB" ) >= 0; }],
         ["UGCA", function( t, c ) { return c.indexOf( "UGCA" ) >= 0; }],
         ["UGC", function( t, c ) { return /\bUGC\b/i.test( t ); }],
         ["NGC", function( t, c ) { return /\bNGC\b/i.test( t ); }],
         ["IC", function( t, c ) { return /\bIC\b/i.test( t ); }],
         ["LEDA", function( t, c ) { return c.indexOf( "LEDA" ) >= 0; }],
         ["Gaia", function( t, c ) { return c.indexOf( "GAIA" ) >= 0; }],
         ["SAI", function( t, c ) { return c.indexOf( "SAI" ) >= 0; }],
         ["FIRST", function( t, c ) { return c.indexOf( "FIRST" ) >= 0; }],
         ["MFGC", function( t, c ) { return c.indexOf( "MFGC" ) >= 0; }],
         ["MGC", function( t, c ) { return /\bMGC\b/i.test( t ); }],
         ["MRK", function( t, c ) { return c.indexOf( "MRK" ) >= 0; }],
         ["MCG", function( t, c ) { return c.indexOf( "MCG" ) >= 0; }],
         ["MASS", function( t, c ) { return c.indexOf( "MASS" ) >= 0; }],
         ["M", function( t, c ) { return /\bM\s*\d+\b/i.test( t ); }]
      ];

      for ( var i = 0; i < patterns.length; ++i )
         if ( patterns[i][1]( text, compact ) )
            return patterns[i][0];
      return "";
   };

   this.cataloguePriority = function( catalogueType )
   {
      var order = null;

      if ( this.config.cataloguePriorityMode == "Prefer NGC/IC" )
      {
         order = {
            "NGC": 1, "IC": 2, "M": 3, "UGC": 4, "UGCA": 5, "MCG": 6,
            "MRK": 7, "MGC": 8, "LEDA": 9, "2MASX": 10, "2MASS": 11,
            "SDSS": 12, "Gaia": 13, "SAI": 14, "FIRST": 15, "MFGC": 16,
            "2MFGC": 17, "MASS": 18
         };
      }
      else if ( this.config.cataloguePriorityMode == "Known catalogues first" )
      {
         order = {
            "M": 1, "NGC": 2, "IC": 3, "UGC": 4, "UGCA": 5, "MCG": 6,
            "LEDA": 7, "2MASX": 8, "MRK": 9, "MGC": 10, "MFGC": 11,
            "2MFGC": 12, "SAI": 13, "SDSS": 20, "2MASS": 21, "MASS": 22,
            "Gaia": 23, "FIRST": 24
         };
      }
      else
      {
         order = {
            "M": 1, "NGC": 2, "IC": 3, "UGC": 4, "UGCA": 5, "MCG": 6,
            "MRK": 7, "MGC": 8, "LEDA": 9, "2MASX": 10, "2MASS": 11,
            "SDSS": 12, "Gaia": 13, "SAI": 14, "FIRST": 15, "MFGC": 16,
            "2MFGC": 17, "MASS": 18
         };
      }

      return order[catalogueType] ? order[catalogueType] : 999;
   };

   this.redshiftDistanceMly = function( redshift )
   {
      if ( isNaN( redshift ) || redshift <= 0 )
         return NaN;

      // Flat LCDM approximation. Good enough for relative "depth" ordering without
      // adding a dependency or implying high-precision cosmology.
      var z = Math.min( redshift, 8.0 );
      var omegaM = 0.30;
      var omegaL = 0.70;
      var steps = Math.max( 24, Math.min( 600, Math.round( z * 180 ) ) );
      if ( steps % 2 == 1 )
         ++steps;

      var dz = z / steps;
      var sum = 0;
      for ( var i = 0; i <= steps; ++i )
      {
         var zi = i * dz;
         var invE = 1.0 / Math.sqrt( omegaM * Math.pow( 1 + zi, 3 ) + omegaL );
         sum += (i == 0 || i == steps) ? invE : ((i % 2 == 0) ? 2 * invE : 4 * invE);
      }

      var cKmS = 299792.458;
      var h0 = 70.0;
      var comovingMpc = (cKmS / h0) * (dz / 3.0) * sum;
      return comovingMpc * 3.26156;
   };

   this.isQuasarLikeObject = function( object )
   {
      var text = (object.otype + " " + object.otypePath + " " + object.mainId + " " + object.displayId).toUpperCase();
      for ( var i = 0; object.aliases && i < object.aliases.length; ++i )
         text += " " + object.aliases[i].toUpperCase();

      return /\b(QSO|QUASAR|BLLAC|BLAZAR)\b/.test( text );
   };

   this.isSurveyOnlyCatalogue = function( catalogueType )
   {
      return catalogueType == "Gaia" || catalogueType == "SDSS" ||
         catalogueType == "2MASS" || catalogueType == "MASS" ||
         catalogueType == "FIRST";
   };

   this.isGroupLikeName = function( name )
   {
      var text = this.normaliseAlias( name ).toUpperCase();
      if ( text.length == 0 )
         return false;

      if ( /\b(GROUP|TRIPLET|CLUSTER|ASSOCIATION)\b/.test( text ) )
         return true;

      // SIMBAD can return "DWH M 82 3"-style sub-components before the
      // canonical Messier object. They are useful aliases, not primary panels.
      return /^DWH\s+M\s*\d+\s+\d+\b/.test( text );
   };

   this.isMainObjectCandidate = function( object )
   {
      var mainObject = this.normalisedMainObject();
      if ( mainObject.length == 0 || !object )
         return false;

      var displayCompact = this.normaliseAlias( object.displayId ).replace( /\s+/g, "" ).toUpperCase();
      var mainCompact = this.normaliseAlias( object.mainId ).replace( /\s+/g, "" ).toUpperCase();
      if ( displayCompact == mainObject || mainCompact == mainObject )
         return true;

      var displayParent = this.extractParentObjectId( object.displayId );
      var mainParent = this.extractParentObjectId( object.mainId );
      return displayParent == mainObject || mainParent == mainObject || object.familyKey == mainObject;
   };

   this.chooseDisplayId = function( mainId, aliases )
   {
      var best = this.normaliseAlias( mainId );
      var bestScore = this.cataloguePriority( this.matchCatalogueType( best ) );
      var candidates = [best];
      for ( var i = 0; i < aliases.length; ++i )
         candidates.push( this.normaliseAlias( aliases[i] ) );

      for ( var j = 0; j < candidates.length; ++j )
      {
         var candidate = candidates[j];
         if ( candidate.length == 0 )
            continue;
         if ( this.isGroupLikeName( candidate ) )
            continue;
         var score = this.cataloguePriority( this.matchCatalogueType( candidate ) );
         if ( score < bestScore || (score == bestScore && candidate.length < best.length) )
         {
            best = candidate;
            bestScore = score;
         }
      }

      return best;
   };

   this.extractParentObjectId = function( name )
   {
      var text = this.normaliseAlias( name );
      if ( text.length == 0 )
         return "";

      text = text.replace( /^\[[^\]]+\]\s*/, "" );
      var patterns = [
         [/^M\s*([0-9]+)\b/i, "M$1"],
         [/^NGC\s*([0-9A-Z]+)\b/i, "NGC$1"],
         [/^IC\s*([0-9A-Z]+)\b/i, "IC$1"],
         [/^UGCA\s*([0-9A-Z-]+)\b/i, "UGCA$1"],
         [/^UGC\s*([0-9A-Z-]+)\b/i, "UGC$1"],
         [/^LEDA\s*([0-9]+)\b/i, "LEDA$1"],
         [/^MRK\s*([0-9A-Z]+)\b/i, "MRK$1"],
         [/^MGC\s*([0-9A-Z]+)\b/i, "MGC$1"],
         [/^MCG\s*([+\-0-9]+-[0-9]+-[0-9]+)\b/i, "MCG$1"],
         [/^2MASX\s+([A-Z0-9+\-.]+)\b/i, "2MASX$1"],
         [/^2MASS\s+([A-Z0-9+\-.]+)\b/i, "2MASS$1"],
         [/^2MFGC\s*([0-9]+)\b/i, "2MFGC$1"],
         [/^SDSS\s+([A-Z0-9+\-.]+)\b/i, "SDSS$1"],
         [/^SAI\s*([0-9]+)\b/i, "SAI$1"],
         [/^Gaia\s+DR3\s+([0-9]+)\b/i, "GaiaDR3$1"]
      ];

      for ( var i = 0; i < patterns.length; ++i )
      {
         var m = text.match( patterns[i][0] );
         if ( m )
            return patterns[i][1].replace( "$1", m[1].toUpperCase() );
      }

      return "";
   };

   this.looksLikeSubobject = function( name )
   {
      var text = this.normaliseAlias( name );
      return text.indexOf( "[" ) == 0 || /\bM\s*\d+\s+\d+\b/i.test( text );
   };

   this.objectFamilyKey = function( displayId, aliases, mainId )
   {
      var keys = [];
      var k = this.extractParentObjectId( displayId );
      if ( k.length > 0 )
         keys.push( k );
      k = this.extractParentObjectId( mainId );
      if ( k.length > 0 )
         keys.push( k );

      for ( var i = 0; i < aliases.length; ++i )
      {
         k = this.extractParentObjectId( aliases[i] );
         if ( k.length > 0 )
            keys.push( k );
      }

      if ( keys.length == 0 )
         return "";

      keys.sort( function( a, b )
      {
         var pa = this.cataloguePriority( this.matchCatalogueType( a ) );
         var pb = this.cataloguePriority( this.matchCatalogueType( b ) );
         if ( pa != pb )
            return pa - pb;
         return a.length - b.length;
      }.bind( this ) );
      return keys[0];
   };

   this.groupRows = function( rows )
   {
      for ( var i = 0; i < rows.length; ++i )
      {
         rows[i].aliases = rows[i].aliases ? rows[i].aliases : [];
         rows[i].displayId = this.chooseDisplayId( rows[i].mainId, rows[i].aliases );
         rows[i].catalogueType = this.matchCatalogueType( rows[i].displayId );
         if ( rows[i].catalogueType.length == 0 )
            rows[i].catalogueType = this.matchCatalogueType( rows[i].mainId );
         rows[i].familyKey = this.objectFamilyKey( rows[i].displayId, rows[i].aliases, rows[i].mainId );
         rows[i].isSubobject =
            this.looksLikeSubobject( rows[i].displayId ) ||
            this.looksLikeSubobject( rows[i].mainId );
      }
      return rows;
   };

   this.filterObjects = function( objects )
   {
      var keepPrefixes = {};
      for ( var i = 0; i < this.config.filterPrefixes.length; ++i )
         keepPrefixes[this.config.filterPrefixes[i]] = true;

      var filtered = [];
      for ( var j = 0; j < objects.length; ++j )
      {
         if ( !this.isMainObjectCandidate( objects[j] ) && this.isGroupLikeName( objects[j].displayId ) )
            continue;
         if ( !this.isMainObjectCandidate( objects[j] ) && this.isGroupLikeName( objects[j].mainId ) )
            continue;

         if ( this.config.objectTypeMode == "Galaxies, quasars off" && this.isQuasarLikeObject( objects[j] ) )
            continue;

         if ( this.config.objectTypeMode == "Known galaxies priority" &&
              !this.isMainObjectCandidate( objects[j] ) &&
              this.isSurveyOnlyCatalogue( objects[j].catalogueType ) )
            continue;

         if ( this.config.objectTypeMode == "Stars only" )
         {
            filtered.push( objects[j] );
            continue;
         }

         if ( keepPrefixes[objects[j].catalogueType] )
            filtered.push( objects[j] );
      }
      return filtered;
   };

   this.projectObjects = function( metadata, objects )
   {
      var projected = [];
      for ( var i = 0; i < objects.length; ++i )
      {
         var p = metadata.Convert_RD_I( new Point( objects[i].ra, objects[i].dec ), true );
         if ( !p )
            continue;
         if ( p.x < 0 || p.y < 0 || p.x >= metadata.width || p.y >= metadata.height )
            continue;
         objects[i].px = p.x;
         objects[i].py = p.y;
         objects[i].pixelScaleDeg = metadata.resolution;
         projected.push( objects[i] );
      }
      return projected;
   };

   this.dedupeFamilies = function( objects )
   {
      var byFamily = {};
      var deduped = [];

      for ( var i = 0; i < objects.length; ++i )
      {
         var object = objects[i];
         if ( object.familyKey.length == 0 )
         {
            deduped.push( object );
            continue;
         }

         if ( !byFamily[object.familyKey] )
            byFamily[object.familyKey] = [];
         byFamily[object.familyKey].push( object );
      }

      for ( var familyKey in byFamily )
      {
         var family = byFamily[familyKey];
         var canonical = null;
         for ( var j = 0; j < family.length; ++j )
         {
            var item = family[j];
            if ( this.extractParentObjectId( item.displayId ) == familyKey && !item.isSubobject )
            {
               if ( canonical == null || item.displayId.length < canonical.displayId.length )
                  canonical = item;
            }
         }

         if ( canonical != null )
         {
            deduped.push( canonical );
            continue;
         }

         family.sort( function( a, b )
         {
            var pa = this.cataloguePriority( a.catalogueType );
            var pb = this.cataloguePriority( b.catalogueType );
            if ( pa != pb )
               return pa - pb;
            return a.displayId.length - b.displayId.length;
         }.bind( this ) );
         deduped.push( family[0] );
      }

      deduped.sort( function( a, b )
      {
         var pa = this.cataloguePriority( a.catalogueType );
         var pb = this.cataloguePriority( b.catalogueType );
         if ( pa != pb )
            return pa - pb;
         return a.displayId < b.displayId ? -1 : 1;
      }.bind( this ) );

      return deduped;
   };

   this.sortObjects = function( objects )
   {
      objects.sort( function( a, b )
      {
         var ma = this.isMainObjectCandidate( a ) ? 0 : 1;
         var mb = this.isMainObjectCandidate( b ) ? 0 : 1;
         if ( ma != mb )
            return ma - mb;

         var pa = this.cataloguePriority( a.catalogueType );
         var pb = this.cataloguePriority( b.catalogueType );
         if ( pa != pb )
            return pa - pb;
         return a.displayId < b.displayId ? -1 : (a.displayId > b.displayId ? 1 : 0);
      }.bind( this ) );
      return objects;
   };

   this.normalisedMainObject = function()
   {
      return this.normaliseAlias( this.config.mainObject ).replace( /\s+/g, "" ).toUpperCase();
   };

   this.simbadObjectPatchSize = function( object, baseSize )
   {
      if ( !this.config.useSimbadObjectSize )
         return 0;
      if ( object.pixelScaleDeg == null || object.pixelScaleDeg <= 0 )
         return 0;

      var major = isNaN( object.majorAxisArcmin ) ? 0 : object.majorAxisArcmin;
      var minor = isNaN( object.minorAxisArcmin ) ? 0 : object.minorAxisArcmin;
      var angularArcmin = Math.max( major, minor );
      if ( angularArcmin <= 0 )
         return 0;

      var diameterPx = (angularArcmin / 60.0) / object.pixelScaleDeg;
      var margin = 1.45;
      if ( minor > 0 && major / Math.max( 0.01, minor ) > 3.0 )
         margin = 1.70;

      var candidate = Math.round( diameterPx * margin );
      candidate = Math.max( Math.round( baseSize * 0.45 ), candidate );
      return Math.max( 24, Math.min( 2048, candidate ) );
   };

   this.getPatchSize = function( object )
   {
      var displayCompact = this.normaliseAlias( object.displayId ).replace( /\s+/g, "" ).toUpperCase();
      var mainObject = this.normalisedMainObject();
      var baseSize = Math.max( 24, Math.round( this.config.boxSize ) );
      var patchSize = Math.round( baseSize / 3 );

      if ( mainObject.length > 0 && displayCompact == mainObject )
         patchSize = Math.round( baseSize * 10.6667 );
      else if ( object.catalogueType == "M" )
         patchSize = Math.round( baseSize * 5.3333 );
      else if ( object.catalogueType == "NGC" || object.catalogueType == "IC" )
         patchSize = Math.round( baseSize * 2.6667 );
      else if ( object.catalogueType == "SAI" || object.catalogueType == "Gaia" )
         patchSize = Math.round( baseSize * 1.3333 );
      else if ( object.catalogueType == "UGC" || object.catalogueType == "UGCA" )
         patchSize = Math.round( baseSize * 1.1667 );
      else if ( object.catalogueType == "MCG" )
         patchSize = Math.round( baseSize * 1.1667 );
      else if ( object.catalogueType == "MFGC" || object.catalogueType == "2MFGC" )
         patchSize = baseSize;
      else if ( object.catalogueType == "2MASX" || object.catalogueType == "SDSS" )
         patchSize = Math.round( baseSize * 0.5 );
      else if (
         object.catalogueType == "LEDA" ||
         object.catalogueType == "MRK" ||
         object.catalogueType == "MGC" ||
         object.catalogueType == "2MASS"
      )
         patchSize = Math.round( baseSize / 3 );

      var simbadPatchSize = this.simbadObjectPatchSize( object, baseSize );
      if ( simbadPatchSize > 0 )
         patchSize = Math.max( patchSize, simbadPatchSize );

      if ( object.isSubobject )
         patchSize = Math.min( patchSize, 96 );
      else if (
         object.catalogueType == "2MASX" ||
         object.catalogueType == "SDSS" ||
         object.catalogueType == "UGC" ||
         object.catalogueType == "UGCA" ||
         object.catalogueType == "MFGC" ||
         object.catalogueType == "2MFGC"
      )
         patchSize = Math.round( patchSize * 1.25 );

      return Math.max( 24, Math.round( patchSize * this.config.patchScale ) );
   };

   this.buildBox = function( px, py, patchSize )
   {
      var half = Math.floor( patchSize / 2 );
      return {
         left: Math.round( px - half ),
         top: Math.round( py - half ),
         right: Math.round( px - half + patchSize ),
         bottom: Math.round( py - half + patchSize )
      };
   };

   this.buildClampedSquareBox = function( px, py, size, width, height )
   {
      size = Math.round( Math.min( Math.max( size, 1 ), Math.min( width, height ) ) );
      var half = Math.floor( size / 2 );
      var left = Math.round( px - half );
      var top = Math.round( py - half );
      left = Math.max( 0, Math.min( width - size, left ) );
      top = Math.max( 0, Math.min( height - size, top ) );
      return {
         left: left,
         top: top,
         right: left + size,
         bottom: top + size
      };
   };

   this.boxFits = function( box, width, height )
   {
      return box.left >= 0 && box.top >= 0 && box.right <= width && box.bottom <= height;
   };

   this.overlapRatio = function( a, b )
   {
      var left = Math.max( a.left, b.left );
      var top = Math.max( a.top, b.top );
      var right = Math.min( a.right, b.right );
      var bottom = Math.min( a.bottom, b.bottom );
      if ( right <= left || bottom <= top )
         return 0;

      var intersection = (right - left) * (bottom - top);
      var area = Math.max( 1, (a.right - a.left) * (a.bottom - a.top) );
      return intersection / area;
   };

   this.maxOverlapRatio = function( box, boxes )
   {
      var maxOverlap = 0;
      for ( var i = 0; i < boxes.length; ++i )
         maxOverlap = Math.max( maxOverlap, this.overlapRatio( box, boxes[i] ) );
      return maxOverlap;
   };

   this.adjustPatchSizeForOverlap = function( px, py, patchSize, acceptedBoxes, width, height )
   {
      var candidate = patchSize;
      var minimum = 48;
      while ( candidate > minimum )
      {
         var box = this.buildBox( px, py, candidate );
         if ( this.boxFits( box, width, height ) && this.maxOverlapRatio( box, acceptedBoxes ) <= 0.72 )
            return candidate;
         candidate = Math.max( minimum, Math.round( candidate * 0.78 ) );
      }
      return candidate;
   };

   this.isLowPriorityDuplicateCandidate = function( object )
   {
      if ( this.isMainObjectCandidate( object ) )
         return false;

      return this.cataloguePriority( object.catalogueType ) >= 9;
   };

   this.shouldSkipDuplicateCrop = function( object, box, accepted )
   {
      if ( !this.isLowPriorityDuplicateCandidate( object ) )
         return false;

      var cx = (box.left + box.right) / 2;
      var cy = (box.top + box.bottom) / 2;
      var size = Math.max( box.right - box.left, box.bottom - box.top );

      for ( var i = 0; i < accepted.length; ++i )
      {
         var other = accepted[i];
         if ( this.config.cataloguePriorityMode == "Hide Gaia if duplicate exists" &&
              object.catalogueType == "Gaia" && other.catalogueType != "Gaia" )
         {
            var gaiaOtherBox = other.box;
            var gaiaOx = (gaiaOtherBox.left + gaiaOtherBox.right) / 2;
            var gaiaOy = (gaiaOtherBox.top + gaiaOtherBox.bottom) / 2;
            var gaiaOtherSize = Math.max( gaiaOtherBox.right - gaiaOtherBox.left, gaiaOtherBox.bottom - gaiaOtherBox.top );
            var gaiaDistance = Math.sqrt( (cx - gaiaOx) * (cx - gaiaOx) + (cy - gaiaOy) * (cy - gaiaOy) );
            if ( gaiaDistance <= Math.max( 16, Math.min( size, gaiaOtherSize ) * 0.80 ) )
               return true;
            if ( this.overlapRatio( box, gaiaOtherBox ) >= 0.15 || this.overlapRatio( gaiaOtherBox, box ) >= 0.15 )
               return true;
         }

         if ( !this.isLowPriorityDuplicateCandidate( other ) && this.cataloguePriority( other.catalogueType ) > 6 )
            continue;

         var otherBox = other.box;
         var ox = (otherBox.left + otherBox.right) / 2;
         var oy = (otherBox.top + otherBox.bottom) / 2;
         var otherSize = Math.max( otherBox.right - otherBox.left, otherBox.bottom - otherBox.top );
         var distance = Math.sqrt( (cx - ox) * (cx - ox) + (cy - oy) * (cy - oy) );

         if ( distance <= Math.max( 10, Math.min( size, otherSize ) * 0.45 ) )
            return true;

         if ( this.overlapRatio( box, otherBox ) >= 0.42 || this.overlapRatio( otherBox, box ) >= 0.42 )
            return true;
      }

      return false;
   };

   this.chooseAcceptedObjects = function( imageWindow, objects )
   {
      var width = imageWindow.mainView.image.width;
      var height = imageWindow.mainView.image.height;
      var accepted = [];
      var acceptedBoxes = [];
      objects = this.sortObjects( objects.slice( 0 ) );

      for ( var i = 0; i < objects.length; ++i )
      {
         var object = objects[i];
         var patchSize = this.adjustPatchSizeForOverlap(
            object.px,
            object.py,
            this.getPatchSize( object ),
            acceptedBoxes,
            width,
            height
         );
         var box = this.buildBox( object.px, object.py, patchSize );
         if ( !this.boxFits( box, width, height ) )
            continue;
         if ( this.shouldSkipDuplicateCrop( object, box, accepted ) )
            continue;

         object.patchSize = patchSize;
         object.box = box;
         accepted.push( object );
         acceptedBoxes.push( box );
      }

      return accepted;
   };

   this.labelText = function( index, displayId )
   {
      if ( this.config.labelMode == "Object IDs" )
         return displayId;
      if ( this.config.labelMode == "Numbers + IDs" )
         return index.toString() + ": " + displayId;
      return index.toString();
   };

   this.objectClassColor = function( object )
   {
      if ( this.isMainObjectCandidate( object ) )
         return 0xffffd166;
      if ( this.isQuasarLikeObject( object ) )
         return 0xffb277ff;
      if ( this.isClassicCatalogueObject( object ) )
         return 0xffff9f43;
      if ( this.isStellarCatalogueObject( object ) )
         return 0xff6ee7b7;
      return 0xff1d4ed8;
   };

   this.isClassicCatalogueObject = function( object )
   {
      return object.catalogueType == "M" || object.catalogueType == "NGC" || object.catalogueType == "IC";
   };

   this.isStellarCatalogueObject = function( object )
   {
      return object.catalogueType == "Gaia" || object.catalogueType == "SAI";
   };

   this.objectClassBorderColors = function( object )
   {
      if ( this.isMainObjectCandidate( object ) )
         return [ 0xffffd166 ];

      var colors = [];
      if ( this.isClassicCatalogueObject( object ) )
         colors.push( 0xffff9f43 );
      if ( this.isQuasarLikeObject( object ) )
         colors.push( 0xffb277ff );
      if ( this.isStellarCatalogueObject( object ) )
         colors.push( 0xff6ee7b7 );
      if ( colors.length == 0 )
         colors.push( 0xff1d4ed8 );
      return colors;
   };

   this.drawObjectClassRect = function( g, x0, y0, x1, y1, object, width, fallbackColor )
   {
      var colors = this.config.colorCodeObjectClasses ? this.objectClassBorderColors( object ) : [ fallbackColor ];
      if ( colors.length < 2 )
      {
         g.pen = new Pen( colors[0], width );
         g.drawRect( x0, y0, x1, y1 );
         return;
      }

      var midY = Math.round( (y0 + y1) / 2 );
      g.pen = new Pen( colors[0], width );
      g.drawLine( x0, y0, x1, y0 );
      g.drawLine( x0, y0, x0, midY );
      g.drawLine( x1, y0, x1, midY );

      g.pen = new Pen( colors[1], width );
      g.drawLine( x0, y1, x1, y1 );
      g.drawLine( x0, midY, x0, y1 );
      g.drawLine( x1, midY, x1, y1 );
   };

   this.objectClassLegend = function()
   {
      return [
         { color: 0xffffd166, label: "Main target" },
         { color: 0xffff9f43, label: "Messier / NGC / IC" },
         { color: 0xffb277ff, label: "Quasar / AGN-like" },
         { color: 0xff6ee7b7, label: "Gaia / stellar catalogue" },
         { color: 0xff1d4ed8, label: "Other galaxy / survey object" }
      ];
   };

   this.objectClassSortRank = function( object )
   {
      if ( this.isMainObjectCandidate( object ) )
         return 0;
      if ( this.isClassicCatalogueObject( object ) )
         return 1;
      if ( this.isQuasarLikeObject( object ) )
         return 2;
      if ( this.isStellarCatalogueObject( object ) )
         return 3;
      return 4;
   };

   this.showcaseObjectCount = function( objects )
   {
      return Math.min( 5, objects.length );
   };

   this.getViewBitmap = function( view )
   {
      var image = view.image;
      var tmp = null;
      try
      {
         tmp = new ImageWindow(
            image.width, image.height, image.numberOfChannels,
            view.window.bitsPerSample, view.window.isFloatSample,
            image.isColor, "SkyAnnotationStudioTmp"
         );
         tmp.mainView.beginProcess( UndoFlag_NoSwapFile );
         tmp.mainView.image.apply( image );
         tmp.mainView.endProcess();
         var bmp = new Bitmap( image.width, image.height );
         bmp.assign( tmp.mainView.image.render() );
         return bmp;
      }
      finally
      {
         if ( tmp )
            tmp.forceClose();
      }
   };

   this.getWindowBitmap = function( imageWindow )
   {
      return this.getViewBitmap( imageWindow.mainView );
   };

   this.renderAnnotatedBitmap = function( imageWindow, objects )
   {
      var bmp = this.getWindowBitmap( imageWindow );
      var g = new Graphics( bmp );
      g.transparentBackground = true;
      g.antialiasing = true;
      for ( var i = 0; i < objects.length; ++i )
      {
         var o = objects[i];
         var x0 = o.box.left;
         var y0 = o.box.top;
         var x1 = o.box.right;
         var y1 = o.box.bottom;
         var isShowcase = this.config.highlightShowcaseObjects && i < this.showcaseObjectCount( objects );
         this.drawObjectClassRect( g, x0, y0, x1, y1, o, isShowcase ? 2 : 1, 0x80ffffff );
         g.pen = new Pen( this.config.colorCodeObjectClasses ? this.objectClassColor( o ) : 0xff2d9cff, isShowcase ? 2 : 1 );
         g.drawText( x0, y1 + 24, this.labelText( i + 1, o.displayId ) );
      }
      g.end();
      return bmp;
   };

   this.uniqueWindowId = function( baseId )
   {
      var outId = baseId;
      while ( !View.viewById( outId ).isNull )
         outId += "1";
      return outId;
   };

   this.bitmapToWindow = function( bmp, templateWindow, outId )
   {
      var result = new ImageWindow( bmp.width, bmp.height, 3, 8, false, true, this.uniqueWindowId( outId ) );
      result.mainView.beginProcess( UndoFlag_NoSwapFile );
      result.mainView.image.blend( bmp );
      result.mainView.endProcess();
      result.keywords = templateWindow.keywords;
      result.zoomToFit();
      result.show();
      return result;
   };

   this.renderAnnotatedWindow = function( imageWindow, objects )
   {
      return this.bitmapToWindow(
         this.renderAnnotatedBitmap( imageWindow, objects ),
         imageWindow,
         imageWindow.mainView.id + "_SkyAnnot"
      );
   };

   this.truncateText = function( text, maxLength )
   {
      if ( text.length <= maxLength )
         return text;
      return text.substr( 0, Math.max( 3, maxLength - 3 ) ) + "...";
   };

   this.labelMaxLength = function()
   {
      if ( this.config.labelLengthMode == "Short" )
         return 14;
      if ( this.config.labelLengthMode == "Full" )
         return 1000;
      return 20;
   };

   this.bitmapLuminance = function( pixel )
   {
      var r = (pixel >> 16) & 0xff;
      var g = (pixel >> 8) & 0xff;
      var b = pixel & 0xff;
      return 0.2126 * r + 0.7152 * g + 0.0722 * b;
   };

   this.quantile = function( values, q )
   {
      if ( values.length == 0 )
         return 0;
      var index = Math.max( 0, Math.min( values.length - 1, Math.round( q * (values.length - 1) ) ) );
      return values[index];
   };

   this.patchVisibilityThreshold = function( object )
   {
      if ( this.config.visibilityMode == "Off" )
         return 0;
      if ( this.isMainObjectCandidate( object ) )
         return 0;

      var priority = this.cataloguePriority( object.catalogueType );
      if ( priority <= 6 )
         return 0;

      var threshold = 6.5;
      if ( object.catalogueType == "LEDA" || object.catalogueType == "MRK" || object.catalogueType == "MGC" )
         threshold = 5.5;
      else if ( object.catalogueType == "2MASX" || object.catalogueType == "2MASS" || object.catalogueType == "SDSS" )
         threshold = 7.0;
      else if ( object.catalogueType == "Gaia" || object.catalogueType == "SAI" || object.catalogueType == "FIRST" )
         threshold = 8.0;

      if ( this.config.visibilityMode == "Permissive" )
         threshold *= 0.75;
      else if ( this.config.visibilityMode == "Strict" )
         threshold *= 1.75;

      return threshold;
   };

   this.patchLooksVisible = function( bitmap, object )
   {
      var threshold = this.patchVisibilityThreshold( object );
      if ( threshold <= 0 )
         return true;

      var samples = [];
      var stepX = Math.max( 1, Math.floor( bitmap.width / 34 ) );
      var stepY = Math.max( 1, Math.floor( bitmap.height / 34 ) );
      var marginX = Math.max( 1, Math.floor( bitmap.width * 0.06 ) );
      var marginY = Math.max( 1, Math.floor( bitmap.height * 0.06 ) );

      for ( var y = marginY; y < bitmap.height - marginY; y += stepY )
         for ( var x = marginX; x < bitmap.width - marginX; x += stepX )
            samples.push( this.bitmapLuminance( bitmap.pixel( x, y ) ) );

      if ( samples.length < 16 )
         return true;

      samples.sort( function( a, b ) { return a - b; } );
      var median = this.quantile( samples, 0.50 );
      var p95 = this.quantile( samples, 0.95 );
      var p99 = this.quantile( samples, 0.99 );

      var cx = Math.floor( bitmap.width / 2 );
      var cy = Math.floor( bitmap.height / 2 );
      var radius = Math.max( 2, Math.floor( Math.min( bitmap.width, bitmap.height ) * 0.08 ) );
      var centreSamples = [];
      for ( var yy = cy - radius; yy <= cy + radius; yy += Math.max( 1, Math.floor( radius / 2 ) ) )
      {
         if ( yy < 0 || yy >= bitmap.height )
            continue;
         for ( var xx = cx - radius; xx <= cx + radius; xx += Math.max( 1, Math.floor( radius / 2 ) ) )
         {
            if ( xx < 0 || xx >= bitmap.width )
               continue;
            centreSamples.push( this.bitmapLuminance( bitmap.pixel( xx, yy ) ) );
         }
      }

      centreSamples.sort( function( a, b ) { return a - b; } );
      var centreMedian = centreSamples.length > 0 ? this.quantile( centreSamples, 0.50 ) : median;
      var centrePeak = centreSamples.length > 0 ? this.quantile( centreSamples, 0.90 ) : median;
      var centreLift = centreMedian - median;
      var centrePeakLift = centrePeak - median;
      var globalLift = Math.max( p95 - median, (p99 - median) * 0.65 );
      var centralEvidence = Math.max( centreLift, centrePeakLift );

      // A bright star near the crop edge should not make an otherwise empty
      // catalogue hit look valid. Balanced and Strict require local evidence
      // around the catalogue centre; global contrast is only a weak tie-breaker.
      if ( this.config.visibilityMode == "Balanced" && centralEvidence < threshold * 0.45 )
      {
         object.visibilityScore = Math.max( centralEvidence, globalLift * 0.20 );
         return false;
      }
      if ( this.config.visibilityMode == "Strict" && centralEvidence < threshold * 0.70 )
      {
         object.visibilityScore = Math.max( centralEvidence, globalLift * 0.15 );
         return false;
      }

      var contrastScore = Math.max( centreLift * 1.35, centrePeakLift, globalLift * 0.18 );
      object.visibilityScore = contrastScore;
      return contrastScore >= threshold;
   };

   this.finalObjectSortRank = function( object, imageWindow )
   {
      var rank = {
         main: this.isMainObjectCandidate( object ) ? 0 : 1,
         primary: this.cataloguePriority( object.catalogueType ),
         secondary: object.displayId
      };

      if ( this.config.sortMode == "Visible size" )
      {
         rank.primary = -Math.round( object.patchSize ? object.patchSize : this.getPatchSize( object ) );
         rank.secondary = this.cataloguePriority( object.catalogueType ).toString() + ":" + object.displayId;
      }
      else if ( this.config.sortMode == "Image contrast" )
      {
         rank.primary = -Math.round( 1000 * (object.visibilityScore ? object.visibilityScore : 0) );
         rank.secondary = this.cataloguePriority( object.catalogueType ).toString() + ":" + object.displayId;
      }
      else if ( this.config.sortMode == "Distance from centre" )
      {
         var cx = imageWindow.mainView.image.width / 2;
         var cy = imageWindow.mainView.image.height / 2;
         var dx = object.px - cx;
         var dy = object.py - cy;
         rank.primary = Math.round( Math.sqrt( dx * dx + dy * dy ) );
         rank.secondary = this.cataloguePriority( object.catalogueType ).toString() + ":" + object.displayId;
      }
      else if ( this.config.sortMode == "Name" )
      {
         rank.primary = 0;
         rank.secondary = object.displayId;
      }
      else if ( this.config.sortMode == "Redshift" )
      {
         var distanceMly = this.redshiftDistanceMly( object.redshift );
         rank.primary = isNaN( distanceMly ) ? 999999999 : -Math.round( distanceMly * 10 );
         rank.secondary = this.cataloguePriority( object.catalogueType ).toString() + ":" + object.displayId;
      }
      else if ( this.config.sortMode == "Object class / colour" )
      {
         rank.primary = this.objectClassSortRank( object );
         rank.secondary = this.cataloguePriority( object.catalogueType ).toString() + ":" + object.displayId;
      }

      return rank;
   };

   this.gridTextX = function( graphics, x, tileWidth, text )
   {
      if ( this.config.previewLabelAlignment != "Centred" )
         return x;

      var width = 0;
      try
      {
         if ( graphics.font && graphics.font.width )
            width = graphics.font.width( text );
      }
      catch ( ex )
      {
         width = 0;
      }
      if ( width <= 0 )
         width = Math.round( text.length * 6 );
      return x + Math.max( 0, Math.round( (tileWidth - width) / 2 ) );
   };

   this.sortPatchesForOutput = function( patches, imageWindow )
   {
      patches.sort( function( a, b )
      {
         var ra = this.finalObjectSortRank( a.object, imageWindow );
         var rb = this.finalObjectSortRank( b.object, imageWindow );
         if ( ra.main != rb.main )
            return ra.main - rb.main;
         if ( ra.primary != rb.primary )
            return ra.primary - rb.primary;
         return ra.secondary < rb.secondary ? -1 : (ra.secondary > rb.secondary ? 1 : 0);
      }.bind( this ) );
      return patches;
   };

   this.collectPatchBitmaps = function( imageWindow, objects )
   {
      var patches = [];
      var skipped = 0;
      var createdIds = [];
      try
      {
         for ( var i = 0; i < objects.length; ++i )
         {
            var object = objects[i];
            var previewId = "SkyAnnotPatch_" + (i + 1).toString();
            var rect = new Rect( object.box.left, object.box.top, object.box.right, object.box.bottom );
            imageWindow.createPreview( rect, previewId );
            createdIds.push( previewId );

            var previewView = imageWindow.previewById( previewId );
            var patchBmp = this.getViewBitmap( previewView );
            if ( patchBmp.width != this.config.previewPatchSize || patchBmp.height != this.config.previewPatchSize )
               patchBmp = patchBmp.scaledTo( this.config.previewPatchSize, this.config.previewPatchSize );

            if ( !this.patchLooksVisible( patchBmp, object ) )
            {
               ++skipped;
               continue;
            }

            patches.push( { object: object, bitmap: patchBmp } );
         }
      }
      finally
      {
         for ( var j = 0; j < createdIds.length; ++j )
         {
            var preview = imageWindow.previewById( createdIds[j] );
            if ( preview && !preview.isNull )
               imageWindow.deletePreview( preview );
         }
      }

      if ( skipped > 0 )
         this.log( "Visibility filter removed " + skipped.toString() + " low-contrast preview patches." );

      return patches;
   };

   this.buildGridBitmapFromPatches = function( patches )
   {
      if ( patches.length == 0 )
         throw new Error( "No preview patches could be generated." );

      var tile = this.config.previewPatchSize;
      var topLabel = 34;
      var bottomLabel = 24;
      var gutter = 8;
      var margin = 8;
      var cols = Math.max( 1, Math.ceil( Math.sqrt( patches.length ) ) );
      var rows = Math.max( 1, Math.ceil( patches.length / cols ) );
      var cellHeight = topLabel + tile + bottomLabel;
      var width = margin * 2 + cols * tile + (cols - 1) * gutter;
      var height = margin * 2 + rows * cellHeight + (rows - 1) * gutter;
      var bmp = new Bitmap( width, height );
      bmp.fill( 0xff000000 );
      var g = new VectorGraphics( bmp );
      g.transparentBackground = true;
      g.antialiasing = true;
      g.font = new Font( "Helvetica", 10 );

      for ( var i = 0; i < patches.length; ++i )
      {
         var col = i % cols;
         var row = Math.floor( i / cols );
         var x = margin + col * (tile + gutter);
         var y = margin + row * (cellHeight + gutter);
         var patch = patches[i];
         var tileClassColor = this.config.colorCodeObjectClasses ? this.objectClassColor( patch.object ) : 0xff2d9cff;
         var numberText = (i + 1).toString();
         var labelText = this.truncateText( patch.object.displayId, this.labelMaxLength() );
         g.pen = new Pen( tileClassColor, 1 );
         g.drawText( this.gridTextX( g, x, tile, numberText ), y + 22, numberText );
         g.drawBitmap( x, y + topLabel, patch.bitmap );
         this.drawObjectClassRect( g, x, y + topLabel, x + tile, y + topLabel + tile, patch.object, 1, 0xffffffff );
         g.pen = new Pen( 0xffffffff, 1 );
         g.drawText( this.gridTextX( g, x, tile, labelText ), y + topLabel + tile + 18, labelText );
      }
      g.end();
      return bmp;
   };

   this.buildGridBitmap = function( imageWindow, objects )
   {
      return this.buildGridBitmapFromPatches( this.collectPatchBitmaps( imageWindow, objects ) );
   };

   this.buildFinalCompositeBitmap = function( overviewBitmap, gridBitmap )
   {
      var scaledGrid = gridBitmap;
      if ( gridBitmap.width != overviewBitmap.width )
      {
         var scaledHeight = Math.max( 1, Math.round( gridBitmap.height * overviewBitmap.width / gridBitmap.width ) );
         scaledGrid = gridBitmap.scaledTo( overviewBitmap.width, scaledHeight );
      }

      var descriptionLines = this.config.showTopDescriptions ? this.topObjectDescriptionLines( this.currentDescriptionObjects ? this.currentDescriptionObjects : [] ) : [];
      var legendItems = this.objectClassLegend();
      var legendHeight = 64;
      var footerHeight = (descriptionLines.length > 0 ? 34 + descriptionLines.length * 22 : 0) + legendHeight;
      var finalBmp = new Bitmap( overviewBitmap.width, overviewBitmap.height + scaledGrid.height + footerHeight );
      finalBmp.fill( 0xff000000 );
      var g = new VectorGraphics( finalBmp );
      g.drawBitmap( 0, 0, overviewBitmap );
      g.drawBitmap( 0, overviewBitmap.height, scaledGrid );
      var footerY = overviewBitmap.height + scaledGrid.height;
      if ( legendItems.length > 0 )
      {
         g.pen = new Pen( 0xff2d9cff, 1 );
         g.font = new Font( "Helvetica", 11 );
         g.drawText( 18, footerY + 22, "Object colour legend" );
         g.font = new Font( "Helvetica", 9 );
         var xLegend = 18;
         var yLegend = footerY + 48;
         for ( var li = 0; li < legendItems.length; ++li )
         {
            g.pen = new Pen( legendItems[li].color, 1 );
            g.drawRect( xLegend, yLegend - 10, xLegend + 16, yLegend + 6 );
            g.fillRect( xLegend + 1, yLegend - 9, xLegend + 15, yLegend + 5, new Brush( legendItems[li].color ) );
            g.pen = new Pen( 0xffffffff, 1 );
            g.drawText( xLegend + 22, yLegend + 4, legendItems[li].label );
            xLegend += Math.max( 170, legendItems[li].label.length * 8 + 42 );
         }
         footerY += legendHeight;
      }
      if ( descriptionLines.length > 0 )
      {
         g.pen = new Pen( 0xff2d9cff, 1 );
         g.font = new Font( "Helvetica", 11 );
         g.drawText( 18, footerY + 24, "Top object notes" );
         g.pen = new Pen( 0xffffffff, 1 );
         g.font = new Font( "Helvetica", 9 );
         for ( var d = 0; d < descriptionLines.length; ++d )
            g.drawText( 18, footerY + 50 + d * 22, descriptionLines[d] );
      }
      g.end();
      return finalBmp;
   };

   this.objectIdentifierText = function( object )
   {
      return (object.displayId + " " + object.mainId + " " + object.ids).toUpperCase();
   };

   this.knownObjectDescription = function( object )
   {
      var id = this.objectIdentifierText( object );
      if ( id.indexOf( "M 81" ) >= 0 || id.indexOf( "M81" ) >= 0 || id.indexOf( "BODE" ) >= 0 || id.indexOf( "NGC 3031" ) >= 0 )
         return "M81 Galaxy, also known as Bode's Galaxy, is a grand-design spiral galaxy approximately 12 million light-years away in the constellation Ursa Major.";
      if ( id.indexOf( "M 82" ) >= 0 || id.indexOf( "M82" ) >= 0 || id.indexOf( "CIGAR" ) >= 0 || id.indexOf( "NGC 3034" ) >= 0 )
         return "M82 Galaxy, Messier 82, is a starburst galaxy approximately 12 million light-years away in the constellation Ursa Major, with strong dust lanes and active central star formation.";
      if ( id.indexOf( "NGC 3077" ) >= 0 )
         return "NGC 3077 is a disrupted dwarf galaxy in the M81 Group, shaped by gravitational interaction with M81 and M82.";
      if ( id.indexOf( "NGC 2976" ) >= 0 )
         return "NGC 2976 is a nearby spiral galaxy in the M81 Group, roughly 11 to 12 million light-years away in the constellation Ursa Major.";
      if ( id.indexOf( "NGC 2959" ) >= 0 )
         return "NGC 2959 is a compact galaxy in the Ursa Major field, visible here as a bright, rounded background system.";
      if ( id.indexOf( "NGC 2961" ) >= 0 )
         return "NGC 2961 is a galaxy in the Ursa Major field, visible here as an elongated background galaxy near NGC 2959.";
      if ( id.indexOf( "UGC 5302" ) >= 0 )
         return "UGC 5302 is an edge-on galaxy in the M81 field, visible as a thin, elongated system crossing the background sky.";
      if ( id.indexOf( "MCG+12-09-064" ) >= 0 || id.indexOf( "MCG +12-09-064" ) >= 0 )
         return "MCG+12-09-064 is an edge-on background galaxy with a long, narrow profile, making it stand out clearly in the M81 field.";
      return "";
   };

   this.objectDetailSuffix = function( object )
   {
      var parts = [];
      if ( !isNaN( object.majorAxisArcmin ) && object.majorAxisArcmin > 0 )
         parts.push( "catalogued major axis about " + format( "%.1f", object.majorAxisArcmin ) + "'" );
      if ( this.config.includeRedshift && !isNaN( object.redshift ) )
         parts.push( "z=" + format( "%.5f", object.redshift ) );
      if ( parts.length == 0 )
         return "";
      return " (" + parts.join( ", " ) + ")";
   };

   this.genericObjectDescription = function( object )
   {
      if ( this.isMainObjectCandidate( object ) )
         return object.displayId + " is the configured main target and the visual anchor of this annotation field.";
      if ( object.catalogueType == "M" )
         return object.displayId + " is a Messier catalogue galaxy or deep-sky object highlighted as one of the most prominent objects in this field.";
      if ( object.catalogueType == "NGC" || object.catalogueType == "IC" )
         return object.displayId + " is a classic " + object.catalogueType + " catalogue object selected as one of the clearest visible targets in the frame.";
      if ( this.isQuasarLikeObject( object ) )
         return object.displayId + " is an active-galaxy or quasar-like catalogue entry selected from the SIMBAD query.";
      return object.displayId + " is a selected " + object.catalogueType + " catalogue object with a measured preview visibility score of " + format( "%.1f", object.visibilityScore ) + ".";
   };

   this.topObjectDescriptionLines = function( objects )
   {
      var lines = [];
      var count = Math.min( 5, objects.length );
      for ( var i = 0; i < count; ++i )
      {
         var o = objects[i];
         var description = this.knownObjectDescription( o );
         if ( description.length == 0 )
            description = this.genericObjectDescription( o ) + this.objectDetailSuffix( o );
         lines.push( this.truncateText( "Object " + (i + 1).toString() + ": " + description, 230 ) );
      }
      return lines;
   };

   this.exportCsv = function( objects, filePath )
   {
      var lines = ["index,keep,display_id,main_id,catalogue_type,ra_deg,dec_deg,redshift,major_axis_arcmin,minor_axis_arcmin,px,py,patch_size,visibility_score"];
      for ( var i = 0; i < objects.length; ++i )
      {
         var o = objects[i];
         lines.push(
            (i + 1).toString() + "," +
            ((o.keep === false) ? "false" : "true") + "," +
            "\"" + o.displayId.replace( /"/g, "\"\"" ) + "\"," +
            "\"" + o.mainId.replace( /"/g, "\"\"" ) + "\"," +
            o.catalogueType + "," +
            format( "%.10f", o.ra ) + "," +
            format( "%.10f", o.dec ) + "," +
            (isNaN( o.redshift ) ? "" : format( "%.8f", o.redshift )) + "," +
            (isNaN( o.majorAxisArcmin ) ? "" : format( "%.4f", o.majorAxisArcmin )) + "," +
            (isNaN( o.minorAxisArcmin ) ? "" : format( "%.4f", o.minorAxisArcmin )) + "," +
            format( "%.2f", o.px ) + "," +
            format( "%.2f", o.py ) + "," +
            format( "%.0f", o.patchSize ? o.patchSize : 0 ) + "," +
            format( "%.3f", o.visibilityScore ? o.visibilityScore : 0 )
         );
      }
      File.writeTextFile( filePath, lines.join( "\n" ) );
   };

   this.exportHtmlReport = function( objects, filePath )
   {
      var html = [];
      html.push( "<!doctype html><html><head><meta charset=\"utf-8\"><title>Sky Annotation Studio Report</title>" );
      html.push( "<style>body{font-family:Segoe UI,Arial,sans-serif;background:#0b1220;color:#e5eefc}table{border-collapse:collapse;width:100%}td,th{border:1px solid #2b3b55;padding:6px}th{background:#16243a}tr:nth-child(even){background:#101a2b}</style></head><body>" );
      html.push( "<h1>Sky Annotation Studio Report</h1><table><tr><th>#</th><th>Keep</th><th>Display ID</th><th>Main ID</th><th>Catalogue</th><th>RA</th><th>Dec</th><th>Redshift</th><th>Major axis</th><th>Patch</th><th>Visibility</th></tr>" );
      for ( var i = 0; i < objects.length; ++i )
      {
         var o = objects[i];
         html.push( "<tr><td>" + (i + 1).toString() + "</td><td>" + ((o.keep === false) ? "No" : "Yes") +
            "</td><td>" + o.displayId + "</td><td>" + o.mainId + "</td><td>" + o.catalogueType +
            "</td><td>" + format( "%.6f", o.ra ) + "</td><td>" + format( "%.6f", o.dec ) +
            "</td><td>" + (isNaN( o.redshift ) ? "" : format( "%.5f", o.redshift )) +
            "</td><td>" + (isNaN( o.majorAxisArcmin ) ? "" : format( "%.2f'", o.majorAxisArcmin )) +
            "</td><td>" + format( "%.0f", o.patchSize ? o.patchSize : 0 ) +
            "</td><td>" + format( "%.2f", o.visibilityScore ? o.visibilityScore : 0 ) + "</td></tr>" );
      }
      html.push( "</table></body></html>" );
      File.writeTextFile( filePath, html.join( "\n" ) );
   };

   this.renderFromPatches = function( patches )
   {
      if ( patches.length == 0 )
         throw new Error( "No kept preview patches are available to render." );

      var opened = this.currentWindow();
      try
      {
         var objects = [];
         for ( var i = 0; i < patches.length; ++i )
            objects.push( patches[i].object );

         this.log( "Rendering curated output from " + objects.length.toString() + " kept objects..." );
         var overviewBitmap = this.renderAnnotatedBitmap( opened.window, objects );
         var gridBitmap = this.buildGridBitmapFromPatches( patches );
         this.currentDescriptionObjects = objects;
         var finalBitmap = this.buildFinalCompositeBitmap( overviewBitmap, gridBitmap );
         this.currentDescriptionObjects = null;

         var overviewWindow = this.bitmapToWindow( overviewBitmap, opened.window, opened.window.mainView.id + "_SkyAnnotOverview" );
         var gridWindow = this.bitmapToWindow( gridBitmap, opened.window, opened.window.mainView.id + "_SkyAnnotGrid" );
         var finalWindow = this.bitmapToWindow( finalBitmap, opened.window, opened.window.mainView.id + "_SkyAnnotFinal" );
         this.log( "Created curated overview, grid, and final composite windows." );
         return {
            objects: objects,
            patches: patches,
            sourceWindow: opened.window,
            overviewBitmap: overviewBitmap,
            gridBitmap: gridBitmap,
            finalBitmap: finalBitmap,
            overviewWindow: overviewWindow,
            gridWindow: gridWindow,
            finalWindow: finalWindow
         };
      }
      finally
      {
         if ( opened.temporary )
            opened.window.forceClose();
      }
   };

   this.run = function()
   {
      var opened = this.currentWindow();
      try
      {
         this.log( "Extracting astrometric metadata..." );
         var metadata = opened.metadata ? opened.metadata : this.extractMetadata( opened.window );
         this.log( "Image centre: RA " + format( "%.6f", metadata.ra ) + " deg, Dec " + format( "%.6f", metadata.dec ) + " deg" );

         var rawRows = this.querySimbad( metadata );
         this.log( "SIMBAD rows: " + rawRows.length.toString() );

         var objects = this.groupRows( rawRows );
         objects = this.filterObjects( objects );
         objects = this.projectObjects( metadata, objects );
         objects = this.dedupeFamilies( objects );
         objects = this.sortObjects( objects );
         this.log( "Objects kept after filtering and deduplication: " + objects.length.toString() );

         if ( objects.length == 0 )
            throw new Error( "No matching catalogue objects were found inside the image bounds." );

         var acceptedObjects = this.chooseAcceptedObjects( opened.window, objects );
         if ( acceptedObjects.length > this.config.maxObjects )
            acceptedObjects = acceptedObjects.slice( 0, this.config.maxObjects );
         this.log( "Objects kept after crop validation: " + acceptedObjects.length.toString() );
         if ( acceptedObjects.length == 0 )
            throw new Error( "Objects were found, but none could be cropped safely inside the image bounds." );

         this.log( "Building preview grid..." );
         var patches = this.collectPatchBitmaps( opened.window, acceptedObjects );
         if ( patches.length == 0 )
            throw new Error( "Objects were found, but no visible preview patches could be generated." );

         patches = this.sortPatchesForOutput( patches, opened.window );
         acceptedObjects = [];
         for ( var patchIndex = 0; patchIndex < patches.length; ++patchIndex )
            acceptedObjects.push( patches[patchIndex].object );

         this.log( "Objects kept after visibility filtering: " + acceptedObjects.length.toString() );
         this.log( "Output sort mode: " + this.config.sortMode +
            "; visibility filter: " + this.config.visibilityMode +
            "; object type: " + this.config.objectTypeMode +
            "; catalogue priority: " + this.config.cataloguePriorityMode +
            "; SIMBAD size crops: " + (this.config.useSimbadObjectSize ? "on" : "off") + "." );
         this.log( "Rendering annotated overview..." );
         var overviewBitmap = this.renderAnnotatedBitmap( opened.window, acceptedObjects );
         var gridBitmap = this.buildGridBitmapFromPatches( patches );
         this.log( "Composing final stacked output..." );
         this.currentDescriptionObjects = acceptedObjects;
         var finalBitmap = this.buildFinalCompositeBitmap( overviewBitmap, gridBitmap );
         this.currentDescriptionObjects = null;

         var overviewWindow = this.bitmapToWindow( overviewBitmap, opened.window, opened.window.mainView.id + "_SkyAnnotOverview" );
         var gridWindow = this.bitmapToWindow( gridBitmap, opened.window, opened.window.mainView.id + "_SkyAnnotGrid" );
         var finalWindow = this.bitmapToWindow( finalBitmap, opened.window, opened.window.mainView.id + "_SkyAnnotFinal" );
         this.log( "Created overview, grid, and final composite windows." );

         return {
         objects: acceptedObjects,
         patches: patches,
         sourceWindow: opened.window,
         overviewBitmap: overviewBitmap,
         gridBitmap: gridBitmap,
         finalBitmap: finalBitmap,
            overviewWindow: overviewWindow,
            gridWindow: gridWindow,
            finalWindow: finalWindow
         };
      }
      finally
      {
         if ( opened.temporary )
            opened.window.forceClose();
      }
   };
}

function SkyAnnotationDialog()
{
   this.__base__ = Dialog;
   this.__base__();

   var dialog = this;
   this.config = new SkyAnnotationConfig();
   this.resultObjects = [];
   this.resultPatches = [];
   this.lastResult = null;
   this.selectedPreviewBitmap = null;
   this.selectedContextBitmap = null;
   this.selectedObject = null;
   this.selectedPreviewTitle = "Select a result row to inspect its crop.";
   this.autoReviewIndex = -1;
   this.autoReviewRunning = false;
   this.autoReviewBusy = false;
   this.autoReviewStopRequested = false;
   this.autoReviewTimer = new Timer;
   if ( this.config.autoReviewDelayMs == 900 )
      this.config.autoReviewDelayMs = 150;
   if ( this.config.autoReviewDelayMs < 150 )
      this.config.autoReviewDelayMs = 150;
   this.autoReviewTimer.interval = this.config.autoReviewDelayMs / 1000.0;
   this.autoReviewTimer.periodic = false;
   this.autoReviewTimer.dialog = this;
   this.autoReviewTimer.onTimeout = function()
   {
      this.dialog.autoReviewTimer.stop();
      if ( typeof processEvents == "function" )
         processEvents();
      if ( this.dialog.autoReviewRunning && !this.dialog.autoReviewStopRequested )
      {
         this.dialog.advanceAutoReview();
         if ( typeof processEvents == "function" )
            processEvents();
         if ( this.dialog.autoReviewRunning && !this.dialog.autoReviewStopRequested )
            this.dialog.autoReviewTimer.start();
      }
   };
   this.autoReviewTimer.stop();

   this.presetNames = [
      "Galaxy field", "Widefield", "Messier target", "Deep field",
      "Messier showcase", "NGC/IC showcase", "Deep survey", "Minimal clean labels"
   ];
   this.builtInPresetCount = this.presetNames.length;
   this.processingSettingFields = [
      "filterPrefixes", "labelMode", "labelLengthMode", "objectTypeMode",
      "cataloguePriorityMode", "useSimbadObjectSize", "boxSize", "patchScale",
      "previewPatchSize", "maxObjects", "sortMode", "previewLabelAlignment", "visibilityMode",
      "outputMode", "showTopDescriptions", "highlightShowcaseObjects",
      "colorCodeObjectClasses", "autoTitle", "includeRedshift", "manualCuration",
      "autoReviewDelayMs"
   ];

   this.presetSettingsKey = function( name )
   {
      return SETTINGS_MODULE + "/preset/" + name.replace( /\s+/g, "_" );
   };

   this.safeSettingsRead = function( key, type )
   {
      if ( typeof Settings == "undefined" )
         return null;
      try
      {
         return Settings.read( key, type );
      }
      catch ( ex )
      {
         return null;
      }
   };

   this.safeSettingsWrite = function( key, type, value )
   {
      if ( typeof Settings == "undefined" )
         return;
      try
      {
         Settings.write( key, type, value );
      }
      catch ( ex )
      {
      }
   };

   this.loadPresetNameList = function()
   {
      var payload = this.safeSettingsRead( SETTINGS_MODULE + "/presetNames", DataType_UCString );
      if ( payload != null && payload.length > 0 )
      {
         var extra = payload.split( "\n" );
         for ( var i = 0; i < extra.length; ++i )
         {
            var name = extra[i].replace( /^\s+|\s+$/g, "" );
            if ( name.length > 0 && this.presetNames.indexOf( name ) < 0 )
               this.presetNames.push( name );
         }
      }
   };

   this.savePresetNameList = function()
   {
      var custom = [];
      for ( var i = 0; i < this.presetNames.length; ++i )
         if ( i >= this.builtInPresetCount )
            custom.push( this.presetNames[i] );
      this.safeSettingsWrite( SETTINGS_MODULE + "/presetNames", DataType_UCString, custom.join( "\n" ) );
   };

   this.builtInPreset = function( name )
   {
      var p = {};
      p.filterPrefixes = this.config.filterPrefixes.slice( 0 );
      p.labelMode = "Numbers";
      p.labelLengthMode = "Medium";
      p.objectTypeMode = "Galaxies only";
      p.cataloguePriorityMode = "Prefer Messier";
      p.useSimbadObjectSize = false;
      p.boxSize = 96;
      p.patchScale = 1.0;
      p.previewPatchSize = 256;
      p.maxObjects = 500;
      p.sortMode = "Visible size";
      p.previewLabelAlignment = "Left";
      p.visibilityMode = "Balanced";
      p.outputMode = "Showcase";
      p.showTopDescriptions = false;
      p.highlightShowcaseObjects = true;
      p.colorCodeObjectClasses = false;
      p.autoTitle = false;
      p.includeRedshift = false;
      p.manualCuration = false;
      p.autoReviewDelayMs = 100;

      if ( name == "Widefield" )
      {
         p.boxSize = 80;
         p.patchScale = 0.90;
         p.maxObjects = 350;
         p.sortMode = "Distance from centre";
      }
      else if ( name == "Messier target" )
      {
         p.boxSize = 112;
         p.patchScale = 1.15;
         p.maxObjects = 300;
         p.cataloguePriorityMode = "Prefer Messier";
         p.visibilityMode = "Permissive";
         p.useSimbadObjectSize = true;
      }
      else if ( name == "Deep field" )
      {
         p.boxSize = 72;
         p.patchScale = 0.90;
         p.previewPatchSize = 192;
         p.maxObjects = 900;
         p.objectTypeMode = "Galaxies, quasars off";
         p.cataloguePriorityMode = "Known catalogues first";
         p.sortMode = "Image contrast";
         p.visibilityMode = "Strict";
      }
      else if ( name == "Messier showcase" )
      {
         p.boxSize = 118;
         p.patchScale = 1.20;
         p.maxObjects = 260;
         p.sortMode = "Visible size";
         p.visibilityMode = "Balanced";
         p.cataloguePriorityMode = "Prefer Messier";
         p.objectTypeMode = "Galaxies only";
         p.useSimbadObjectSize = true;
         p.outputMode = "Showcase";
         p.showTopDescriptions = true;
         p.highlightShowcaseObjects = true;
      }
      else if ( name == "NGC/IC showcase" )
      {
         p.boxSize = 108;
         p.patchScale = 1.12;
         p.maxObjects = 320;
         p.sortMode = "Visible size";
         p.visibilityMode = "Balanced";
         p.cataloguePriorityMode = "Prefer NGC/IC";
         p.objectTypeMode = "Galaxies, quasars off";
         p.useSimbadObjectSize = true;
         p.outputMode = "Showcase";
         p.highlightShowcaseObjects = true;
      }
      else if ( name == "Deep survey" )
      {
         p.boxSize = 72;
         p.patchScale = 0.95;
         p.previewPatchSize = 192;
         p.maxObjects = 1000;
         p.sortMode = "Redshift";
         p.visibilityMode = "Strict";
         p.cataloguePriorityMode = "Known catalogues first";
         p.objectTypeMode = "Galaxies, quasars off";
         p.outputMode = "Showcase";
         p.showTopDescriptions = true;
         p.includeRedshift = true;
      }
      else if ( name == "Minimal clean labels" )
      {
         p.boxSize = 100;
         p.patchScale = 1.05;
         p.maxObjects = 220;
         p.sortMode = "Visible size";
         p.visibilityMode = "Strict";
         p.labelMode = "Numbers";
         p.labelLengthMode = "Short";
         p.cataloguePriorityMode = "Known catalogues first";
         p.objectTypeMode = "Known galaxies priority";
         p.outputMode = "Poster";
         p.highlightShowcaseObjects = true;
      }
      return p;
   };

   this.encodePreset = function()
   {
      var parts = [];
      for ( var i = 0; i < this.processingSettingFields.length; ++i )
      {
         var key = this.processingSettingFields[i];
         var value = this.config[key];
         if ( value instanceof Array )
            value = value.join( "," );
         parts.push( key + "=" + encodeURIComponent( value.toString() ) );
      }
      return parts.join( "\n" );
   };

   this.decodePreset = function( payload )
   {
      var values = {};
      if ( payload == null || payload.length == 0 )
         return values;
      var lines = payload.replace( /\r/g, "" ).split( "\n" );
      for ( var i = 0; i < lines.length; ++i )
      {
         var eq = lines[i].indexOf( "=" );
         if ( eq <= 0 )
            continue;
         values[lines[i].substr( 0, eq )] = decodeURIComponent( lines[i].substr( eq + 1 ) );
      }
      return values;
   };

   this.applyPresetValues = function( values )
   {
      for ( var i = 0; i < this.processingSettingFields.length; ++i )
      {
         var key = this.processingSettingFields[i];
         if ( values[key] == null )
            continue;
         var value = values[key];
         if ( key == "filterPrefixes" )
            this.config[key] = value instanceof Array ? value.slice( 0 ) : value.split( "," );
         else if ( key == "boxSize" || key == "patchScale" )
            this.config[key] = parseFloat( value );
         else if ( key == "previewPatchSize" || key == "maxObjects" || key == "autoReviewDelayMs" )
            this.config[key] = parseInt( value, 10 );
         else if ( key == "useSimbadObjectSize" )
            this.config[key] = value === true || value == "true";
         else if ( key == "showTopDescriptions" || key == "highlightShowcaseObjects" ||
                   key == "colorCodeObjectClasses" || key == "autoTitle" ||
                   key == "includeRedshift" || key == "manualCuration" )
            this.config[key] = value === true || value == "true";
         else
            this.config[key] = value;
      }
   };

   this.applySelectedPreset = function()
   {
      var name = this.presetNames[this.presetCombo.currentItem];
      var payload = this.safeSettingsRead( this.presetSettingsKey( name ), DataType_UCString );
      var values = payload != null && payload.length > 0 ? this.decodePreset( payload ) : this.builtInPreset( name );
      this.applyPresetValues( values );
      this.config.presetName = name;
      this.syncConfigToControls();
      this.appendLog( "Applied preset: " + name + "." );
   };

   this.saveSelectedPreset = function()
   {
      var name = this.presetNameEdit.text.replace( /^\s+|\s+$/g, "" );
      if ( name.length == 0 )
         name = this.presetNames[this.presetCombo.currentItem];
      if ( this.presetNames.indexOf( name ) < 0 )
      {
         this.presetNames.push( name );
         this.presetCombo.addItem( name );
         this.savePresetNameList();
      }
      this.safeSettingsWrite( this.presetSettingsKey( name ), DataType_UCString, this.encodePreset() );
      this.config.presetName = name;
      this.presetCombo.currentItem = Math.max( 0, this.presetNames.indexOf( name ) );
      this.appendLog( "Saved preset: " + name + "." );
   };

   this.loadPresetNameList();

   this.presetLabel = new Label( this );
   this.presetLabel.text = "Preset";
   this.presetLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.presetLabel.minWidth = 120;
   this.presetLabel.toolTip =
      "Apply or save reusable processing settings. Presets do not change the current source image, main object, or title.";

   this.presetCombo = new ComboBox( this );
   for ( var presetIndex = 0; presetIndex < this.presetNames.length; ++presetIndex )
      this.presetCombo.addItem( this.presetNames[presetIndex] );
   this.presetCombo.currentItem = Math.max( 0, this.presetNames.indexOf( this.config.presetName ) );
   this.presetCombo.toolTip = this.presetLabel.toolTip;
   this.presetCombo.onItemSelected = function( index )
   {
      this.dialog.config.presetName = this.dialog.presetNames[index];
      this.dialog.presetNameEdit.text = this.dialog.presetNames[index];
   };

   this.presetNameEdit = new Edit( this );
   this.presetNameEdit.text = this.config.presetName;
   this.presetNameEdit.toolTip = "Preset name to apply or save. Type a new name, then click Save preset to create a custom preset.";
   this.presetNameEdit.onTextUpdated = function( value )
   {
      this.dialog.config.presetName = value;
   };

   this.applyPresetButton = new PushButton( this );
   this.applyPresetButton.text = "Apply preset";
   this.applyPresetButton.toolTip = "Load the selected preset into the processing controls.";
   this.applyPresetButton.onClick = function()
   {
      this.dialog.applySelectedPreset();
   };

   this.savePresetButton = new PushButton( this );
   this.savePresetButton.text = "Save preset";
   this.savePresetButton.toolTip = "Save the current processing controls into the selected preset slot.";
   this.savePresetButton.onClick = function()
   {
      this.dialog.saveSelectedPreset();
   };

   this.windowModeLabel = new Label( this );
   this.windowModeLabel.text = "Source";
   this.windowModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.windowModeLabel.minWidth = 120;
   this.windowModeLabel.toolTip =
      "Choose whether the script annotates the currently active PixInsight image or opens a FITS/XISF file from disk.";

   this.windowModeCombo = new ComboBox( this );
   this.windowModeCombo.addItem( "Active image" );
   this.windowModeCombo.addItem( "File on disk" );
   this.windowModeCombo.currentItem = this.config.useActiveWindow ? 0 : 1;
   this.windowModeCombo.toolTip = this.windowModeLabel.toolTip;
   this.windowModeCombo.onItemSelected = function( index )
   {
      this.dialog.config.useActiveWindow = index == 0;
      this.dialog.inputFileEdit.enabled = index != 0;
      this.dialog.inputFileButton.enabled = index != 0;
   };

   this.inputFileLabel = new Label( this );
   this.inputFileLabel.text = "FITS/XISF file";
   this.inputFileLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.inputFileLabel.minWidth = 120;
   this.inputFileLabel.toolTip =
      "Optional source image path when Source is set to File on disk. The image must have a valid astrometric solution.";

   this.inputFileEdit = new Edit( this );
   this.inputFileEdit.text = this.config.inputFile;
   this.inputFileEdit.enabled = !this.config.useActiveWindow;
   this.inputFileEdit.toolTip = this.inputFileLabel.toolTip;
   this.inputFileEdit.onTextUpdated = function( value )
   {
      this.dialog.config.inputFile = value;
   };

   this.inputFileButton = new PushButton( this );
   this.inputFileButton.text = "Browse";
   this.inputFileButton.enabled = !this.config.useActiveWindow;
   this.inputFileButton.toolTip = "Browse for a solved FITS, FIT, or XISF image file.";
   this.inputFileButton.onClick = function()
   {
      var ofd = new OpenFileDialog();
      ofd.multipleSelections = false;
      ofd.filters = [ [ "Astro images", ".fit", ".fits", ".xisf" ] ];
      if ( ofd.execute() )
      {
         this.dialog.inputFileEdit.text = ofd.fileName;
         this.dialog.config.inputFile = ofd.fileName;
      }
   };

   this.mainObjectLabel = new Label( this );
   this.mainObjectLabel.text = "Main object";
   this.mainObjectLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.mainObjectLabel.minWidth = 120;
   this.mainObjectLabel.toolTip =
      "Preferred primary object, for example M81. Matching objects are sorted first and receive the largest crop by default.";

   this.mainObjectEdit = new Edit( this );
   this.mainObjectEdit.text = this.config.mainObject;
   this.mainObjectEdit.toolTip = this.mainObjectLabel.toolTip;
   this.mainObjectEdit.onTextUpdated = function( value )
   {
      this.dialog.config.mainObject = value;
   };

   this.titleLabel = new Label( this );
   this.titleLabel.text = "Title";
   this.titleLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.titleLabel.minWidth = 120;
   this.titleLabel.toolTip = "Title drawn at the top of the annotated overview image.";

   this.titleEdit = new Edit( this );
   this.titleEdit.text = this.config.photoTitle;
   this.titleEdit.toolTip = this.titleLabel.toolTip;
   this.titleEdit.onTextUpdated = function( value )
   {
      this.dialog.config.photoTitle = value;
   };

   this.filterLabel = new Label( this );
   this.filterLabel.text = "Catalogue filters";
   this.filterLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.filterLabel.minWidth = 120;
   this.filterLabel.toolTip =
      "Comma-separated catalogue/type prefixes to keep. Remove very deep catalogues such as SDSS or Gaia if you want fewer faint candidates.";

   this.filterEdit = new Edit( this );
   this.filterEdit.text = this.config.filterPrefixes.join( "," );
   this.filterEdit.toolTip = this.filterLabel.toolTip;
   this.filterEdit.onTextUpdated = function( value )
   {
      var parts = value.split( /[,|]/ );
      var list = [];
      for ( var i = 0; i < parts.length; ++i )
      {
         var token = parts[i].replace( /^\s+|\s+$/g, "" );
         if ( token.length > 0 )
            list.push( token );
      }
      this.dialog.config.filterPrefixes = list;
   };

   this.labelModeLabel = new Label( this );
   this.labelModeLabel.text = "Label mode";
   this.labelModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.labelModeLabel.minWidth = 120;
   this.labelModeLabel.toolTip =
      "Controls text drawn next to boxes: compact numbers, object identifiers, or both.";

   this.labelModeCombo = new ComboBox( this );
   this.labelModeCombo.addItem( "Numbers" );
   this.labelModeCombo.addItem( "Object IDs" );
   this.labelModeCombo.addItem( "Numbers + IDs" );
   this.labelModeCombo.currentItem = this.config.labelMode == "Object IDs" ? 1 : (this.config.labelMode == "Numbers + IDs" ? 2 : 0);
   this.labelModeCombo.toolTip = this.labelModeLabel.toolTip;
   this.labelModeCombo.onItemSelected = function( index )
   {
      this.dialog.config.labelMode = index == 1 ? "Object IDs" : (index == 2 ? "Numbers + IDs" : "Numbers");
   };

   this.labelLengthLabel = new Label( this );
   this.labelLengthLabel.text = "Label length";
   this.labelLengthLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.labelLengthLabel.minWidth = 120;
   this.labelLengthLabel.toolTip =
      "Controls the object name length printed below preview tiles. Short keeps the grid compact, Medium matches the classic 20-character trim, Full keeps complete object names.";

   this.labelLengthCombo = new ComboBox( this );
   this.labelLengthCombo.addItem( "Short" );
   this.labelLengthCombo.addItem( "Medium" );
   this.labelLengthCombo.addItem( "Full" );
   var labelLengthModes = [ "Short", "Medium", "Full" ];
   this.labelLengthCombo.currentItem = Math.max( 0, labelLengthModes.indexOf( this.config.labelLengthMode ) );
   this.labelLengthCombo.toolTip = this.labelLengthLabel.toolTip;
   this.labelLengthCombo.onItemSelected = function( index )
   {
      this.dialog.config.labelLengthMode = labelLengthModes[index];
   };

   this.previewLabelAlignmentLabel = new Label( this );
   this.previewLabelAlignmentLabel.text = "Preview label alignment";
   this.previewLabelAlignmentLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.previewLabelAlignmentLabel.minWidth = 120;
   this.previewLabelAlignmentLabel.toolTip =
      "Controls where the preview-grid number and object name are drawn inside each tile. Left matches the classic layout; Centred gives a cleaner poster-like grid.";

   this.previewLabelAlignmentCombo = new ComboBox( this );
   this.previewLabelAlignmentCombo.addItem( "Left" );
   this.previewLabelAlignmentCombo.addItem( "Centred" );
   var previewLabelAlignmentModes = [ "Left", "Centred" ];
   this.previewLabelAlignmentCombo.currentItem = Math.max( 0, previewLabelAlignmentModes.indexOf( this.config.previewLabelAlignment ) );
   this.previewLabelAlignmentCombo.toolTip = this.previewLabelAlignmentLabel.toolTip;
   this.previewLabelAlignmentCombo.onItemSelected = function( index )
   {
      this.dialog.config.previewLabelAlignment = previewLabelAlignmentModes[index];
   };

   this.boxSizeLabel = new Label( this );
   this.boxSizeLabel.text = "Box size";
   this.boxSizeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.boxSizeLabel.minWidth = 120;
   this.boxSizeLabel.toolTip =
      "Base crop size in source pixels. Catalogue type multipliers are applied on top of this, so larger values zoom out every generated object crop.";

   this.boxSizeSpin = new SpinBox( this );
   this.boxSizeSpin.minValue = 24;
   this.boxSizeSpin.maxValue = 1024;
   this.boxSizeSpin.value = Math.round( this.config.boxSize );
   this.boxSizeSpin.toolTip = this.boxSizeLabel.toolTip;
   this.boxSizeSpin.onValueUpdated = function( value )
   {
      this.dialog.config.boxSize = value;
   };

   this.patchScaleLabel = new Label( this );
   this.patchScaleLabel.text = "Patch scale %";
   this.patchScaleLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.patchScaleLabel.minWidth = 120;
   this.patchScaleLabel.toolTip =
      "Global crop scale after catalogue sizing. 100% preserves the automatic crop, lower values zoom in, higher values zoom out.";

   this.patchScaleSpin = new SpinBox( this );
   this.patchScaleSpin.minValue = 25;
   this.patchScaleSpin.maxValue = 400;
   this.patchScaleSpin.value = Math.round( this.config.patchScale * 100 );
   this.patchScaleSpin.toolTip = this.patchScaleLabel.toolTip;
   this.patchScaleSpin.onValueUpdated = function( value )
   {
      this.dialog.config.patchScale = value / 100;
   };

   this.previewPatchSizeLabel = new Label( this );
   this.previewPatchSizeLabel.text = "Preview patch";
   this.previewPatchSizeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.previewPatchSizeLabel.minWidth = 120;
   this.previewPatchSizeLabel.toolTip =
      "Rendered grid tile size in pixels. This changes output resolution/detail, not the sky area selected for each object.";

   this.previewPatchSizeSpin = new SpinBox( this );
   this.previewPatchSizeSpin.minValue = 64;
   this.previewPatchSizeSpin.maxValue = 1024;
   this.previewPatchSizeSpin.value = this.config.previewPatchSize;
   this.previewPatchSizeSpin.toolTip = this.previewPatchSizeLabel.toolTip;
   this.previewPatchSizeSpin.onValueUpdated = function( value )
   {
      this.dialog.config.previewPatchSize = value;
   };

   this.maxObjectsLabel = new Label( this );
   this.maxObjectsLabel.text = "Max rows";
   this.maxObjectsLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.maxObjectsLabel.minWidth = 120;
   this.maxObjectsLabel.toolTip =
      "Maximum number of visible preview rows kept after filtering. Higher values search deeper, but can include many faint catalogue-only objects.";

   this.maxObjectsSpin = new SpinBox( this );
   this.maxObjectsSpin.minValue = 50;
   this.maxObjectsSpin.maxValue = 5000;
   this.maxObjectsSpin.value = this.config.maxObjects;
   this.maxObjectsSpin.toolTip = this.maxObjectsLabel.toolTip;
   this.maxObjectsSpin.onValueUpdated = function( value )
   {
      this.dialog.config.maxObjects = value;
   };

   this.sortModeLabel = new Label( this );
   this.sortModeLabel.text = "Sort by";
   this.sortModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.sortModeLabel.minWidth = 120;
   this.sortModeLabel.toolTip =
      "Controls the final order of preview tiles. Visible size uses the actual crop size, image contrast favours the clearest measured patches, distance from centre favours objects near the image centre, redshift uses approximate farthest-to-nearest depth ordering, and object class / colour groups by the legend colours.";

   this.sortModeCombo = new ComboBox( this );
   this.sortModeCombo.addItem( "Default" );
   this.sortModeCombo.addItem( "Visible size" );
   this.sortModeCombo.addItem( "Image contrast" );
   this.sortModeCombo.addItem( "Distance from centre" );
   this.sortModeCombo.addItem( "Name" );
   this.sortModeCombo.addItem( "Redshift" );
   this.sortModeCombo.addItem( "Object class / colour" );
   var sortModes = [ "Default", "Visible size", "Image contrast", "Distance from centre", "Name", "Redshift", "Object class / colour" ];
   this.sortModeCombo.currentItem = Math.max( 0, sortModes.indexOf( this.config.sortMode ) );
   this.sortModeCombo.toolTip = this.sortModeLabel.toolTip;
   this.sortModeCombo.onItemSelected = function( index )
   {
      this.dialog.config.sortMode = sortModes[index];
   };

   this.visibilityModeLabel = new Label( this );
   this.visibilityModeLabel.text = "Visibility filter";
   this.visibilityModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.visibilityModeLabel.minWidth = 120;
   this.visibilityModeLabel.toolTip =
      "Filters preview crops that look like plain background in your actual image. Off keeps every catalogue hit, Permissive keeps more faint objects, Balanced is the default, Strict removes more blank-looking previews.";

   this.visibilityModeCombo = new ComboBox( this );
   this.visibilityModeCombo.addItem( "Off" );
   this.visibilityModeCombo.addItem( "Permissive" );
   this.visibilityModeCombo.addItem( "Balanced" );
   this.visibilityModeCombo.addItem( "Strict" );
   var visibilityModes = [ "Off", "Permissive", "Balanced", "Strict" ];
   this.visibilityModeCombo.currentItem = Math.max( 0, visibilityModes.indexOf( this.config.visibilityMode ) );
   this.visibilityModeCombo.toolTip = this.visibilityModeLabel.toolTip;
   this.visibilityModeCombo.onItemSelected = function( index )
   {
      this.dialog.config.visibilityMode = visibilityModes[index];
   };

   this.objectTypeLabel = new Label( this );
   this.objectTypeLabel.text = "Object type";
   this.objectTypeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.objectTypeLabel.minWidth = 120;
   this.objectTypeLabel.toolTip =
      "Controls the SIMBAD object family queried and kept. Galaxies only is the safest default; Quasars off removes QSO/blazar-like entries; Known galaxies priority hides survey-only candidates; Stars only is for stellar fields.";

   this.objectTypeCombo = new ComboBox( this );
   this.objectTypeCombo.addItem( "Galaxies only" );
   this.objectTypeCombo.addItem( "Galaxies, quasars off" );
   this.objectTypeCombo.addItem( "Known galaxies priority" );
   this.objectTypeCombo.addItem( "Stars only" );
   var objectTypeModes = [ "Galaxies only", "Galaxies, quasars off", "Known galaxies priority", "Stars only" ];
   this.objectTypeCombo.currentItem = Math.max( 0, objectTypeModes.indexOf( this.config.objectTypeMode ) );
   this.objectTypeCombo.toolTip = this.objectTypeLabel.toolTip;
   this.objectTypeCombo.onItemSelected = function( index )
   {
      this.dialog.config.objectTypeMode = objectTypeModes[index];
   };

   this.cataloguePriorityLabel = new Label( this );
   this.cataloguePriorityLabel.text = "Catalogue priority";
   this.cataloguePriorityLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.cataloguePriorityLabel.minWidth = 120;
   this.cataloguePriorityLabel.toolTip =
      "Controls which aliases and duplicate candidates win. Prefer Messier keeps M objects first, Prefer NGC/IC favours classic NGC/IC labels, Known catalogues first lowers deep survey names, and Hide Gaia if duplicate exists suppresses Gaia duplicates near stronger catalogue entries.";

   this.cataloguePriorityCombo = new ComboBox( this );
   this.cataloguePriorityCombo.addItem( "Prefer Messier" );
   this.cataloguePriorityCombo.addItem( "Prefer NGC/IC" );
   this.cataloguePriorityCombo.addItem( "Known catalogues first" );
   this.cataloguePriorityCombo.addItem( "Hide Gaia if duplicate exists" );
   var cataloguePriorityModes = [ "Prefer Messier", "Prefer NGC/IC", "Known catalogues first", "Hide Gaia if duplicate exists" ];
   this.cataloguePriorityCombo.currentItem = Math.max( 0, cataloguePriorityModes.indexOf( this.config.cataloguePriorityMode ) );
   this.cataloguePriorityCombo.toolTip = this.cataloguePriorityLabel.toolTip;
   this.cataloguePriorityCombo.onItemSelected = function( index )
   {
      this.dialog.config.cataloguePriorityMode = cataloguePriorityModes[index];
   };

   this.outputModeLabel = new Label( this );
   this.outputModeLabel.text = "Output mode";
   this.outputModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.outputModeLabel.minWidth = 120;
   this.outputModeLabel.toolTip =
      "Quick presentation style. Scientific keeps dense numeric+ID annotations, Showcase balances attractive output and useful crops, Poster prioritises fewer cleaner labels, and Discovery Map keeps many small candidates for inspection. See the README for the full mode matrix.";

   this.outputModeCombo = new ComboBox( this );
   this.outputModeCombo.addItem( "Scientific" );
   this.outputModeCombo.addItem( "Showcase" );
   this.outputModeCombo.addItem( "Poster" );
   this.outputModeCombo.addItem( "Discovery Map" );
   var outputModes = [ "Scientific", "Showcase", "Poster", "Discovery Map" ];
   this.outputModeCombo.currentItem = Math.max( 0, outputModes.indexOf( this.config.outputMode ) );
   this.outputModeCombo.toolTip = this.outputModeLabel.toolTip;
   this.outputModeCombo.onItemSelected = function( index )
   {
      this.dialog.config.outputMode = outputModes[index];
   };

   this.topDescriptionsCheck = new CheckBox( this );
   this.topDescriptionsCheck.text = "Top 5 object notes";
   this.topDescriptionsCheck.checked = this.config.showTopDescriptions;
   this.topDescriptionsCheck.toolTip =
      "Add a compact notes footer for the five most prominent selected objects in the final composite.";
   this.topDescriptionsCheck.onCheck = function( checked )
   {
      this.dialog.config.showTopDescriptions = checked;
   };

   this.highlightShowcaseCheck = new CheckBox( this );
   this.highlightShowcaseCheck.text = "Highlight showcase objects";
   this.highlightShowcaseCheck.checked = this.config.highlightShowcaseObjects;
   this.highlightShowcaseCheck.toolTip =
      "Draw the first five output objects with stronger boxes and labels.";
   this.highlightShowcaseCheck.onCheck = function( checked )
   {
      this.dialog.config.highlightShowcaseObjects = checked;
   };

   this.colorCodeCheck = new CheckBox( this );
   this.colorCodeCheck.text = "Colour-code object classes";
   this.colorCodeCheck.checked = this.config.colorCodeObjectClasses;
   this.colorCodeCheck.toolTip =
      "Use different annotation colours: yellow main target, orange Messier/NGC/IC, purple quasar/AGN-like entries, green Gaia/stellar catalogue entries, deep blue other survey galaxies. A legend is added to the final image.";
   this.colorCodeCheck.onCheck = function( checked )
   {
      this.dialog.config.colorCodeObjectClasses = checked;
   };

   this.advancedCheck = new CheckBox( this );
   this.advancedCheck.text = "Show advanced controls";
   this.advancedCheck.checked = this.config.showAdvanced;
   this.advancedCheck.toolTip = "Show manual curation, auto-review scrolling, redshift/report export, and automatic-title controls.";
   this.advancedCheck.onCheck = function( checked )
   {
      this.dialog.config.showAdvanced = checked;
      this.dialog.setAdvancedVisible( checked );
   };

   this.simbadSizeCheck = new CheckBox( this );
   this.simbadSizeCheck.text = "Experimental SIMBAD size crops";
   this.simbadSizeCheck.checked = this.config.useSimbadObjectSize;
   this.simbadSizeCheck.toolTip =
      "Use SIMBAD galaxy major/minor axis values when available to enlarge crops for physically large or elongated galaxies. This is experimental because catalogue dimensions are incomplete and not always measured in the same band.";
   this.simbadSizeCheck.onCheck = function( checked )
   {
      this.dialog.config.useSimbadObjectSize = checked;
   };

   this.resultTree = new TreeBox( this );
   this.resultTree.alternateRowColor = true;
   this.resultTree.multipleSelection = false;
   this.resultTree.rootDecoration = false;
   this.resultTree.headerVisible = true;
   this.resultTree.numberOfColumns = 9;
   this.resultTree.setHeaderText( 0, "#" );
   this.resultTree.setHeaderText( 1, "Keep" );
   this.resultTree.setHeaderText( 2, "Display ID" );
   this.resultTree.setHeaderText( 3, "Main ID" );
   this.resultTree.setHeaderText( 4, "Catalogue" );
   this.resultTree.setHeaderText( 5, "RA" );
   this.resultTree.setHeaderText( 6, "Dec" );
   this.resultTree.setHeaderText( 7, "Patch" );
   this.resultTree.setHeaderText( 8, "Visibility" );
   this.resultTree.minHeight = 200;
   this.resultTree.toolTip =
      "Catalogue objects kept by the current query. Click a row after a run to inspect that object's crop in the preview panel below.";
   this.resultTree.onNodeSelectionUpdated = function()
   {
      if ( this.dialog.resultTree.selectedNodes.length == 1 )
         this.dialog.showSelectedPreview( this.dialog.resultTree.selectedNodes[0] );
   };
   this.resultTree.onNodeDoubleClicked = function( node, columnIndex )
   {
      if ( node && columnIndex == 1 )
      {
         node.selected = true;
         this.dialog.toggleKeepNode( node );
      }
   };

   this.logBox = new TextBox( this );
   this.logBox.readOnly = true;
   this.logBox.minHeight = 120;
   this.logBox.visible = this.config.showLog;
   this.logBox.toolTip =
      "Run log with query, filtering, crop validation, visibility filtering, and output creation messages.";

   this.showLogCheck = new CheckBox( this );
   this.showLogCheck.text = "Show log";
   this.showLogCheck.checked = this.config.showLog;
   this.showLogCheck.toolTip =
      "Show or hide the detailed run log. The PixInsight Process Console still receives the same messages.";
   this.showLogCheck.onCheck = function( checked )
   {
      this.dialog.setLogVisible( checked );
   };

   this.previewTitleLabel = new Label( this );
   this.previewTitleLabel.text = this.selectedPreviewTitle;
   this.previewTitleLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   this.previewTitleLabel.visible = false;
   this.previewTitleLabel.toolTip =
      "Selected result preview. Click a row in the table to update the context zoom and enlarged crop.";

   this.previewCanvas = new Control( this );
   this.previewCanvas.minHeight = 190;
   this.previewCanvas.visible = false;
   this.previewCanvas.toolTip =
      "Selected object inspector. Left side shows a zoomed context crop from the annotated overview; right side shows the generated preview crop.";
   this.previewCanvas.onPaint = function( x0, y0, x1, y1 )
   {
      var g = new VectorGraphics( this );
      g.fillRect( x0, y0, x1, y1, new Brush( 0xff101820 ) );
      g.pen = new Pen( 0xff52637a, 1 );
      g.drawRect( 0, 0, this.width - 1, this.height - 1 );

      var dlg = this.dialog;
      if ( dlg.selectedPreviewBitmap )
      {
         var gap = 10;
         var panelH = this.height;
         var leftW = 0;
         var rightW = this.width;
         if ( dlg.selectedContextBitmap )
         {
            leftW = Math.max( 1, Math.floor( (this.width - gap) * 0.58 ) );
            rightW = Math.max( 1, this.width - leftW - gap );

            var contextBmp = dlg.selectedContextBitmap;
            var scaleContext = Math.min( leftW / contextBmp.width, panelH / contextBmp.height );
            scaleContext = Math.max( 0.05, scaleContext );
            var contextDraw = Math.round( contextBmp.width * scaleContext );
            var contextScaled = contextBmp.scaledTo( contextDraw, contextDraw );
            var contextX = Math.round( (leftW - contextDraw) / 2 );
            var contextY = Math.round( (panelH - contextDraw) / 2 );

            g.drawBitmap( contextX, contextY, contextScaled );
            g.pen = new Pen( 0xff2d9cff, 1 );
            g.drawRect( contextX, contextY, contextX + contextDraw, contextY + contextDraw );
            g.drawText( contextX + 6, contextY + 18, "Overview zoom" );
         }

         var bmp = dlg.selectedPreviewBitmap;
         var scalePatch = Math.min( rightW / bmp.width, panelH / bmp.height );
         scalePatch = Math.max( 0.05, scalePatch );
         var drawW = Math.round( bmp.width * scalePatch );
         var drawH = Math.round( bmp.height * scalePatch );
         var scaled = bmp.scaledTo( drawW, drawH );
         var dx = (dlg.selectedContextBitmap ? leftW + gap : 0) + Math.round( (rightW - drawW) / 2 );
         var dy = Math.round( (panelH - drawH) / 2 );
         g.drawBitmap( dx, dy, scaled );
         g.pen = new Pen( 0xffffffff, 1 );
         g.drawRect( dx, dy, dx + drawW, dy + drawH );
         g.pen = new Pen( 0xff2d9cff, 1 );
         g.drawText( dx + 6, dy + 18, "Preview crop" );
      }
      else
      {
         g.font = new Font( "Helvetica", 11 );
         g.pen = new Pen( 0xffa9b7c9, 1 );
         g.drawText( 16, Math.round( this.height / 2 ), "No selected preview yet" );
      }
      g.end();
   };

   this.runButton = new PushButton( this );
   this.runButton.text = "Query and Annotate";
   this.runButton.toolTip = "Run the SIMBAD query, filter/deduplicate objects, and create overview, grid, and final composite windows.";
   this.runButton.onClick = function()
   {
      this.dialog.runEngine();
   };

   this.exportButton = new PushButton( this );
   this.exportButton.text = "Export CSV";
   this.exportButton.enabled = false;
   this.exportButton.toolTip = "Export the last result table to CSV after a successful run.";
   this.exportButton.onClick = function()
   {
      this.dialog.exportResults();
   };

   this.closeButton = new PushButton( this );
   this.closeButton.text = "Close";
   this.closeButton.toolTip = "Close Sky Annotation Studio.";
   this.closeButton.onClick = function()
   {
      this.dialog.stopAutoReview();
      this.dialog.cleanupLegacyContextPreview();
      this.dialog.config.SaveSettings();
      this.dialog.saveDialogSize();
      this.dialog.ok();
   };

   this.resetButton = new PushButton( this );
   this.resetButton.text = "Reset to defaults";
   this.resetButton.toolTip = "Restore the built-in default parameters for this session.";
   this.resetButton.onClick = function()
   {
      this.dialog.resetToDefaults();
   };

   this.manualCurationCheck = new CheckBox( this );
   this.manualCurationCheck.text = "Enable manual keep/remove";
   this.manualCurationCheck.checked = this.config.manualCuration;
   this.manualCurationCheck.toolTip =
      "After a run, remove selected false positives from the kept list and render a curated output without repeating the SIMBAD query.";
   this.manualCurationCheck.onCheck = function( checked )
   {
      this.dialog.config.manualCuration = checked;
   };

   this.keepSelectedButton = new PushButton( this );
   this.keepSelectedButton.text = "Keep selected";
   this.keepSelectedButton.toolTip = "Mark the selected result row as kept.";
   this.keepSelectedButton.onClick = function()
   {
      this.dialog.setSelectedKeepState( true );
   };

   this.removeSelectedButton = new PushButton( this );
   this.removeSelectedButton.text = "Remove selected";
   this.removeSelectedButton.toolTip = "Mark the selected result row as removed from curated rendering.";
   this.removeSelectedButton.onClick = function()
   {
      this.dialog.setSelectedKeepState( false );
   };

   this.restoreAllButton = new PushButton( this );
   this.restoreAllButton.text = "Restore all";
   this.restoreAllButton.toolTip = "Mark all result rows as kept.";
   this.restoreAllButton.onClick = function()
   {
      this.dialog.restoreAllKept();
   };

   this.renderKeptButton = new PushButton( this );
   this.renderKeptButton.text = "Render kept";
   this.renderKeptButton.toolTip = "Create new output windows from currently kept rows only.";
   this.renderKeptButton.onClick = function()
   {
      this.dialog.renderKeptResults();
   };

   this.autoReviewButton = new PushButton( this );
   this.autoReviewButton.text = "Start auto-review";
   this.autoReviewButton.enabled = false;
   this.autoReviewButton.toolTip = "Automatically step through the result table so blank or weak previews are easier to spot. Auto-review uses a lightweight preview-only mode so the Stop button remains responsive.";
   this.autoReviewButton.onClick = function()
   {
      this.dialog.toggleAutoReview();
   };

   this.stopAutoReviewButton = new PushButton( this );
   this.stopAutoReviewButton.text = "Stop";
   this.stopAutoReviewButton.enabled = false;
   this.stopAutoReviewButton.toolTip = "Immediately request auto-review to stop. This is a separate stable button so PixInsight does not have to toggle the Start button while the timer is active.";
   this.stopAutoReviewButton.onClick = function()
   {
      this.dialog.stopAutoReview();
      this.dialog.resultTree.hasFocus = true;
   };

   this.autoReviewDelayLabel = new Label( this );
   this.autoReviewDelayLabel.text = "Delay ms";
   this.autoReviewDelayLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.autoReviewDelayLabel.toolTip = "How long each preview row stays selected during auto-review. Default/minimum is 150 ms because faster values can starve PixInsight's UI event loop and make Stop unreliable.";

   this.autoReviewDelaySpin = new SpinBox( this );
   this.autoReviewDelaySpin.minValue = 150;
   this.autoReviewDelaySpin.maxValue = 5000;
   this.autoReviewDelaySpin.value = this.config.autoReviewDelayMs;
   this.autoReviewDelaySpin.toolTip = this.autoReviewDelayLabel.toolTip;
   this.autoReviewDelaySpin.onValueUpdated = function( value )
   {
      this.dialog.config.autoReviewDelayMs = Math.max( 150, value );
      this.dialog.autoReviewTimer.interval = this.dialog.config.autoReviewDelayMs / 1000.0;
   };

   this.autoTitleCheck = new CheckBox( this );
   this.autoTitleCheck.text = "Auto title";
   this.autoTitleCheck.checked = this.config.autoTitle;
   this.autoTitleCheck.toolTip = "Automatically set the title from the main object and selected output mode before each run.";
   this.autoTitleCheck.onCheck = function( checked )
   {
      this.dialog.config.autoTitle = checked;
   };

   this.includeRedshiftCheck = new CheckBox( this );
   this.includeRedshiftCheck.text = "Include redshift";
   this.includeRedshiftCheck.checked = this.config.includeRedshift;
   this.includeRedshiftCheck.toolTip = "Include SIMBAD redshift values in CSV/HTML exports and top-object notes when available.";
   this.includeRedshiftCheck.onCheck = function( checked )
   {
      this.dialog.config.includeRedshift = checked;
   };

   this.htmlReportButton = new PushButton( this );
   this.htmlReportButton.text = "Export HTML report";
   this.htmlReportButton.enabled = false;
   this.htmlReportButton.toolTip = "Export a readable HTML object report after a successful run.";
   this.htmlReportButton.onClick = function()
   {
      this.dialog.exportHtmlReport();
   };

   this.advancedControls = [
      this.manualCurationCheck, this.keepSelectedButton, this.removeSelectedButton,
      this.restoreAllButton, this.renderKeptButton, this.autoTitleCheck,
      this.autoReviewButton, this.stopAutoReviewButton, this.autoReviewDelayLabel, this.autoReviewDelaySpin,
      this.includeRedshiftCheck, this.exportButton, this.htmlReportButton
   ];

   this.setAdvancedVisible = function( visible )
   {
      for ( var i = 0; i < this.advancedControls.length; ++i )
         this.advancedControls[i].visible = visible;
      this.adjustToContents();
   };

   this.syncConfigToControls = function()
   {
      this.windowModeCombo.currentItem = this.config.useActiveWindow ? 0 : 1;
      this.inputFileEdit.enabled = !this.config.useActiveWindow;
      this.inputFileButton.enabled = !this.config.useActiveWindow;
      this.inputFileEdit.text = this.config.inputFile;
      this.mainObjectEdit.text = this.config.mainObject;
      this.titleEdit.text = this.config.photoTitle;
      this.presetCombo.currentItem = Math.max( 0, this.presetNames.indexOf( this.config.presetName ) );
      this.presetNameEdit.text = this.config.presetName;
      this.filterEdit.text = this.config.filterPrefixes.join( "," );
      this.labelModeCombo.currentItem =
         this.config.labelMode == "Object IDs" ? 1 : (this.config.labelMode == "Numbers + IDs" ? 2 : 0);
      this.labelLengthCombo.currentItem =
         this.config.labelLengthMode == "Short" ? 0 :
         (this.config.labelLengthMode == "Full" ? 2 : 1);
      this.boxSizeSpin.value = Math.round( this.config.boxSize );
      this.patchScaleSpin.value = Math.round( this.config.patchScale * 100 );
      this.previewPatchSizeSpin.value = this.config.previewPatchSize;
      this.maxObjectsSpin.value = this.config.maxObjects;
      this.sortModeCombo.currentItem =
         this.config.sortMode == "Visible size" ? 1 :
         (this.config.sortMode == "Image contrast" ? 2 :
         (this.config.sortMode == "Distance from centre" ? 3 :
         (this.config.sortMode == "Name" ? 4 :
         (this.config.sortMode == "Redshift" ? 5 :
         (this.config.sortMode == "Object class / colour" ? 6 : 0)))));
      this.previewLabelAlignmentCombo.currentItem =
         this.config.previewLabelAlignment == "Centred" ? 1 : 0;
      this.visibilityModeCombo.currentItem =
         this.config.visibilityMode == "Permissive" ? 1 :
         (this.config.visibilityMode == "Balanced" ? 2 :
         (this.config.visibilityMode == "Strict" ? 3 : 0));
      this.objectTypeCombo.currentItem =
         this.config.objectTypeMode == "Galaxies, quasars off" ? 1 :
         (this.config.objectTypeMode == "Known galaxies priority" ? 2 :
         (this.config.objectTypeMode == "Stars only" ? 3 : 0));
      this.cataloguePriorityCombo.currentItem =
         this.config.cataloguePriorityMode == "Prefer NGC/IC" ? 1 :
         (this.config.cataloguePriorityMode == "Known catalogues first" ? 2 :
         (this.config.cataloguePriorityMode == "Hide Gaia if duplicate exists" ? 3 : 0));
      this.simbadSizeCheck.checked = this.config.useSimbadObjectSize;
      this.outputModeCombo.currentItem =
         this.config.outputMode == "Scientific" ? 0 :
         (this.config.outputMode == "Poster" ? 2 :
         (this.config.outputMode == "Discovery Map" ? 3 : 1));
      this.topDescriptionsCheck.checked = this.config.showTopDescriptions;
      this.highlightShowcaseCheck.checked = this.config.highlightShowcaseObjects;
      this.colorCodeCheck.checked = this.config.colorCodeObjectClasses;
      this.advancedCheck.checked = this.config.showAdvanced;
      this.showLogCheck.checked = this.config.showLog;
      this.logBox.visible = this.config.showLog;
      this.manualCurationCheck.checked = this.config.manualCuration;
      this.autoReviewDelaySpin.value = this.config.autoReviewDelayMs;
      this.autoTitleCheck.checked = this.config.autoTitle;
      this.includeRedshiftCheck.checked = this.config.includeRedshift;
      this.setAdvancedVisible( this.config.showAdvanced );
   };

   this.resetToDefaults = function()
   {
      this.config.SetDefaults();
      this.cleanupLegacyContextPreview();
      this.selectedPreviewBitmap = null;
      this.selectedContextBitmap = null;
      this.selectedObject = null;
      this.previewTitleLabel.visible = false;
      this.previewCanvas.visible = false;
      this.syncConfigToControls();
      this.appendLog( "Parameters reset to defaults." );
      this.adjustToContents();
   };

   this.setLogVisible = function( visible )
   {
      this.config.showLog = visible;
      this.showLogCheck.checked = visible;
      this.logBox.visible = visible;
      this.adjustToContents();
   };

   this.cleanupLegacyContextPreview = function()
   {
      var windows = ImageWindow.openWindows;
      for ( var i = 0; i < windows.length; ++i )
      {
         try
         {
            var preview = windows[i].previewById( "SkyAnnotSelectedContext" );
            if ( preview && !preview.isNull )
               windows[i].deletePreview( preview );
         }
         catch ( ex )
         {
         }
      }
   };

   this.restoreDialogSize = function()
   {
      var w = this.safeSettingsRead( SETTINGS_MODULE + "/dialogWidth", DataType_Int32 );
      var h = this.safeSettingsRead( SETTINGS_MODULE + "/dialogHeight", DataType_Int32 );
      if ( w != null && h != null && w >= 960 && h >= 680 )
         this.resize( w, h );
      else
         this.resize( 1180, 760 );
   };

   this.saveDialogSize = function()
   {
      this.safeSettingsWrite( SETTINGS_MODULE + "/dialogWidth", DataType_Int32, Math.round( this.width ) );
      this.safeSettingsWrite( SETTINGS_MODULE + "/dialogHeight", DataType_Int32, Math.round( this.height ) );
   };

   this.appendLog = function( message )
   {
      if ( this.logBox.text.length == 0 )
         this.logBox.text = message;
      else
         this.logBox.text += "\n" + message;
   };

   this.formatElapsedSeconds = function( seconds )
   {
      if ( seconds < 60 )
         return format( "%.1fs", seconds );
      var minutes = Math.floor( seconds / 60 );
      var rest = seconds - minutes * 60;
      return minutes.toString() + "m " + format( "%.1fs", rest );
   };

   this.setResults = function( objects )
   {
      this.stopAutoReview();
      this.resultTree.clear();
      for ( var i = 0; i < objects.length; ++i )
      {
         var o = objects[i];
         var node = new TreeBoxNode( this.resultTree );
         if ( o.keep == null )
            o.keep = true;
         node.setText( 0, (i + 1).toString() );
         node.setText( 1, o.keep === false ? "No" : "Yes" );
         node.setText( 2, o.displayId );
         node.setText( 3, o.mainId );
         node.setText( 4, o.catalogueType );
         node.setText( 5, format( "%.6f", o.ra ) );
         node.setText( 6, format( "%.6f", o.dec ) );
         node.setText( 7, format( "%.0f", o.patchSize ? o.patchSize : 0 ) );
         node.setText( 8, format( "%.2f", o.visibilityScore ? o.visibilityScore : 0 ) );
         node.objectIndex = i;
      }
      this.exportButton.enabled = objects.length > 0;
      this.htmlReportButton.enabled = objects.length > 0;
      this.autoReviewButton.enabled = objects.length > 0;
   };

   this.selectResultIndex = function( index, lightweightPreview )
   {
      if ( index < 0 || index >= this.resultTree.numberOfChildren )
         return;
      this.resultTree.canUpdate = false;
      for ( var i = 0; i < this.resultTree.numberOfChildren; ++i )
         this.resultTree.child( i ).selected = false;
      var node = this.resultTree.child( index );
      node.selected = true;
      this.resultTree.canUpdate = true;
      this.showSelectedPreview( node, lightweightPreview );
      this.resultTree.hasFocus = true;
   };

   this.stopAutoReview = function()
   {
      this.autoReviewRunning = false;
      this.autoReviewStopRequested = true;
      if ( this.autoReviewTimer )
         this.autoReviewTimer.stop();
      this.autoReviewIndex = -1;
      this.autoReviewBusy = false;
      if ( this.autoReviewButton )
      {
         this.autoReviewButton.enabled = this.resultTree.numberOfChildren > 0;
      }
      if ( this.stopAutoReviewButton )
         this.stopAutoReviewButton.enabled = false;
   };

   this.toggleAutoReview = function()
   {
      if ( this.resultTree.numberOfChildren == 0 )
         return;
      if ( this.autoReviewRunning )
      {
         this.stopAutoReview();
         this.resultTree.hasFocus = true;
         return;
      }

      this.config.autoReviewDelayMs = Math.max( 150, this.autoReviewDelaySpin.value );
      this.autoReviewDelaySpin.value = this.config.autoReviewDelayMs;
      this.autoReviewTimer.interval = this.config.autoReviewDelayMs / 1000.0;
      this.autoReviewIndex = this.resultTree.selectedNodes.length == 1 ?
         this.resultTree.selectedNodes[0].objectIndex : -1;
      this.autoReviewButton.enabled = false;
      this.stopAutoReviewButton.enabled = true;
      this.autoReviewStopRequested = false;
      this.autoReviewRunning = true;
      this.autoReviewBusy = false;
      this.advanceAutoReview();
      if ( typeof processEvents == "function" )
         processEvents();
      if ( this.autoReviewRunning && !this.autoReviewStopRequested )
         this.autoReviewTimer.start();
   };

   this.advanceAutoReview = function()
   {
      if ( this.autoReviewBusy || !this.autoReviewRunning )
         return;
      if ( this.resultTree.numberOfChildren == 0 )
      {
         this.stopAutoReview();
         return;
      }
      this.autoReviewBusy = true;
      try
      {
         this.autoReviewIndex = (this.autoReviewIndex + 1) % this.resultTree.numberOfChildren;
         this.selectResultIndex( this.autoReviewIndex, true );
      }
      catch ( ex )
      {
         this.appendLog( "Auto-review stopped after error: " + ex );
         this.stopAutoReview();
      }
      this.autoReviewBusy = false;
      if ( typeof processEvents == "function" )
         processEvents();
   };

   this.buildContextBitmap = function( object )
   {
      if ( !this.lastResult || !this.lastResult.overviewBitmap )
         return null;

      var overview = this.lastResult.overviewBitmap;
      var contextSize = Math.max( object.patchSize * 4, object.patchSize + 220 );
      contextSize = Math.min( Math.max( contextSize, 384 ), Math.min( overview.width, overview.height ) );
      var half = Math.floor( contextSize / 2 );
      var sx0 = Math.round( object.px - half );
      var sy0 = Math.round( object.py - half );
      sx0 = Math.max( 0, Math.min( overview.width - contextSize, sx0 ) );
      sy0 = Math.max( 0, Math.min( overview.height - contextSize, sy0 ) );

      var context = new Bitmap( contextSize, contextSize );
      context.fill( 0xff000000 );
      var g = new VectorGraphics( context );
      g.drawBitmapRect( new Point( 0, 0 ), overview, new Rect( sx0, sy0, sx0 + contextSize, sy0 + contextSize ) );
      g.pen = new Pen( 0xff2d9cff, 2 );
      var cx = Math.round( object.px - sx0 );
      var cy = Math.round( object.py - sy0 );
      g.drawLine( cx - 18, cy, cx + 18, cy );
      g.drawLine( cx, cy - 18, cx, cy + 18 );
      g.end();
      return context;
   };

   this.showSelectedPreview = function( node, lightweightPreview )
   {
      if ( !node || this.resultPatches.length == 0 )
         return;

      var index = node.objectIndex;
      if ( index < 0 || index >= this.resultPatches.length )
         return;

      var patch = this.resultPatches[index];
      var object = patch.object;
      var wasHidden = !this.previewCanvas.visible;
      this.selectedPreviewBitmap = patch.bitmap;
      this.selectedContextBitmap = lightweightPreview ? null :
         (patch.contextBitmap ? patch.contextBitmap : this.buildContextBitmap( object ));
      this.selectedObject = object;
      this.selectedPreviewTitle =
         "Preview " + (index + 1).toString() + ": " + object.displayId +
         "  |  patch " + format( "%.0f", object.patchSize ? object.patchSize : 0 ) +
         " px  |  visibility " + format( "%.2f", object.visibilityScore ? object.visibilityScore : 0 );
      this.previewTitleLabel.text = this.selectedPreviewTitle;
      this.previewTitleLabel.visible = true;
      this.previewCanvas.visible = true;
      this.previewCanvas.update();
      if ( wasHidden )
         this.adjustToContents();
   };

   this.setSelectedKeepState = function( keep )
   {
      if ( this.resultTree.selectedNodes.length != 1 )
         return;
      var node = this.resultTree.selectedNodes[0];
      var index = node.objectIndex;
      if ( index < 0 || index >= this.resultObjects.length )
         return;
      this.resultObjects[index].keep = keep;
      if ( this.resultPatches[index] )
         this.resultPatches[index].object.keep = keep;
      this.resultTree.canUpdate = false;
      node.setText( 1, keep ? "Yes" : "No" );
      node.selected = true;
      this.resultTree.canUpdate = true;
      this.appendLog( (keep ? "Kept " : "Removed ") + this.resultObjects[index].displayId + "." );
      this.resultTree.hasFocus = true;
   };

   this.toggleKeepNode = function( node )
   {
      if ( !node )
         return;
      var index = node.objectIndex;
      if ( index < 0 || index >= this.resultObjects.length )
         return;
      var keep = !(this.resultObjects[index].keep === false);
      this.resultObjects[index].keep = !keep;
      if ( this.resultPatches[index] )
         this.resultPatches[index].object.keep = !keep;
      this.resultTree.canUpdate = false;
      node.setText( 1, keep ? "No" : "Yes" );
      node.selected = true;
      this.resultTree.canUpdate = true;
      this.appendLog( (keep ? "Removed " : "Kept ") + this.resultObjects[index].displayId + "." );
      this.resultTree.hasFocus = true;
   };

   this.restoreAllKept = function()
   {
      for ( var i = 0; i < this.resultObjects.length; ++i )
      {
         this.resultObjects[i].keep = true;
         if ( this.resultPatches[i] )
            this.resultPatches[i].object.keep = true;
      }
      this.setResults( this.resultObjects );
      this.appendLog( "Restored all result rows to kept." );
      this.resultTree.hasFocus = true;
   };

   this.keptPatches = function()
   {
      var kept = [];
      for ( var i = 0; i < this.resultPatches.length; ++i )
         if ( this.resultPatches[i].object.keep !== false )
            kept.push( this.resultPatches[i] );
      return kept;
   };

   this.renderKeptResults = function()
   {
      try
      {
         var started = (new Date()).getTime();
         var kept = this.keptPatches();
         var engine = new SkyAnnotationEngine( this, this.config );
         var result = engine.renderFromPatches( kept );
         this.lastResult = result;
         this.resultObjects = result.objects;
         this.resultPatches = result.patches ? result.patches : [];
         this.setResults( this.resultObjects );
         var elapsed = ((new Date()).getTime() - started) / 1000.0;
         var curatedTimeMessage = "Curated render finished in " + this.formatElapsedSeconds( elapsed ) + " with " + this.resultObjects.length.toString() + " kept objects.";
         this.appendLog( curatedTimeMessage );
         console.writeln( curatedTimeMessage );
      }
      catch ( ex )
      {
         this.appendLog( "Error: " + ex );
         (new MessageBox( ex.toString(), "Sky Annotation Studio", StdIcon_Error, StdButton_Ok )).execute();
      }
   };

   this.applyOutputModeDefaults = function()
   {
      if ( this.config.outputMode == "Scientific" )
      {
         if ( this.config.sortMode != "Redshift" && this.config.sortMode != "Object class / colour" )
            this.config.sortMode = "Default";
         this.config.visibilityMode = "Balanced";
         this.config.labelMode = "Numbers + IDs";
         this.config.highlightShowcaseObjects = false;
      }
      else if ( this.config.outputMode == "Poster" )
      {
         if ( this.config.sortMode != "Redshift" && this.config.sortMode != "Object class / colour" )
            this.config.sortMode = "Visible size";
         this.config.visibilityMode = "Strict";
         this.config.maxObjects = Math.min( this.config.maxObjects, 250 );
         this.config.labelMode = "Numbers";
         this.config.highlightShowcaseObjects = true;
      }
      else if ( this.config.outputMode == "Discovery Map" )
      {
         if ( this.config.sortMode != "Redshift" && this.config.sortMode != "Object class / colour" )
            this.config.sortMode = "Image contrast";
         this.config.visibilityMode = "Permissive";
         this.config.maxObjects = Math.max( this.config.maxObjects, 800 );
         this.config.highlightShowcaseObjects = false;
      }
   };

   this.runEngine = function()
   {
      try
      {
         var started = (new Date()).getTime();
         this.stopAutoReview();
         this.cleanupLegacyContextPreview();
         this.logBox.clear();
         this.applyOutputModeDefaults();
         if ( this.config.autoTitle )
         {
            this.config.photoTitle = (this.config.mainObject.length > 0 ? this.config.mainObject + " " : "") +
               this.config.outputMode + " Annotation Field";
            this.titleEdit.text = this.config.photoTitle;
         }
         this.syncConfigToControls();
         this.config.SaveSettings();
         var engine = new SkyAnnotationEngine( this, this.config );
         var result = engine.run();
         Console.hide();
         this.lastResult = result;
         this.resultObjects = result.objects;
         this.resultPatches = result.patches ? result.patches : [];
         this.setResults( this.resultObjects );
         var elapsed = ((new Date()).getTime() - started) / 1000.0;
         var timeMessage = "Finished in " + this.formatElapsedSeconds( elapsed ) + ".";
         this.appendLog( timeMessage );
         console.writeln( timeMessage );
         if ( this.resultTree.numberOfChildren > 0 )
         {
            this.resultTree.child( 0 ).selected = true;
            this.showSelectedPreview( this.resultTree.child( 0 ) );
         }
      }
      catch ( ex )
      {
         this.appendLog( "Error: " + ex );
         (new MessageBox( ex.toString(), "Sky Annotation Studio", StdIcon_Error, StdButton_Ok )).execute();
      }
   };

   this.exportResults = function()
   {
      if ( this.resultObjects.length == 0 )
         return;

      var sfd = new SaveFileDialog();
      sfd.caption = "Export annotation table";
      sfd.filters = [ [ "CSV files", ".csv" ] ];
      sfd.initialPath = File.systemTempDirectory + "/sky_annotation_results.csv";
      if ( !sfd.execute() )
         return;

      try
      {
         var engine = new SkyAnnotationEngine( this, this.config );
         engine.exportCsv( this.resultObjects, sfd.fileName );
         this.appendLog( "CSV exported to " + sfd.fileName );
      }
      catch ( ex )
      {
         (new MessageBox( ex.toString(), "Sky Annotation Studio", StdIcon_Error, StdButton_Ok )).execute();
      }
   };

   this.exportHtmlReport = function()
   {
      if ( this.resultObjects.length == 0 )
         return;

      var sfd = new SaveFileDialog();
      sfd.caption = "Export annotation HTML report";
      sfd.filters = [ [ "HTML files", ".html" ] ];
      sfd.initialPath = File.systemTempDirectory + "/sky_annotation_report.html";
      if ( !sfd.execute() )
         return;

      try
      {
         var engine = new SkyAnnotationEngine( this, this.config );
         engine.exportHtmlReport( this.resultObjects, sfd.fileName );
         this.appendLog( "HTML report exported to " + sfd.fileName );
      }
      catch ( ex )
      {
         (new MessageBox( ex.toString(), "Sky Annotation Studio", StdIcon_Error, StdButton_Ok )).execute();
      }
   };

   var row1 = new HorizontalSizer();
   row1.spacing = 6;
   row1.add( this.windowModeLabel );
   row1.add( this.windowModeCombo, 100 );

   var row2 = new HorizontalSizer();
   row2.spacing = 6;
   row2.add( this.inputFileLabel );
   row2.add( this.inputFileEdit, 100 );
   row2.add( this.inputFileButton );

   var row3 = new HorizontalSizer();
   row3.spacing = 6;
   row3.add( this.mainObjectLabel );
   row3.add( this.mainObjectEdit, 100 );

   var row4 = new HorizontalSizer();
   row4.spacing = 6;
   row4.add( this.titleLabel );
   row4.add( this.titleEdit, 100 );

   var row5 = new HorizontalSizer();
   row5.spacing = 6;
   row5.add( this.filterLabel );
   row5.add( this.filterEdit, 100 );

   var presetRow = new HorizontalSizer();
   presetRow.spacing = 6;
   presetRow.add( this.presetLabel );
   presetRow.add( this.presetCombo );
   presetRow.add( this.presetNameEdit, 100 );
   presetRow.addSpacing( 16 );
   presetRow.add( this.applyPresetButton );
   presetRow.add( this.savePresetButton );

   var row6 = new HorizontalSizer();
   row6.spacing = 6;
   row6.add( this.labelModeLabel );
   row6.add( this.labelModeCombo );
   row6.addSpacing( 16 );
   row6.add( this.boxSizeLabel );
   row6.add( this.boxSizeSpin );
   row6.addSpacing( 16 );
   row6.add( this.maxObjectsLabel );
   row6.add( this.maxObjectsSpin );
   row6.addStretch();

   var row7 = new HorizontalSizer();
   row7.spacing = 6;
   row7.add( this.patchScaleLabel );
   row7.add( this.patchScaleSpin );
   row7.addSpacing( 16 );
   row7.add( this.previewPatchSizeLabel );
   row7.add( this.previewPatchSizeSpin );
   row7.addStretch();

   var row8 = new HorizontalSizer();
   row8.spacing = 6;
   row8.add( this.sortModeLabel );
   row8.add( this.sortModeCombo );
   row8.addSpacing( 16 );
   row8.add( this.visibilityModeLabel );
   row8.add( this.visibilityModeCombo );
   row8.addStretch();

   var row9 = new HorizontalSizer();
   row9.spacing = 6;
   row9.add( this.labelLengthLabel );
   row9.add( this.labelLengthCombo );
   row9.addSpacing( 16 );
   row9.add( this.previewLabelAlignmentLabel );
   row9.add( this.previewLabelAlignmentCombo );
   row9.addSpacing( 16 );
   row9.addStretch();

   var row9b = new HorizontalSizer();
   row9b.spacing = 6;
   row9b.add( this.objectTypeLabel );
   row9b.add( this.objectTypeCombo );
   row9b.addSpacing( 16 );
   row9b.add( this.cataloguePriorityLabel );
   row9b.add( this.cataloguePriorityCombo );
   row9b.addStretch();

   var row10 = new HorizontalSizer();
   row10.spacing = 6;
   row10.add( this.outputModeLabel );
   row10.add( this.outputModeCombo );
   row10.addSpacing( 16 );
   row10.add( this.topDescriptionsCheck );
   row10.addSpacing( 16 );
   row10.add( this.highlightShowcaseCheck );
   row10.addSpacing( 16 );
   row10.add( this.colorCodeCheck );
   row10.addStretch();

   var row11 = new HorizontalSizer();
   row11.spacing = 6;
   row11.addSpacing( 126 );
   row11.add( this.advancedCheck );
   row11.addSpacing( 16 );
   row11.add( this.simbadSizeCheck );
   row11.addSpacing( 16 );
   row11.add( this.showLogCheck );
   row11.addStretch();

   var advancedRow1 = new HorizontalSizer();
   advancedRow1.spacing = 6;
   advancedRow1.addSpacing( 126 );
   advancedRow1.add( this.manualCurationCheck );
   advancedRow1.addSpacing( 16 );
   advancedRow1.add( this.keepSelectedButton );
   advancedRow1.addSpacing( 6 );
   advancedRow1.add( this.removeSelectedButton );
   advancedRow1.addSpacing( 6 );
   advancedRow1.add( this.restoreAllButton );
   advancedRow1.addSpacing( 6 );
   advancedRow1.add( this.renderKeptButton );
   advancedRow1.addStretch();

   var advancedRow2 = new HorizontalSizer();
   advancedRow2.spacing = 6;
   advancedRow2.addSpacing( 126 );
   advancedRow2.add( this.autoReviewButton );
   advancedRow2.add( this.stopAutoReviewButton );
   advancedRow2.add( this.autoReviewDelayLabel );
   advancedRow2.add( this.autoReviewDelaySpin );
   advancedRow2.addSpacing( 16 );
   advancedRow2.add( this.autoTitleCheck );
   advancedRow2.addSpacing( 16 );
   advancedRow2.add( this.includeRedshiftCheck );
   advancedRow2.addStretch();

   var advancedRow3 = new HorizontalSizer();
   advancedRow3.spacing = 6;
   advancedRow3.addSpacing( 126 );
   advancedRow3.add( this.exportButton );
   advancedRow3.addSpacing( 6 );
   advancedRow3.add( this.htmlReportButton );
   advancedRow3.addStretch();

   var buttonRow = new HorizontalSizer();
   buttonRow.spacing = 6;
   buttonRow.addStretch();
   buttonRow.add( this.runButton );
   buttonRow.add( this.resetButton );
   buttonRow.add( this.closeButton );

   this.sizer = new VerticalSizer();
   this.sizer.margin = 10;
   this.sizer.spacing = 8;
   this.sizer.add( row1 );
   this.sizer.add( row2 );
   this.sizer.add( row3 );
   this.sizer.add( row4 );
   this.sizer.add( row5 );
   this.sizer.add( presetRow );
   this.sizer.add( row6 );
   this.sizer.add( row7 );
   this.sizer.add( row8 );
   this.sizer.add( row9 );
   this.sizer.add( row9b );
   this.sizer.add( row10 );
   this.sizer.add( row11 );
   this.sizer.add( advancedRow1 );
   this.sizer.add( advancedRow2 );
   this.sizer.add( advancedRow3 );
   this.sizer.add( this.resultTree, 100 );
   this.sizer.add( this.previewTitleLabel );
   this.sizer.add( this.previewCanvas, 100 );
   this.sizer.add( this.logBox );
   this.sizer.add( buttonRow );

   this.onClose = function()
   {
      this.stopAutoReview();
      this.cleanupLegacyContextPreview();
      this.config.SaveSettings();
      this.saveDialogSize();
      return true;
   };

   this.windowTitle = "Sky Annotation Studio (PJSR MVP)";
   this.adjustToContents();
   this.setMinWidth( 960 );
   this.setMinHeight( 680 );
   this.syncConfigToControls();
   this.restoreDialogSize();
}

SkyAnnotationDialog.prototype = new Dialog;

function main()
{
   Console.abortEnabled = true;
   Console.show();
   var dialog = new SkyAnnotationDialog();
   dialog.execute();
}

main();
