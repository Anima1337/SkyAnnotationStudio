/*
   Sky Annotation Studio - Native PixInsight PJSR MVP

   This script provides a native PixInsight interface for querying SIMBAD
   around a solved FITS/XISF image, filtering likely galaxy catalogues,
   deduplicating related object identifiers, and generating an annotated
   preview window inside PixInsight.
*/

#feature-id    SkyAnnotationStudio : Utilities > Sky Annotation Studio
#feature-info  Native PixInsight annotation browser for solved FITS/XISF images.<br/>\
Queries SIMBAD around the active image or a selected file, filters likely deep-sky catalogues,\
deduplicates related identifiers, and opens an annotated preview window.

#include <pjsr/Sizer.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/UndoFlag.jsh>

#ifndef SETTINGS_MODULE
#define SETTINGS_MODULE "SkyAnnotationStudioPJSR"
#endif

#include "../AdP/WCSmetadata.jsh"

function SkyAnnotationConfig()
{
   this.__base__ = ObjectWithSettings;
   this.__base__(
      SETTINGS_MODULE,
      "config",
      [
         ["useActiveWindow", DataType_Boolean],
         ["inputFile", DataType_UCString],
         ["mainObject", DataType_UCString],
         ["photoTitle", DataType_UCString],
         ["filterPrefixes", Ext_DataType_StringArray],
         ["labelMode", DataType_UCString],
         ["boxSize", DataType_Double],
         ["patchScale", DataType_Double],
         ["previewPatchSize", DataType_Int32],
         ["maxObjects", DataType_Int32],
         ["sortMode", DataType_UCString],
         ["visibilityMode", DataType_UCString]
      ]
   );

   this.SetDefaults = function()
   {
      this.useActiveWindow = true;
      this.inputFile = "";
      this.mainObject = "";
      this.photoTitle = "Annotated Sky Field";
      this.filterPrefixes = [
         "LEDA", "Gaia", "2MASX", "SDSS", "UGC", "M", "UGCA", "MFGC",
         "MRK", "MGC", "FIRST", "MASS", "MCG", "Mrk", "2MFGC", "2MASS",
         "IC", "NGC", "SAI"
      ];
      this.labelMode = "Numbers";
      this.boxSize = 96;
      this.patchScale = 1.0;
      this.previewPatchSize = 256;
      this.maxObjects = 500;
      this.sortMode = "Default";
      this.visibilityMode = "Balanced";
   };

   this.SetDefaults();
   this.LoadSettings();
}

SkyAnnotationConfig.prototype = new ObjectWithSettings;

function SkyAnnotationEngine( dialog, config )
{
   this.dialog = dialog;
   this.config = config;

   this.log = function( message )
   {
      if ( this.dialog )
         this.dialog.appendLog( message );
      console.writeln( message );
   };

   this.tryExtractMetadata = function( imageWindow )
   {
      try
      {
         var metadata = new ImageMetadata();
         metadata.ExtractMetadata( imageWindow );
         if ( metadata.ref_I_G == null )
            return null;
         return metadata;
      }
      catch ( ex )
      {
         return null;
      }
   };

   this.windowSelectionScore = function( imageWindow, metadata, isActive )
   {
      var score = 0;
      var id = imageWindow && imageWindow.mainView ? imageWindow.mainView.id : "";
      var title = id.toLowerCase();

      if ( isActive )
         score += 1000;
      if ( title.indexOf( "_skyannot" ) >= 0 )
         score -= 500;
      if ( title.indexOf( "annot" ) >= 0 )
         score -= 200;
      if ( title.indexOf( "preview" ) >= 0 )
         score -= 150;
      if ( metadata && metadata.width && metadata.height )
         score += Math.min( 500, Math.round( (metadata.width * metadata.height) / 1000000 ) );

      return score;
   };

   this.findBestSolvedOpenWindow = function()
   {
      var windows = ImageWindow.windows;
      var active = ImageWindow.activeWindow;
      var best = null;
      var bestScore = -1e9;

      for ( var i = 0; i < windows.length; ++i )
      {
         var w = windows[i];
         if ( !w || w.isNull )
            continue;

         var metadata = this.tryExtractMetadata( w );
         if ( metadata == null )
            continue;

         var score = this.windowSelectionScore( w, metadata, active && !active.isNull && w.mainView.id == active.mainView.id );
         if ( best == null || score > bestScore )
         {
            best = { window: w, metadata: metadata, score: score };
            bestScore = score;
         }
      }

      return best;
   };

   this.currentWindow = function()
   {
      if ( this.config.useActiveWindow )
      {
         var w = ImageWindow.activeWindow;
         if ( !w || w.isNull )
            throw new Error( "There is no active image window." );

         var activeMetadata = this.tryExtractMetadata( w );
         if ( activeMetadata != null )
            return { window: w, temporary: false, metadata: activeMetadata };

         var fallback = this.findBestSolvedOpenWindow();
         if ( fallback != null )
         {
            this.log(
               "Active window has no astrometric solution; using solved window '" +
               fallback.window.mainView.id + "' instead."
            );
            return { window: fallback.window, temporary: false, metadata: fallback.metadata };
         }

         throw new Error( "No open image window with a valid astrometric solution was found." );
      }

      if ( !this.config.inputFile || this.config.inputFile.trim().length == 0 )
         throw new Error( "Please choose a FITS/XISF file." );

      var windows = ImageWindow.open( this.config.inputFile );
      if ( !windows || windows.length < 1 )
         throw new Error( "PixInsight could not open the selected file." );

      return { window: windows[0], temporary: true, metadata: null };
   };

   this.extractMetadata = function( imageWindow )
   {
      var metadata = this.tryExtractMetadata( imageWindow );
      if ( metadata == null )
         throw new Error( "The selected image has no valid astrometric solution." );
      return metadata;
   };

   this.fieldRadiusDeg = function( metadata )
   {
      if ( metadata.resolution == null || metadata.width == null || metadata.height == null )
         throw new Error( "The image metadata did not provide a usable field size." );
      return metadata.resolution * Math.max( metadata.width, metadata.height );
   };

   this.downloadText = function( url, fileName )
   {
      var filePath = File.systemTempDirectory + "/" + fileName;
      var downloader = new FileDownload( url, filePath );
      if ( !downloader.perform() )
         throw new Error( "SIMBAD download failed." );
      return File.readTextFile( filePath );
   };

   this.buildCirclePredicate = function( metadata )
   {
      var radiusDeg = this.fieldRadiusDeg( metadata );
      return (
         "CONTAINS(POINT('ICRS', ra, dec), " +
         "CIRCLE('ICRS', " + format( "%.10f", metadata.ra ) + ", " + format( "%.10f", metadata.dec ) + ", " +
         format( "%.10f", radiusDeg ) + ")) = 1"
      );
   };

   this.executeTapQuery = function( adql, fileName )
   {
      var url =
         "https://simbad.cds.unistra.fr/simbad/sim-tap/sync" +
         "?request=doQuery&lang=adql&format=tsv&query=" + encodeURIComponent( adql );
      return this.downloadText( url, fileName );
   };

   this.querySimbad = function( metadata )
   {
      this.log( "Querying SIMBAD..." );
      var objects = this.querySimbadObjects( metadata );
      var aliasesByOid = this.querySimbadAliases( objects );
      for ( var i = 0; i < objects.length; ++i )
      {
         var oid = objects[i].oid.toString();
         objects[i].aliases = aliasesByOid[oid] ? aliasesByOid[oid] : [];
      }
      return objects;
   };

   this.querySimbadObjects = function( metadata )
   {
      var predicate = this.buildCirclePredicate( metadata );
      var queryLimit = Math.max( this.config.maxObjects * 10, 5000 );
      var adql =
         "SELECT TOP " + queryLimit.toString() + " " +
         "basic.oid, basic.main_id, basic.ra, basic.dec " +
         "FROM basic " +
         "JOIN otypedef ON basic.otype = otypedef.otype " +
         "WHERE " + predicate + " AND otypedef.path LIKE 'G%'";

      var text = this.executeTapQuery( adql, "sky_annotation_simbad_objects.tsv" );
      return this.parseObjectRows( text );
   };

   this.querySimbadAliases = function( objects )
   {
      var aliasesByOid = {};
      if ( objects.length == 0 )
         return aliasesByOid;

      var chunkSize = 120;
      for ( var offset = 0; offset < objects.length; offset += chunkSize )
      {
         var chunk = objects.slice( offset, offset + chunkSize );
         var oidList = [];
         for ( var i = 0; i < chunk.length; ++i )
         {
            oidList.push( chunk[i].oid.toString() );
            aliasesByOid[chunk[i].oid.toString()] = [];
         }

         var adql =
            "SELECT oidref, id " +
            "FROM ident " +
            "WHERE oidref IN (" + oidList.join( "," ) + ")";

         var fileName = "sky_annotation_simbad_aliases_" + offset.toString() + ".tsv";
         var text = this.executeTapQuery( adql, fileName );
         var aliasRows = this.parseAliasRows( text );
         for ( var j = 0; j < aliasRows.length; ++j )
         {
            var row = aliasRows[j];
            if ( !aliasesByOid[row.oid] )
               aliasesByOid[row.oid] = [];
            if ( aliasesByOid[row.oid].indexOf( row.aliasId ) < 0 )
               aliasesByOid[row.oid].push( row.aliasId );
         }
      }

      return aliasesByOid;
   };

   this.parseObjectRows = function( text )
   {
      var rows = [];
      var lines = text.replace( /\r/g, "" ).split( "\n" );
      for ( var i = 0; i < lines.length; ++i )
      {
         var line = lines[i];
         if ( !line || line.length == 0 )
            continue;
         if ( line.charAt( 0 ) == '#' )
            continue;
         if ( line.indexOf( "oid" ) == 0 )
            continue;

         var parts = line.split( "\t" );
         if ( parts.length < 4 )
            continue;

         rows.push(
            {
               oid: this.cleanText( parts[0] ),
               mainId: this.cleanText( parts[1] ),
               ra: parseFloat( parts[2] ),
               dec: parseFloat( parts[3] ),
               aliases: []
            }
         );
      }
      return rows;
   };

   this.parseAliasRows = function( text )
   {
      var rows = [];
      var lines = text.replace( /\r/g, "" ).split( "\n" );
      for ( var i = 0; i < lines.length; ++i )
      {
         var line = lines[i];
         if ( !line || line.length == 0 )
            continue;
         if ( line.charAt( 0 ) == '#' )
            continue;
         if ( line.indexOf( "oidref" ) == 0 )
            continue;

         var parts = line.split( "\t" );
         if ( parts.length < 2 )
            continue;

         rows.push(
            {
               oid: this.cleanText( parts[0] ),
               aliasId: this.cleanText( parts[1] )
            }
         );
      }
      return rows;
   };

   this.cleanText = function( text )
   {
      if ( text == null )
         return "";
      var s = text.toString();
      s = s.replace( /^"+|"+$/g, "" );
      return s.replace( /^\s+|\s+$/g, "" );
   };

   this.normaliseAlias = function( text )
   {
      return this.cleanText( text ).replace( /\s+/g, " " );
   };

   this.matchCatalogueType = function( name )
   {
      var text = this.normaliseAlias( name );
      var compact = text.replace( /\s+/g, "" ).toUpperCase();
      var patterns = [
         ["2MFGC", function( t, c ) { return c.indexOf( "2MFGC" ) >= 0; }],
         ["2MASX", function( t, c ) { return c.indexOf( "2MASX" ) >= 0; }],
         ["2MASS", function( t, c ) { return c.indexOf( "2MASS" ) >= 0; }],
         ["SDSS", function( t, c ) { return c.indexOf( "SDSS" ) >= 0 || c.indexOf( "SDSSCGB" ) >= 0; }],
         ["UGCA", function( t, c ) { return c.indexOf( "UGCA" ) >= 0; }],
         ["UGC", function( t, c ) { return /\bUGC\b/i.test( t ); }],
         ["NGC", function( t, c ) { return /\bNGC\b/i.test( t ); }],
         ["IC", function( t, c ) { return /\bIC\b/i.test( t ); }],
         ["LEDA", function( t, c ) { return c.indexOf( "LEDA" ) >= 0; }],
         ["Gaia", function( t, c ) { return c.indexOf( "GAIA" ) >= 0; }],
         ["SAI", function( t, c ) { return c.indexOf( "SAI" ) >= 0; }],
         ["FIRST", function( t, c ) { return c.indexOf( "FIRST" ) >= 0; }],
         ["MFGC", function( t, c ) { return c.indexOf( "MFGC" ) >= 0; }],
         ["MGC", function( t, c ) { return /\bMGC\b/i.test( t ); }],
         ["MRK", function( t, c ) { return c.indexOf( "MRK" ) >= 0; }],
         ["MCG", function( t, c ) { return c.indexOf( "MCG" ) >= 0; }],
         ["MASS", function( t, c ) { return c.indexOf( "MASS" ) >= 0; }],
         ["M", function( t, c ) { return /\bM\s*\d+\b/i.test( t ); }]
      ];

      for ( var i = 0; i < patterns.length; ++i )
         if ( patterns[i][1]( text, compact ) )
            return patterns[i][0];
      return "";
   };

   this.cataloguePriority = function( catalogueType )
   {
      var order = {
         "M": 1, "NGC": 2, "IC": 3, "UGC": 4, "UGCA": 5, "MCG": 6,
         "MRK": 7, "MGC": 8, "LEDA": 9, "2MASX": 10, "2MASS": 11,
         "SDSS": 12, "Gaia": 13, "SAI": 14, "FIRST": 15, "MFGC": 16,
         "2MFGC": 17, "MASS": 18
      };
      return order[catalogueType] ? order[catalogueType] : 999;
   };

   this.isGroupLikeName = function( name )
   {
      var text = this.normaliseAlias( name ).toUpperCase();
      if ( text.length == 0 )
         return false;

      if ( /\b(GROUP|TRIPLET|CLUSTER|ASSOCIATION)\b/.test( text ) )
         return true;

      // SIMBAD can return "DWH M 82 3"-style sub-components before the
      // canonical Messier object. They are useful aliases, not primary panels.
      return /^DWH\s+M\s*\d+\s+\d+\b/.test( text );
   };

   this.isMainObjectCandidate = function( object )
   {
      var mainObject = this.normalisedMainObject();
      if ( mainObject.length == 0 || !object )
         return false;

      var displayCompact = this.normaliseAlias( object.displayId ).replace( /\s+/g, "" ).toUpperCase();
      var mainCompact = this.normaliseAlias( object.mainId ).replace( /\s+/g, "" ).toUpperCase();
      if ( displayCompact == mainObject || mainCompact == mainObject )
         return true;

      var displayParent = this.extractParentObjectId( object.displayId );
      var mainParent = this.extractParentObjectId( object.mainId );
      return displayParent == mainObject || mainParent == mainObject || object.familyKey == mainObject;
   };

   this.chooseDisplayId = function( mainId, aliases )
   {
      var best = this.normaliseAlias( mainId );
      var bestScore = this.cataloguePriority( this.matchCatalogueType( best ) );
      var candidates = [best];
      for ( var i = 0; i < aliases.length; ++i )
         candidates.push( this.normaliseAlias( aliases[i] ) );

      for ( var j = 0; j < candidates.length; ++j )
      {
         var candidate = candidates[j];
         if ( candidate.length == 0 )
            continue;
         if ( this.isGroupLikeName( candidate ) )
            continue;
         var score = this.cataloguePriority( this.matchCatalogueType( candidate ) );
         if ( score < bestScore || (score == bestScore && candidate.length < best.length) )
         {
            best = candidate;
            bestScore = score;
         }
      }

      return best;
   };

   this.extractParentObjectId = function( name )
   {
      var text = this.normaliseAlias( name );
      if ( text.length == 0 )
         return "";

      text = text.replace( /^\[[^\]]+\]\s*/, "" );
      var patterns = [
         [/^M\s*([0-9]+)\b/i, "M$1"],
         [/^NGC\s*([0-9A-Z]+)\b/i, "NGC$1"],
         [/^IC\s*([0-9A-Z]+)\b/i, "IC$1"],
         [/^UGCA\s*([0-9A-Z-]+)\b/i, "UGCA$1"],
         [/^UGC\s*([0-9A-Z-]+)\b/i, "UGC$1"],
         [/^LEDA\s*([0-9]+)\b/i, "LEDA$1"],
         [/^MRK\s*([0-9A-Z]+)\b/i, "MRK$1"],
         [/^MGC\s*([0-9A-Z]+)\b/i, "MGC$1"],
         [/^MCG\s*([+\-0-9]+-[0-9]+-[0-9]+)\b/i, "MCG$1"],
         [/^2MASX\s+([A-Z0-9+\-.]+)\b/i, "2MASX$1"],
         [/^2MASS\s+([A-Z0-9+\-.]+)\b/i, "2MASS$1"],
         [/^2MFGC\s*([0-9]+)\b/i, "2MFGC$1"],
         [/^SDSS\s+([A-Z0-9+\-.]+)\b/i, "SDSS$1"],
         [/^SAI\s*([0-9]+)\b/i, "SAI$1"],
         [/^Gaia\s+DR3\s+([0-9]+)\b/i, "GaiaDR3$1"]
      ];

      for ( var i = 0; i < patterns.length; ++i )
      {
         var m = text.match( patterns[i][0] );
         if ( m )
            return patterns[i][1].replace( "$1", m[1].toUpperCase() );
      }

      return "";
   };

   this.looksLikeSubobject = function( name )
   {
      var text = this.normaliseAlias( name );
      return text.indexOf( "[" ) == 0 || /\bM\s*\d+\s+\d+\b/i.test( text );
   };

   this.objectFamilyKey = function( displayId, aliases, mainId )
   {
      var keys = [];
      var k = this.extractParentObjectId( displayId );
      if ( k.length > 0 )
         keys.push( k );
      k = this.extractParentObjectId( mainId );
      if ( k.length > 0 )
         keys.push( k );

      for ( var i = 0; i < aliases.length; ++i )
      {
         k = this.extractParentObjectId( aliases[i] );
         if ( k.length > 0 )
            keys.push( k );
      }

      if ( keys.length == 0 )
         return "";

      keys.sort( function( a, b )
      {
         var pa = this.cataloguePriority( this.matchCatalogueType( a ) );
         var pb = this.cataloguePriority( this.matchCatalogueType( b ) );
         if ( pa != pb )
            return pa - pb;
         return a.length - b.length;
      }.bind( this ) );
      return keys[0];
   };

   this.groupRows = function( rows )
   {
      for ( var i = 0; i < rows.length; ++i )
      {
         rows[i].aliases = rows[i].aliases ? rows[i].aliases : [];
         rows[i].displayId = this.chooseDisplayId( rows[i].mainId, rows[i].aliases );
         rows[i].catalogueType = this.matchCatalogueType( rows[i].displayId );
         if ( rows[i].catalogueType.length == 0 )
            rows[i].catalogueType = this.matchCatalogueType( rows[i].mainId );
         rows[i].familyKey = this.objectFamilyKey( rows[i].displayId, rows[i].aliases, rows[i].mainId );
         rows[i].isSubobject =
            this.looksLikeSubobject( rows[i].displayId ) ||
            this.looksLikeSubobject( rows[i].mainId );
      }
      return rows;
   };

   this.filterObjects = function( objects )
   {
      var keepPrefixes = {};
      for ( var i = 0; i < this.config.filterPrefixes.length; ++i )
         keepPrefixes[this.config.filterPrefixes[i]] = true;

      var filtered = [];
      for ( var j = 0; j < objects.length; ++j )
      {
         if ( !this.isMainObjectCandidate( objects[j] ) && this.isGroupLikeName( objects[j].displayId ) )
            continue;
         if ( !this.isMainObjectCandidate( objects[j] ) && this.isGroupLikeName( objects[j].mainId ) )
            continue;

         if ( keepPrefixes[objects[j].catalogueType] )
            filtered.push( objects[j] );
      }
      return filtered;
   };

   this.projectObjects = function( metadata, objects )
   {
      var projected = [];
      for ( var i = 0; i < objects.length; ++i )
      {
         var p = metadata.Convert_RD_I( new Point( objects[i].ra, objects[i].dec ), true );
         if ( !p )
            continue;
         if ( p.x < 0 || p.y < 0 || p.x >= metadata.width || p.y >= metadata.height )
            continue;
         objects[i].px = p.x;
         objects[i].py = p.y;
         projected.push( objects[i] );
      }
      return projected;
   };

   this.dedupeFamilies = function( objects )
   {
      var byFamily = {};
      var deduped = [];

      for ( var i = 0; i < objects.length; ++i )
      {
         var object = objects[i];
         if ( object.familyKey.length == 0 )
         {
            deduped.push( object );
            continue;
         }

         if ( !byFamily[object.familyKey] )
            byFamily[object.familyKey] = [];
         byFamily[object.familyKey].push( object );
      }

      for ( var familyKey in byFamily )
      {
         var family = byFamily[familyKey];
         var canonical = null;
         for ( var j = 0; j < family.length; ++j )
         {
            var item = family[j];
            if ( this.extractParentObjectId( item.displayId ) == familyKey && !item.isSubobject )
            {
               if ( canonical == null || item.displayId.length < canonical.displayId.length )
                  canonical = item;
            }
         }

         if ( canonical != null )
         {
            deduped.push( canonical );
            continue;
         }

         family.sort( function( a, b )
         {
            var pa = this.cataloguePriority( a.catalogueType );
            var pb = this.cataloguePriority( b.catalogueType );
            if ( pa != pb )
               return pa - pb;
            return a.displayId.length - b.displayId.length;
         }.bind( this ) );
         deduped.push( family[0] );
      }

      deduped.sort( function( a, b )
      {
         var pa = this.cataloguePriority( a.catalogueType );
         var pb = this.cataloguePriority( b.catalogueType );
         if ( pa != pb )
            return pa - pb;
         return a.displayId < b.displayId ? -1 : 1;
      }.bind( this ) );

      return deduped;
   };

   this.sortObjects = function( objects )
   {
      objects.sort( function( a, b )
      {
         var ma = this.isMainObjectCandidate( a ) ? 0 : 1;
         var mb = this.isMainObjectCandidate( b ) ? 0 : 1;
         if ( ma != mb )
            return ma - mb;

         var pa = this.cataloguePriority( a.catalogueType );
         var pb = this.cataloguePriority( b.catalogueType );
         if ( pa != pb )
            return pa - pb;
         return a.displayId < b.displayId ? -1 : (a.displayId > b.displayId ? 1 : 0);
      }.bind( this ) );
      return objects;
   };

   this.normalisedMainObject = function()
   {
      return this.normaliseAlias( this.config.mainObject ).replace( /\s+/g, "" ).toUpperCase();
   };

   this.getPatchSize = function( object )
   {
      var displayCompact = this.normaliseAlias( object.displayId ).replace( /\s+/g, "" ).toUpperCase();
      var mainObject = this.normalisedMainObject();
      var baseSize = Math.max( 24, Math.round( this.config.boxSize ) );
      var patchSize = Math.round( baseSize / 3 );

      if ( mainObject.length > 0 && displayCompact == mainObject )
         patchSize = Math.round( baseSize * 10.6667 );
      else if ( object.catalogueType == "M" )
         patchSize = Math.round( baseSize * 5.3333 );
      else if ( object.catalogueType == "NGC" || object.catalogueType == "IC" )
         patchSize = Math.round( baseSize * 2.6667 );
      else if ( object.catalogueType == "SAI" || object.catalogueType == "Gaia" )
         patchSize = Math.round( baseSize * 1.3333 );
      else if ( object.catalogueType == "UGC" || object.catalogueType == "UGCA" )
         patchSize = Math.round( baseSize * 1.1667 );
      else if ( object.catalogueType == "MCG" )
         patchSize = Math.round( baseSize * 1.1667 );
      else if ( object.catalogueType == "MFGC" || object.catalogueType == "2MFGC" )
         patchSize = baseSize;
      else if ( object.catalogueType == "2MASX" || object.catalogueType == "SDSS" )
         patchSize = Math.round( baseSize * 0.5 );
      else if (
         object.catalogueType == "LEDA" ||
         object.catalogueType == "MRK" ||
         object.catalogueType == "MGC" ||
         object.catalogueType == "2MASS"
      )
         patchSize = Math.round( baseSize / 3 );

      if ( object.isSubobject )
         patchSize = Math.min( patchSize, 96 );
      else if (
         object.catalogueType == "2MASX" ||
         object.catalogueType == "SDSS" ||
         object.catalogueType == "UGC" ||
         object.catalogueType == "UGCA" ||
         object.catalogueType == "MFGC" ||
         object.catalogueType == "2MFGC"
      )
         patchSize = Math.round( patchSize * 1.25 );

      return Math.max( 24, Math.round( patchSize * this.config.patchScale ) );
   };

   this.buildBox = function( px, py, patchSize )
   {
      var half = Math.floor( patchSize / 2 );
      return {
         left: Math.round( px - half ),
         top: Math.round( py - half ),
         right: Math.round( px - half + patchSize ),
         bottom: Math.round( py - half + patchSize )
      };
   };

   this.buildClampedSquareBox = function( px, py, size, width, height )
   {
      size = Math.round( Math.min( Math.max( size, 1 ), Math.min( width, height ) ) );
      var half = Math.floor( size / 2 );
      var left = Math.round( px - half );
      var top = Math.round( py - half );
      left = Math.max( 0, Math.min( width - size, left ) );
      top = Math.max( 0, Math.min( height - size, top ) );
      return {
         left: left,
         top: top,
         right: left + size,
         bottom: top + size
      };
   };

   this.boxFits = function( box, width, height )
   {
      return box.left >= 0 && box.top >= 0 && box.right <= width && box.bottom <= height;
   };

   this.overlapRatio = function( a, b )
   {
      var left = Math.max( a.left, b.left );
      var top = Math.max( a.top, b.top );
      var right = Math.min( a.right, b.right );
      var bottom = Math.min( a.bottom, b.bottom );
      if ( right <= left || bottom <= top )
         return 0;

      var intersection = (right - left) * (bottom - top);
      var area = Math.max( 1, (a.right - a.left) * (a.bottom - a.top) );
      return intersection / area;
   };

   this.maxOverlapRatio = function( box, boxes )
   {
      var maxOverlap = 0;
      for ( var i = 0; i < boxes.length; ++i )
         maxOverlap = Math.max( maxOverlap, this.overlapRatio( box, boxes[i] ) );
      return maxOverlap;
   };

   this.adjustPatchSizeForOverlap = function( px, py, patchSize, acceptedBoxes, width, height )
   {
      var candidate = patchSize;
      var minimum = 48;
      while ( candidate > minimum )
      {
         var box = this.buildBox( px, py, candidate );
         if ( this.boxFits( box, width, height ) && this.maxOverlapRatio( box, acceptedBoxes ) <= 0.72 )
            return candidate;
         candidate = Math.max( minimum, Math.round( candidate * 0.78 ) );
      }
      return candidate;
   };

   this.isLowPriorityDuplicateCandidate = function( object )
   {
      if ( this.isMainObjectCandidate( object ) )
         return false;

      return this.cataloguePriority( object.catalogueType ) >= 9;
   };

   this.shouldSkipDuplicateCrop = function( object, box, accepted )
   {
      if ( !this.isLowPriorityDuplicateCandidate( object ) )
         return false;

      var cx = (box.left + box.right) / 2;
      var cy = (box.top + box.bottom) / 2;
      var size = Math.max( box.right - box.left, box.bottom - box.top );

      for ( var i = 0; i < accepted.length; ++i )
      {
         var other = accepted[i];
         if ( !this.isLowPriorityDuplicateCandidate( other ) && this.cataloguePriority( other.catalogueType ) > 6 )
            continue;

         var otherBox = other.box;
         var ox = (otherBox.left + otherBox.right) / 2;
         var oy = (otherBox.top + otherBox.bottom) / 2;
         var otherSize = Math.max( otherBox.right - otherBox.left, otherBox.bottom - otherBox.top );
         var distance = Math.sqrt( (cx - ox) * (cx - ox) + (cy - oy) * (cy - oy) );

         if ( distance <= Math.max( 10, Math.min( size, otherSize ) * 0.45 ) )
            return true;

         if ( this.overlapRatio( box, otherBox ) >= 0.42 || this.overlapRatio( otherBox, box ) >= 0.42 )
            return true;
      }

      return false;
   };

   this.chooseAcceptedObjects = function( imageWindow, objects )
   {
      var width = imageWindow.mainView.image.width;
      var height = imageWindow.mainView.image.height;
      var accepted = [];
      var acceptedBoxes = [];
      objects = this.sortObjects( objects.slice( 0 ) );

      for ( var i = 0; i < objects.length; ++i )
      {
         var object = objects[i];
         var patchSize = this.adjustPatchSizeForOverlap(
            object.px,
            object.py,
            this.getPatchSize( object ),
            acceptedBoxes,
            width,
            height
         );
         var box = this.buildBox( object.px, object.py, patchSize );
         if ( !this.boxFits( box, width, height ) )
            continue;
         if ( this.shouldSkipDuplicateCrop( object, box, accepted ) )
            continue;

         object.patchSize = patchSize;
         object.box = box;
         accepted.push( object );
         acceptedBoxes.push( box );
      }

      return accepted;
   };

   this.labelText = function( index, displayId )
   {
      if ( this.config.labelMode == "Object IDs" )
         return displayId;
      if ( this.config.labelMode == "Numbers + IDs" )
         return index.toString() + ": " + displayId;
      return index.toString();
   };

   this.getViewBitmap = function( view )
   {
      var image = view.image;
      var tmp = null;
      try
      {
         tmp = new ImageWindow(
            image.width, image.height, image.numberOfChannels,
            view.window.bitsPerSample, view.window.isFloatSample,
            image.isColor, "SkyAnnotationStudioTmp"
         );
         tmp.mainView.beginProcess( UndoFlag_NoSwapFile );
         tmp.mainView.image.apply( image );
         tmp.mainView.endProcess();
         var bmp = new Bitmap( image.width, image.height );
         bmp.assign( tmp.mainView.image.render() );
         return bmp;
      }
      finally
      {
         if ( tmp )
            tmp.forceClose();
      }
   };

   this.getWindowBitmap = function( imageWindow )
   {
      return this.getViewBitmap( imageWindow.mainView );
   };

   this.renderAnnotatedBitmap = function( imageWindow, objects )
   {
      var bmp = this.getWindowBitmap( imageWindow );
      var g = new Graphics( bmp );
      g.transparentBackground = true;
      g.antialiasing = true;
      g.pen = new Pen( 0x80ffffff, 1 );

      for ( var i = 0; i < objects.length; ++i )
      {
         var o = objects[i];
         var x0 = o.box.left;
         var y0 = o.box.top;
         var x1 = o.box.right;
         var y1 = o.box.bottom;
         g.drawRect( x0, y0, x1, y1 );
         g.pen = new Pen( 0xff2d9cff, 1 );
         g.drawText( x0, y1 + 24, this.labelText( i + 1, o.displayId ) );
         g.pen = new Pen( 0x80ffffff, 1 );
      }
      g.end();
      return bmp;
   };

   this.uniqueWindowId = function( baseId )
   {
      var outId = baseId;
      while ( !View.viewById( outId ).isNull )
         outId += "1";
      return outId;
   };

   this.bitmapToWindow = function( bmp, templateWindow, outId )
   {
      var result = new ImageWindow( bmp.width, bmp.height, 3, 8, false, true, this.uniqueWindowId( outId ) );
      result.mainView.beginProcess( UndoFlag_NoSwapFile );
      result.mainView.image.blend( bmp );
      result.mainView.endProcess();
      result.keywords = templateWindow.keywords;
      result.zoomToFit();
      result.show();
      return result;
   };

   this.renderAnnotatedWindow = function( imageWindow, objects )
   {
      return this.bitmapToWindow(
         this.renderAnnotatedBitmap( imageWindow, objects ),
         imageWindow,
         imageWindow.mainView.id + "_SkyAnnot"
      );
   };

   this.truncateText = function( text, maxLength )
   {
      if ( text.length <= maxLength )
         return text;
      return text.substr( 0, Math.max( 3, maxLength - 3 ) ) + "...";
   };

   this.bitmapLuminance = function( pixel )
   {
      var r = (pixel >> 16) & 0xff;
      var g = (pixel >> 8) & 0xff;
      var b = pixel & 0xff;
      return 0.2126 * r + 0.7152 * g + 0.0722 * b;
   };

   this.quantile = function( values, q )
   {
      if ( values.length == 0 )
         return 0;
      var index = Math.max( 0, Math.min( values.length - 1, Math.round( q * (values.length - 1) ) ) );
      return values[index];
   };

   this.patchVisibilityThreshold = function( object )
   {
      if ( this.config.visibilityMode == "Off" )
         return 0;
      if ( this.isMainObjectCandidate( object ) )
         return 0;

      var priority = this.cataloguePriority( object.catalogueType );
      if ( priority <= 6 )
         return 0;

      var threshold = 6.5;
      if ( object.catalogueType == "LEDA" || object.catalogueType == "MRK" || object.catalogueType == "MGC" )
         threshold = 5.5;
      else if ( object.catalogueType == "2MASX" || object.catalogueType == "2MASS" || object.catalogueType == "SDSS" )
         threshold = 7.0;
      else if ( object.catalogueType == "Gaia" || object.catalogueType == "SAI" || object.catalogueType == "FIRST" )
         threshold = 8.0;

      if ( this.config.visibilityMode == "Permissive" )
         threshold *= 0.75;
      else if ( this.config.visibilityMode == "Strict" )
         threshold *= 1.35;

      return threshold;
   };

   this.patchLooksVisible = function( bitmap, object )
   {
      var threshold = this.patchVisibilityThreshold( object );
      if ( threshold <= 0 )
         return true;

      var samples = [];
      var stepX = Math.max( 1, Math.floor( bitmap.width / 34 ) );
      var stepY = Math.max( 1, Math.floor( bitmap.height / 34 ) );
      var marginX = Math.max( 1, Math.floor( bitmap.width * 0.06 ) );
      var marginY = Math.max( 1, Math.floor( bitmap.height * 0.06 ) );

      for ( var y = marginY; y < bitmap.height - marginY; y += stepY )
         for ( var x = marginX; x < bitmap.width - marginX; x += stepX )
            samples.push( this.bitmapLuminance( bitmap.pixel( x, y ) ) );

      if ( samples.length < 16 )
         return true;

      samples.sort( function( a, b ) { return a - b; } );
      var median = this.quantile( samples, 0.50 );
      var p95 = this.quantile( samples, 0.95 );
      var p99 = this.quantile( samples, 0.99 );

      var cx = Math.floor( bitmap.width / 2 );
      var cy = Math.floor( bitmap.height / 2 );
      var radius = Math.max( 2, Math.floor( Math.min( bitmap.width, bitmap.height ) * 0.08 ) );
      var centreSum = 0;
      var centreCount = 0;
      for ( var yy = cy - radius; yy <= cy + radius; yy += Math.max( 1, Math.floor( radius / 2 ) ) )
      {
         if ( yy < 0 || yy >= bitmap.height )
            continue;
         for ( var xx = cx - radius; xx <= cx + radius; xx += Math.max( 1, Math.floor( radius / 2 ) ) )
         {
            if ( xx < 0 || xx >= bitmap.width )
               continue;
            centreSum += this.bitmapLuminance( bitmap.pixel( xx, yy ) );
            ++centreCount;
         }
      }

      var centreLift = centreCount > 0 ? centreSum / centreCount - median : 0;
      var contrastScore = Math.max( p95 - median, (p99 - median) * 0.65, centreLift );
      object.visibilityScore = contrastScore;
      return contrastScore >= threshold;
   };

   this.finalObjectSortRank = function( object, imageWindow )
   {
      var rank = {
         main: this.isMainObjectCandidate( object ) ? 0 : 1,
         primary: this.cataloguePriority( object.catalogueType ),
         secondary: object.displayId
      };

      if ( this.config.sortMode == "Visible size" )
      {
         rank.primary = -Math.round( object.patchSize ? object.patchSize : this.getPatchSize( object ) );
         rank.secondary = this.cataloguePriority( object.catalogueType ).toString() + ":" + object.displayId;
      }
      else if ( this.config.sortMode == "Image contrast" )
      {
         rank.primary = -Math.round( 1000 * (object.visibilityScore ? object.visibilityScore : 0) );
         rank.secondary = this.cataloguePriority( object.catalogueType ).toString() + ":" + object.displayId;
      }
      else if ( this.config.sortMode == "Distance from centre" )
      {
         var cx = imageWindow.mainView.image.width / 2;
         var cy = imageWindow.mainView.image.height / 2;
         var dx = object.px - cx;
         var dy = object.py - cy;
         rank.primary = Math.round( Math.sqrt( dx * dx + dy * dy ) );
         rank.secondary = this.cataloguePriority( object.catalogueType ).toString() + ":" + object.displayId;
      }
      else if ( this.config.sortMode == "Name" )
      {
         rank.primary = 0;
         rank.secondary = object.displayId;
      }

      return rank;
   };

   this.sortPatchesForOutput = function( patches, imageWindow )
   {
      patches.sort( function( a, b )
      {
         var ra = this.finalObjectSortRank( a.object, imageWindow );
         var rb = this.finalObjectSortRank( b.object, imageWindow );
         if ( ra.main != rb.main )
            return ra.main - rb.main;
         if ( ra.primary != rb.primary )
            return ra.primary - rb.primary;
         return ra.secondary < rb.secondary ? -1 : (ra.secondary > rb.secondary ? 1 : 0);
      }.bind( this ) );
      return patches;
   };

   this.collectPatchBitmaps = function( imageWindow, objects )
   {
      var patches = [];
      var skipped = 0;
      var createdIds = [];
      try
      {
         for ( var i = 0; i < objects.length; ++i )
         {
            var object = objects[i];
            var previewId = "SkyAnnotPatch_" + (i + 1).toString();
            var rect = new Rect( object.box.left, object.box.top, object.box.right, object.box.bottom );
            imageWindow.createPreview( rect, previewId );
            createdIds.push( previewId );

            var previewView = imageWindow.previewById( previewId );
            var patchBmp = this.getViewBitmap( previewView );
            if ( patchBmp.width != this.config.previewPatchSize || patchBmp.height != this.config.previewPatchSize )
               patchBmp = patchBmp.scaledTo( this.config.previewPatchSize, this.config.previewPatchSize );

            if ( !this.patchLooksVisible( patchBmp, object ) )
            {
               ++skipped;
               continue;
            }

            patches.push( { object: object, bitmap: patchBmp } );
         }
      }
      finally
      {
         for ( var j = 0; j < createdIds.length; ++j )
         {
            var preview = imageWindow.previewById( createdIds[j] );
            if ( preview && !preview.isNull )
               imageWindow.deletePreview( preview );
         }
      }

      if ( skipped > 0 )
         this.log( "Visibility filter removed " + skipped.toString() + " low-contrast preview patches." );

      return patches;
   };

   this.buildGridBitmapFromPatches = function( patches )
   {
      if ( patches.length == 0 )
         throw new Error( "No preview patches could be generated." );

      var tile = this.config.previewPatchSize;
      var topLabel = 34;
      var bottomLabel = 24;
      var gutter = 8;
      var margin = 8;
      var cols = Math.max( 1, Math.ceil( Math.sqrt( patches.length ) ) );
      var rows = Math.max( 1, Math.ceil( patches.length / cols ) );
      var cellHeight = topLabel + tile + bottomLabel;
      var width = margin * 2 + cols * tile + (cols - 1) * gutter;
      var height = margin * 2 + rows * cellHeight + (rows - 1) * gutter;
      var bmp = new Bitmap( width, height );
      bmp.fill( 0xff000000 );
      var g = new VectorGraphics( bmp );
      g.transparentBackground = true;
      g.antialiasing = true;
      g.font = new Font( "Helvetica", 10 );

      for ( var i = 0; i < patches.length; ++i )
      {
         var col = i % cols;
         var row = Math.floor( i / cols );
         var x = margin + col * (tile + gutter);
         var y = margin + row * (cellHeight + gutter);
         var patch = patches[i];
         g.pen = new Pen( 0xff2d9cff, 1 );
         g.drawText( x + 2, y + 22, (i + 1).toString() );
         g.pen = new Pen( 0xffffffff, 1 );
         g.drawBitmap( x, y + topLabel, patch.bitmap );
         g.drawRect( x, y + topLabel, x + tile, y + topLabel + tile );
         g.drawText( x, y + topLabel + tile + 18, this.truncateText( patch.object.displayId, 20 ) );
      }
      g.end();
      return bmp;
   };

   this.buildGridBitmap = function( imageWindow, objects )
   {
      return this.buildGridBitmapFromPatches( this.collectPatchBitmaps( imageWindow, objects ) );
   };

   this.buildFinalCompositeBitmap = function( overviewBitmap, gridBitmap )
   {
      var scaledGrid = gridBitmap;
      if ( gridBitmap.width != overviewBitmap.width )
      {
         var scaledHeight = Math.max( 1, Math.round( gridBitmap.height * overviewBitmap.width / gridBitmap.width ) );
         scaledGrid = gridBitmap.scaledTo( overviewBitmap.width, scaledHeight );
      }

      var finalBmp = new Bitmap( overviewBitmap.width, overviewBitmap.height + scaledGrid.height );
      finalBmp.fill( 0xff000000 );
      var g = new VectorGraphics( finalBmp );
      g.drawBitmap( 0, 0, overviewBitmap );
      g.drawBitmap( 0, overviewBitmap.height, scaledGrid );
      g.end();
      return finalBmp;
   };

   this.exportCsv = function( objects, filePath )
   {
      var lines = ["index,display_id,main_id,catalogue_type,ra_deg,dec_deg,px,py,patch_size,visibility_score"];
      for ( var i = 0; i < objects.length; ++i )
      {
         var o = objects[i];
         lines.push(
            (i + 1).toString() + "," +
            "\"" + o.displayId.replace( /"/g, "\"\"" ) + "\"," +
            "\"" + o.mainId.replace( /"/g, "\"\"" ) + "\"," +
            o.catalogueType + "," +
            format( "%.10f", o.ra ) + "," +
            format( "%.10f", o.dec ) + "," +
            format( "%.2f", o.px ) + "," +
            format( "%.2f", o.py ) + "," +
            format( "%.0f", o.patchSize ? o.patchSize : 0 ) + "," +
            format( "%.3f", o.visibilityScore ? o.visibilityScore : 0 )
         );
      }
      File.writeTextFile( filePath, lines.join( "\n" ) );
   };

   this.run = function()
   {
      var opened = this.currentWindow();
      try
      {
         this.log( "Extracting astrometric metadata..." );
         var metadata = opened.metadata ? opened.metadata : this.extractMetadata( opened.window );
         this.log( "Image centre: RA " + format( "%.6f", metadata.ra ) + " deg, Dec " + format( "%.6f", metadata.dec ) + " deg" );

         var rawRows = this.querySimbad( metadata );
         this.log( "SIMBAD rows: " + rawRows.length.toString() );

         var objects = this.groupRows( rawRows );
         objects = this.filterObjects( objects );
         objects = this.projectObjects( metadata, objects );
         objects = this.dedupeFamilies( objects );
         objects = this.sortObjects( objects );
         this.log( "Objects kept after filtering and deduplication: " + objects.length.toString() );

         if ( objects.length == 0 )
            throw new Error( "No matching catalogue objects were found inside the image bounds." );

         var acceptedObjects = this.chooseAcceptedObjects( opened.window, objects );
         if ( acceptedObjects.length > this.config.maxObjects )
            acceptedObjects = acceptedObjects.slice( 0, this.config.maxObjects );
         this.log( "Objects kept after crop validation: " + acceptedObjects.length.toString() );
         if ( acceptedObjects.length == 0 )
            throw new Error( "Objects were found, but none could be cropped safely inside the image bounds." );

         this.log( "Building preview grid..." );
         var patches = this.collectPatchBitmaps( opened.window, acceptedObjects );
         if ( patches.length == 0 )
            throw new Error( "Objects were found, but no visible preview patches could be generated." );

         patches = this.sortPatchesForOutput( patches, opened.window );
         acceptedObjects = [];
         for ( var patchIndex = 0; patchIndex < patches.length; ++patchIndex )
            acceptedObjects.push( patches[patchIndex].object );

         this.log( "Objects kept after visibility filtering: " + acceptedObjects.length.toString() );
         this.log( "Output sort mode: " + this.config.sortMode + "; visibility filter: " + this.config.visibilityMode + "." );
         this.log( "Rendering annotated overview..." );
         var overviewBitmap = this.renderAnnotatedBitmap( opened.window, acceptedObjects );
         var gridBitmap = this.buildGridBitmapFromPatches( patches );
         this.log( "Composing final stacked output..." );
         var finalBitmap = this.buildFinalCompositeBitmap( overviewBitmap, gridBitmap );

         var overviewWindow = this.bitmapToWindow( overviewBitmap, opened.window, opened.window.mainView.id + "_SkyAnnotOverview" );
         var gridWindow = this.bitmapToWindow( gridBitmap, opened.window, opened.window.mainView.id + "_SkyAnnotGrid" );
         var finalWindow = this.bitmapToWindow( finalBitmap, opened.window, opened.window.mainView.id + "_SkyAnnotFinal" );
         this.log( "Created overview, grid, and final composite windows." );

         return {
         objects: acceptedObjects,
         patches: patches,
         sourceWindow: opened.window,
         overviewBitmap: overviewBitmap,
         gridBitmap: gridBitmap,
         finalBitmap: finalBitmap,
            overviewWindow: overviewWindow,
            gridWindow: gridWindow,
            finalWindow: finalWindow
         };
      }
      finally
      {
         if ( opened.temporary )
            opened.window.forceClose();
      }
   };
}

function SkyAnnotationDialog()
{
   this.__base__ = Dialog;
   this.__base__();

   var dialog = this;
   this.config = new SkyAnnotationConfig();
   this.resultObjects = [];
   this.resultPatches = [];
   this.lastResult = null;
   this.selectedPreviewBitmap = null;
   this.selectedContextBitmap = null;
   this.selectedObject = null;
   this.selectedPreviewTitle = "Select a result row to inspect its crop.";

   this.windowModeLabel = new Label( this );
   this.windowModeLabel.text = "Source";
   this.windowModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.windowModeLabel.minWidth = 120;
   this.windowModeLabel.toolTip =
      "Choose whether the script annotates the currently active PixInsight image or opens a FITS/XISF file from disk.";

   this.windowModeCombo = new ComboBox( this );
   this.windowModeCombo.addItem( "Active image" );
   this.windowModeCombo.addItem( "File on disk" );
   this.windowModeCombo.currentItem = this.config.useActiveWindow ? 0 : 1;
   this.windowModeCombo.toolTip = this.windowModeLabel.toolTip;
   this.windowModeCombo.onItemSelected = function( index )
   {
      this.dialog.config.useActiveWindow = index == 0;
      this.dialog.inputFileEdit.enabled = index != 0;
      this.dialog.inputFileButton.enabled = index != 0;
   };

   this.inputFileLabel = new Label( this );
   this.inputFileLabel.text = "FITS/XISF file";
   this.inputFileLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.inputFileLabel.minWidth = 120;
   this.inputFileLabel.toolTip =
      "Optional source image path when Source is set to File on disk. The image must have a valid astrometric solution.";

   this.inputFileEdit = new Edit( this );
   this.inputFileEdit.text = this.config.inputFile;
   this.inputFileEdit.enabled = !this.config.useActiveWindow;
   this.inputFileEdit.toolTip = this.inputFileLabel.toolTip;
   this.inputFileEdit.onTextUpdated = function( value )
   {
      this.dialog.config.inputFile = value;
   };

   this.inputFileButton = new PushButton( this );
   this.inputFileButton.text = "Browse";
   this.inputFileButton.enabled = !this.config.useActiveWindow;
   this.inputFileButton.toolTip = "Browse for a solved FITS, FIT, or XISF image file.";
   this.inputFileButton.onClick = function()
   {
      var ofd = new OpenFileDialog();
      ofd.multipleSelections = false;
      ofd.filters = [ [ "Astro images", ".fit", ".fits", ".xisf" ] ];
      if ( ofd.execute() )
      {
         this.dialog.inputFileEdit.text = ofd.fileName;
         this.dialog.config.inputFile = ofd.fileName;
      }
   };

   this.mainObjectLabel = new Label( this );
   this.mainObjectLabel.text = "Main object";
   this.mainObjectLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.mainObjectLabel.minWidth = 120;
   this.mainObjectLabel.toolTip =
      "Preferred primary object, for example M81. Matching objects are sorted first and receive the largest crop by default.";

   this.mainObjectEdit = new Edit( this );
   this.mainObjectEdit.text = this.config.mainObject;
   this.mainObjectEdit.toolTip = this.mainObjectLabel.toolTip;
   this.mainObjectEdit.onTextUpdated = function( value )
   {
      this.dialog.config.mainObject = value;
   };

   this.titleLabel = new Label( this );
   this.titleLabel.text = "Title";
   this.titleLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.titleLabel.minWidth = 120;
   this.titleLabel.toolTip = "Title drawn at the top of the annotated overview image.";

   this.titleEdit = new Edit( this );
   this.titleEdit.text = this.config.photoTitle;
   this.titleEdit.toolTip = this.titleLabel.toolTip;
   this.titleEdit.onTextUpdated = function( value )
   {
      this.dialog.config.photoTitle = value;
   };

   this.filterLabel = new Label( this );
   this.filterLabel.text = "Catalogue filters";
   this.filterLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.filterLabel.minWidth = 120;
   this.filterLabel.toolTip =
      "Comma-separated catalogue/type prefixes to keep. Remove very deep catalogues such as SDSS or Gaia if you want fewer faint candidates.";

   this.filterEdit = new Edit( this );
   this.filterEdit.text = this.config.filterPrefixes.join( "," );
   this.filterEdit.toolTip = this.filterLabel.toolTip;
   this.filterEdit.onTextUpdated = function( value )
   {
      var parts = value.split( "," );
      var list = [];
      for ( var i = 0; i < parts.length; ++i )
      {
         var token = parts[i].replace( /^\s+|\s+$/g, "" );
         if ( token.length > 0 )
            list.push( token );
      }
      this.dialog.config.filterPrefixes = list;
   };

   this.labelModeLabel = new Label( this );
   this.labelModeLabel.text = "Label mode";
   this.labelModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.labelModeLabel.minWidth = 120;
   this.labelModeLabel.toolTip =
      "Controls text drawn next to boxes: compact numbers, object identifiers, or both.";

   this.labelModeCombo = new ComboBox( this );
   this.labelModeCombo.addItem( "Numbers" );
   this.labelModeCombo.addItem( "Object IDs" );
   this.labelModeCombo.addItem( "Numbers + IDs" );
   this.labelModeCombo.currentItem = this.config.labelMode == "Object IDs" ? 1 : (this.config.labelMode == "Numbers + IDs" ? 2 : 0);
   this.labelModeCombo.toolTip = this.labelModeLabel.toolTip;
   this.labelModeCombo.onItemSelected = function( index )
   {
      this.dialog.config.labelMode = index == 1 ? "Object IDs" : (index == 2 ? "Numbers + IDs" : "Numbers");
   };

   this.boxSizeLabel = new Label( this );
   this.boxSizeLabel.text = "Box size";
   this.boxSizeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.boxSizeLabel.minWidth = 120;
   this.boxSizeLabel.toolTip =
      "Base crop size in source pixels. Catalogue type multipliers are applied on top of this, so larger values zoom out every generated object crop.";

   this.boxSizeSpin = new SpinBox( this );
   this.boxSizeSpin.minValue = 24;
   this.boxSizeSpin.maxValue = 1024;
   this.boxSizeSpin.value = Math.round( this.config.boxSize );
   this.boxSizeSpin.toolTip = this.boxSizeLabel.toolTip;
   this.boxSizeSpin.onValueUpdated = function( value )
   {
      this.dialog.config.boxSize = value;
   };

   this.patchScaleLabel = new Label( this );
   this.patchScaleLabel.text = "Patch scale %";
   this.patchScaleLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.patchScaleLabel.minWidth = 120;
   this.patchScaleLabel.toolTip =
      "Global crop scale after catalogue sizing. 100% preserves the automatic crop, lower values zoom in, higher values zoom out.";

   this.patchScaleSpin = new SpinBox( this );
   this.patchScaleSpin.minValue = 25;
   this.patchScaleSpin.maxValue = 400;
   this.patchScaleSpin.value = Math.round( this.config.patchScale * 100 );
   this.patchScaleSpin.toolTip = this.patchScaleLabel.toolTip;
   this.patchScaleSpin.onValueUpdated = function( value )
   {
      this.dialog.config.patchScale = value / 100;
   };

   this.previewPatchSizeLabel = new Label( this );
   this.previewPatchSizeLabel.text = "Preview patch";
   this.previewPatchSizeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.previewPatchSizeLabel.minWidth = 120;
   this.previewPatchSizeLabel.toolTip =
      "Rendered grid tile size in pixels. This changes output resolution/detail, not the sky area selected for each object.";

   this.previewPatchSizeSpin = new SpinBox( this );
   this.previewPatchSizeSpin.minValue = 64;
   this.previewPatchSizeSpin.maxValue = 1024;
   this.previewPatchSizeSpin.value = this.config.previewPatchSize;
   this.previewPatchSizeSpin.toolTip = this.previewPatchSizeLabel.toolTip;
   this.previewPatchSizeSpin.onValueUpdated = function( value )
   {
      this.dialog.config.previewPatchSize = value;
   };

   this.maxObjectsLabel = new Label( this );
   this.maxObjectsLabel.text = "Max rows";
   this.maxObjectsLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.maxObjectsLabel.minWidth = 120;
   this.maxObjectsLabel.toolTip =
      "Maximum number of visible preview rows kept after filtering. Higher values search deeper, but can include many faint catalogue-only objects.";

   this.maxObjectsSpin = new SpinBox( this );
   this.maxObjectsSpin.minValue = 50;
   this.maxObjectsSpin.maxValue = 5000;
   this.maxObjectsSpin.value = this.config.maxObjects;
   this.maxObjectsSpin.toolTip = this.maxObjectsLabel.toolTip;
   this.maxObjectsSpin.onValueUpdated = function( value )
   {
      this.dialog.config.maxObjects = value;
   };

   this.sortModeLabel = new Label( this );
   this.sortModeLabel.text = "Sort by";
   this.sortModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.sortModeLabel.minWidth = 120;
   this.sortModeLabel.toolTip =
      "Controls the final order of preview tiles. Visible size uses the actual crop size, image contrast favours the clearest measured patches, and distance from centre favours objects near the image centre.";

   this.sortModeCombo = new ComboBox( this );
   this.sortModeCombo.addItem( "Default" );
   this.sortModeCombo.addItem( "Visible size" );
   this.sortModeCombo.addItem( "Image contrast" );
   this.sortModeCombo.addItem( "Distance from centre" );
   this.sortModeCombo.addItem( "Name" );
   var sortModes = [ "Default", "Visible size", "Image contrast", "Distance from centre", "Name" ];
   this.sortModeCombo.currentItem = Math.max( 0, sortModes.indexOf( this.config.sortMode ) );
   this.sortModeCombo.toolTip = this.sortModeLabel.toolTip;
   this.sortModeCombo.onItemSelected = function( index )
   {
      this.dialog.config.sortMode = sortModes[index];
   };

   this.visibilityModeLabel = new Label( this );
   this.visibilityModeLabel.text = "Visibility filter";
   this.visibilityModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   this.visibilityModeLabel.minWidth = 120;
   this.visibilityModeLabel.toolTip =
      "Filters preview crops that look like plain background in your actual image. Off keeps every catalogue hit, Permissive keeps more faint objects, Balanced is the default, Strict removes more blank-looking previews.";

   this.visibilityModeCombo = new ComboBox( this );
   this.visibilityModeCombo.addItem( "Off" );
   this.visibilityModeCombo.addItem( "Permissive" );
   this.visibilityModeCombo.addItem( "Balanced" );
   this.visibilityModeCombo.addItem( "Strict" );
   var visibilityModes = [ "Off", "Permissive", "Balanced", "Strict" ];
   this.visibilityModeCombo.currentItem = Math.max( 0, visibilityModes.indexOf( this.config.visibilityMode ) );
   this.visibilityModeCombo.toolTip = this.visibilityModeLabel.toolTip;
   this.visibilityModeCombo.onItemSelected = function( index )
   {
      this.dialog.config.visibilityMode = visibilityModes[index];
   };

   this.resultTree = new TreeBox( this );
   this.resultTree.alternateRowColor = true;
   this.resultTree.multipleSelection = false;
   this.resultTree.rootDecoration = false;
   this.resultTree.headerVisible = true;
   this.resultTree.numberOfColumns = 8;
   this.resultTree.setHeaderText( 0, "#" );
   this.resultTree.setHeaderText( 1, "Display ID" );
   this.resultTree.setHeaderText( 2, "Main ID" );
   this.resultTree.setHeaderText( 3, "Catalogue" );
   this.resultTree.setHeaderText( 4, "RA" );
   this.resultTree.setHeaderText( 5, "Dec" );
   this.resultTree.setHeaderText( 6, "Patch" );
   this.resultTree.setHeaderText( 7, "Visibility" );
   this.resultTree.minHeight = 260;
   this.resultTree.toolTip =
      "Catalogue objects kept by the current query. Click a row after a run to inspect that object's crop in the preview panel below.";
   this.resultTree.onNodeSelectionUpdated = function()
   {
      if ( this.dialog.resultTree.selectedNodes.length == 1 )
         this.dialog.showSelectedPreview( this.dialog.resultTree.selectedNodes[0] );
   };

   this.logBox = new TextBox( this );
   this.logBox.readOnly = true;
   this.logBox.minHeight = 120;
   this.logBox.toolTip =
      "Run log with query, filtering, crop validation, visibility filtering, and output creation messages.";

   this.previewTitleLabel = new Label( this );
   this.previewTitleLabel.text = this.selectedPreviewTitle;
   this.previewTitleLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   this.previewTitleLabel.visible = false;
   this.previewTitleLabel.toolTip =
      "Selected result preview. Click a row in the table to update the context zoom and enlarged crop.";

   this.previewCanvas = new Control( this );
   this.previewCanvas.minHeight = 260;
   this.previewCanvas.visible = false;
   this.previewCanvas.toolTip =
      "Selected object inspector. Left side shows a zoomed context crop from the annotated overview; right side shows the generated preview crop.";
   this.previewCanvas.onPaint = function( x0, y0, x1, y1 )
   {
      var g = new VectorGraphics( this );
      g.fillRect( x0, y0, x1, y1, new Brush( 0xff101820 ) );
      g.pen = new Pen( 0xff52637a, 1 );
      g.drawRect( 0, 0, this.width - 1, this.height - 1 );

      var dlg = this.dialog;
      if ( dlg.selectedPreviewBitmap && dlg.selectedContextBitmap )
      {
         var gap = 10;
         var leftW = Math.max( 1, Math.floor( (this.width - gap) * 0.58 ) );
         var rightW = Math.max( 1, this.width - leftW - gap );
         var panelH = this.height;

         var contextBmp = dlg.selectedContextBitmap;
         var scaleContext = Math.min( leftW / contextBmp.width, panelH / contextBmp.height );
         scaleContext = Math.max( 0.05, scaleContext );
         var contextDraw = Math.round( contextBmp.width * scaleContext );
         var contextScaled = contextBmp.scaledTo( contextDraw, contextDraw );
         var contextX = Math.round( (leftW - contextDraw) / 2 );
         var contextY = Math.round( (panelH - contextDraw) / 2 );

         g.drawBitmap( contextX, contextY, contextScaled );
         g.pen = new Pen( 0xff2d9cff, 1 );
         g.drawRect( contextX, contextY, contextX + contextDraw, contextY + contextDraw );
         g.drawText( contextX + 6, contextY + 18, "Overview zoom" );

         var bmp = dlg.selectedPreviewBitmap;
         var scalePatch = Math.min( rightW / bmp.width, panelH / bmp.height );
         scalePatch = Math.max( 0.05, scalePatch );
         var drawW = Math.round( bmp.width * scalePatch );
         var drawH = Math.round( bmp.height * scalePatch );
         var scaled = bmp.scaledTo( drawW, drawH );
         var dx = leftW + gap + Math.round( (rightW - drawW) / 2 );
         var dy = Math.round( (panelH - drawH) / 2 );
         g.drawBitmap( dx, dy, scaled );
         g.pen = new Pen( 0xffffffff, 1 );
         g.drawRect( dx, dy, dx + drawW, dy + drawH );
         g.pen = new Pen( 0xff2d9cff, 1 );
         g.drawText( dx + 6, dy + 18, "Preview crop" );
      }
      else
      {
         g.font = new Font( "Helvetica", 11 );
         g.pen = new Pen( 0xffa9b7c9, 1 );
         g.drawText( 16, Math.round( this.height / 2 ), "No selected preview yet" );
      }
      g.end();
   };

   this.runButton = new PushButton( this );
   this.runButton.text = "Query and Annotate";
   this.runButton.toolTip = "Run the SIMBAD query, filter/deduplicate objects, and create overview, grid, and final composite windows.";
   this.runButton.onClick = function()
   {
      this.dialog.runEngine();
   };

   this.exportButton = new PushButton( this );
   this.exportButton.text = "Export CSV";
   this.exportButton.enabled = false;
   this.exportButton.toolTip = "Export the last result table to CSV after a successful run.";
   this.exportButton.onClick = function()
   {
      this.dialog.exportResults();
   };

   this.closeButton = new PushButton( this );
   this.closeButton.text = "Close";
   this.closeButton.toolTip = "Close Sky Annotation Studio.";
   this.closeButton.onClick = function()
   {
      this.dialog.ok();
   };

   this.resetButton = new PushButton( this );
   this.resetButton.text = "Reset to defaults";
   this.resetButton.toolTip = "Restore the built-in default parameters for this session.";
   this.resetButton.onClick = function()
   {
      this.dialog.resetToDefaults();
   };

   this.syncConfigToControls = function()
   {
      this.windowModeCombo.currentItem = this.config.useActiveWindow ? 0 : 1;
      this.inputFileEdit.enabled = !this.config.useActiveWindow;
      this.inputFileButton.enabled = !this.config.useActiveWindow;
      this.inputFileEdit.text = this.config.inputFile;
      this.mainObjectEdit.text = this.config.mainObject;
      this.titleEdit.text = this.config.photoTitle;
      this.filterEdit.text = this.config.filterPrefixes.join( "," );
      this.labelModeCombo.currentItem =
         this.config.labelMode == "Object IDs" ? 1 : (this.config.labelMode == "Numbers + IDs" ? 2 : 0);
      this.boxSizeSpin.value = Math.round( this.config.boxSize );
      this.patchScaleSpin.value = Math.round( this.config.patchScale * 100 );
      this.previewPatchSizeSpin.value = this.config.previewPatchSize;
      this.maxObjectsSpin.value = this.config.maxObjects;
      this.sortModeCombo.currentItem =
         this.config.sortMode == "Visible size" ? 1 :
         (this.config.sortMode == "Image contrast" ? 2 :
         (this.config.sortMode == "Distance from centre" ? 3 :
         (this.config.sortMode == "Name" ? 4 : 0)));
      this.visibilityModeCombo.currentItem =
         this.config.visibilityMode == "Permissive" ? 1 :
         (this.config.visibilityMode == "Balanced" ? 2 :
         (this.config.visibilityMode == "Strict" ? 3 : 0));
   };

   this.resetToDefaults = function()
   {
      this.config.SetDefaults();
      this.selectedPreviewBitmap = null;
      this.selectedContextBitmap = null;
      this.selectedObject = null;
      this.previewTitleLabel.visible = false;
      this.previewCanvas.visible = false;
      this.syncConfigToControls();
      this.appendLog( "Parameters reset to defaults." );
      this.adjustToContents();
   };

   this.appendLog = function( message )
   {
      if ( this.logBox.text.length == 0 )
         this.logBox.text = message;
      else
         this.logBox.text += "\n" + message;
   };

   this.setResults = function( objects )
   {
      this.resultTree.clear();
      for ( var i = 0; i < objects.length; ++i )
      {
         var o = objects[i];
         var node = new TreeBoxNode( this.resultTree );
         node.setText( 0, (i + 1).toString() );
         node.setText( 1, o.displayId );
         node.setText( 2, o.mainId );
         node.setText( 3, o.catalogueType );
         node.setText( 4, format( "%.6f", o.ra ) );
         node.setText( 5, format( "%.6f", o.dec ) );
         node.setText( 6, format( "%.0f", o.patchSize ? o.patchSize : 0 ) );
         node.setText( 7, format( "%.2f", o.visibilityScore ? o.visibilityScore : 0 ) );
         node.objectIndex = i;
      }
      this.exportButton.enabled = objects.length > 0;
   };

   this.buildContextBitmap = function( object )
   {
      if ( !this.lastResult || !this.lastResult.overviewBitmap )
         return null;

      if ( this.lastResult.sourceWindow && !this.lastResult.sourceWindow.isNull )
      {
         var sourceWindow = this.lastResult.sourceWindow;
         var contextSizeSource = Math.max( object.patchSize * 5, object.patchSize + 360 );
         contextSizeSource = Math.max( contextSizeSource, 512 );
         var sourceWidth = sourceWindow.mainView.image.width;
         var sourceHeight = sourceWindow.mainView.image.height;
         contextSizeSource = Math.round( Math.min( Math.max( contextSizeSource, 1 ), Math.min( sourceWidth, sourceHeight ) ) );
         var contextHalf = Math.floor( contextSizeSource / 2 );
         var contextLeft = Math.round( object.px - contextHalf );
         var contextTop = Math.round( object.py - contextHalf );
         contextLeft = Math.max( 0, Math.min( sourceWidth - contextSizeSource, contextLeft ) );
         contextTop = Math.max( 0, Math.min( sourceHeight - contextSizeSource, contextTop ) );
         var contextBox = {
            left: contextLeft,
            top: contextTop,
            right: contextLeft + contextSizeSource,
            bottom: contextTop + contextSizeSource
         };
         var contextId = "SkyAnnotSelectedContext";
         try
         {
            var oldPreview = sourceWindow.previewById( contextId );
            if ( oldPreview && !oldPreview.isNull )
               sourceWindow.deletePreview( oldPreview );

            sourceWindow.createPreview(
               new Rect( contextBox.left, contextBox.top, contextBox.right, contextBox.bottom ),
               contextId
            );
            var contextView = sourceWindow.previewById( contextId );
            var contextBmp = this.getViewBitmap( contextView );
            sourceWindow.deletePreview( contextView );

            if ( contextBmp.width != 768 || contextBmp.height != 768 )
               contextBmp = contextBmp.scaledTo( 768, 768 );

            var cg = new VectorGraphics( contextBmp );
            var sourceScale = contextBmp.width / Math.max( 1, contextBox.right - contextBox.left );
            var sourceCx = Math.round( (object.px - contextBox.left) * sourceScale );
            var sourceCy = Math.round( (object.py - contextBox.top) * sourceScale );
            var boxLeft = Math.round( (object.box.left - contextBox.left) * sourceScale );
            var boxTop = Math.round( (object.box.top - contextBox.top) * sourceScale );
            var boxRight = Math.round( (object.box.right - contextBox.left) * sourceScale );
            var boxBottom = Math.round( (object.box.bottom - contextBox.top) * sourceScale );
            cg.pen = new Pen( 0xa0ffffff, 2 );
            cg.drawRect( boxLeft, boxTop, boxRight, boxBottom );
            cg.pen = new Pen( 0xff2d9cff, 2 );
            cg.drawLine( sourceCx - 22, sourceCy, sourceCx + 22, sourceCy );
            cg.drawLine( sourceCx, sourceCy - 22, sourceCx, sourceCy + 22 );
            cg.end();
            return contextBmp;
         }
         catch ( ex )
         {
         }
      }

      var overview = this.lastResult.overviewBitmap;
      var contextSize = Math.max( object.patchSize * 4, object.patchSize + 220 );
      contextSize = Math.min( Math.max( contextSize, 384 ), Math.min( overview.width, overview.height ) );
      var half = Math.floor( contextSize / 2 );
      var sx0 = Math.round( object.px - half );
      var sy0 = Math.round( object.py - half );
      sx0 = Math.max( 0, Math.min( overview.width - contextSize, sx0 ) );
      sy0 = Math.max( 0, Math.min( overview.height - contextSize, sy0 ) );

      var context = new Bitmap( contextSize, contextSize );
      context.fill( 0xff000000 );
      var g = new VectorGraphics( context );
      g.drawBitmapRect( new Point( 0, 0 ), overview, new Rect( sx0, sy0, sx0 + contextSize, sy0 + contextSize ) );
      g.pen = new Pen( 0xff2d9cff, 2 );
      var cx = Math.round( object.px - sx0 );
      var cy = Math.round( object.py - sy0 );
      g.drawLine( cx - 18, cy, cx + 18, cy );
      g.drawLine( cx, cy - 18, cx, cy + 18 );
      g.end();
      return context;
   };

   this.showSelectedPreview = function( node )
   {
      if ( !node || this.resultPatches.length == 0 )
         return;

      var index = node.objectIndex;
      if ( index < 0 || index >= this.resultPatches.length )
         return;

      var patch = this.resultPatches[index];
      var object = patch.object;
      var wasHidden = !this.previewCanvas.visible;
      this.selectedPreviewBitmap = patch.bitmap;
      this.selectedContextBitmap = patch.contextBitmap ? patch.contextBitmap : this.buildContextBitmap( object );
      this.selectedObject = object;
      this.selectedPreviewTitle =
         "Preview " + (index + 1).toString() + ": " + object.displayId +
         "  |  patch " + format( "%.0f", object.patchSize ? object.patchSize : 0 ) +
         " px  |  visibility " + format( "%.2f", object.visibilityScore ? object.visibilityScore : 0 );
      this.previewTitleLabel.text = this.selectedPreviewTitle;
      this.previewTitleLabel.visible = true;
      this.previewCanvas.visible = true;
      this.previewCanvas.update();
      if ( wasHidden )
         this.adjustToContents();
   };

   this.runEngine = function()
   {
      try
      {
         this.logBox.clear();
         this.config.SaveSettings();
         var engine = new SkyAnnotationEngine( this, this.config );
         var result = engine.run();
         Console.hide();
         this.lastResult = result;
         this.resultObjects = result.objects;
         this.resultPatches = result.patches ? result.patches : [];
         this.setResults( this.resultObjects );
         if ( this.resultTree.numberOfChildren > 0 )
         {
            this.resultTree.child( 0 ).selected = true;
            this.showSelectedPreview( this.resultTree.child( 0 ) );
         }
      }
      catch ( ex )
      {
         this.appendLog( "Error: " + ex );
         (new MessageBox( ex.toString(), "Sky Annotation Studio", StdIcon_Error, StdButton_Ok )).execute();
      }
   };

   this.exportResults = function()
   {
      if ( this.resultObjects.length == 0 )
         return;

      var sfd = new SaveFileDialog();
      sfd.caption = "Export annotation table";
      sfd.filters = [ [ "CSV files", ".csv" ] ];
      sfd.initialPath = File.systemTempDirectory + "/sky_annotation_results.csv";
      if ( !sfd.execute() )
         return;

      try
      {
         var engine = new SkyAnnotationEngine( this, this.config );
         engine.exportCsv( this.resultObjects, sfd.fileName );
         this.appendLog( "CSV exported to " + sfd.fileName );
      }
      catch ( ex )
      {
         (new MessageBox( ex.toString(), "Sky Annotation Studio", StdIcon_Error, StdButton_Ok )).execute();
      }
   };

   var row1 = new HorizontalSizer();
   row1.spacing = 6;
   row1.add( this.windowModeLabel );
   row1.add( this.windowModeCombo, 100 );

   var row2 = new HorizontalSizer();
   row2.spacing = 6;
   row2.add( this.inputFileLabel );
   row2.add( this.inputFileEdit, 100 );
   row2.add( this.inputFileButton );

   var row3 = new HorizontalSizer();
   row3.spacing = 6;
   row3.add( this.mainObjectLabel );
   row3.add( this.mainObjectEdit, 100 );

   var row4 = new HorizontalSizer();
   row4.spacing = 6;
   row4.add( this.titleLabel );
   row4.add( this.titleEdit, 100 );

   var row5 = new HorizontalSizer();
   row5.spacing = 6;
   row5.add( this.filterLabel );
   row5.add( this.filterEdit, 100 );

   var row6 = new HorizontalSizer();
   row6.spacing = 6;
   row6.add( this.labelModeLabel );
   row6.add( this.labelModeCombo );
   row6.addSpacing( 16 );
   row6.add( this.boxSizeLabel );
   row6.add( this.boxSizeSpin );
   row6.addSpacing( 16 );
   row6.add( this.maxObjectsLabel );
   row6.add( this.maxObjectsSpin );
   row6.addStretch();

   var row7 = new HorizontalSizer();
   row7.spacing = 6;
   row7.add( this.patchScaleLabel );
   row7.add( this.patchScaleSpin );
   row7.addSpacing( 16 );
   row7.add( this.previewPatchSizeLabel );
   row7.add( this.previewPatchSizeSpin );
   row7.addStretch();

   var row8 = new HorizontalSizer();
   row8.spacing = 6;
   row8.add( this.sortModeLabel );
   row8.add( this.sortModeCombo );
   row8.addSpacing( 16 );
   row8.add( this.visibilityModeLabel );
   row8.add( this.visibilityModeCombo );
   row8.addStretch();

   var buttonRow = new HorizontalSizer();
   buttonRow.spacing = 6;
   buttonRow.addStretch();
   buttonRow.add( this.runButton );
    buttonRow.add( this.resetButton );
   buttonRow.add( this.exportButton );
   buttonRow.add( this.closeButton );

   this.sizer = new VerticalSizer();
   this.sizer.margin = 10;
   this.sizer.spacing = 8;
   this.sizer.add( row1 );
   this.sizer.add( row2 );
   this.sizer.add( row3 );
   this.sizer.add( row4 );
   this.sizer.add( row5 );
   this.sizer.add( row6 );
   this.sizer.add( row7 );
   this.sizer.add( row8 );
   this.sizer.add( this.resultTree, 100 );
   this.sizer.add( this.previewTitleLabel );
   this.sizer.add( this.previewCanvas, 100 );
   this.sizer.add( this.logBox );
   this.sizer.add( buttonRow );

   this.windowTitle = "Sky Annotation Studio (PJSR MVP)";
   this.adjustToContents();
   this.setMinWidth( 980 );
   this.setMinHeight( 760 );
   this.syncConfigToControls();
}

SkyAnnotationDialog.prototype = new Dialog;

function main()
{
   Console.abortEnabled = true;
   Console.show();
   var dialog = new SkyAnnotationDialog();
   dialog.execute();
}

main();
